import assert from "node:assert/strict";
import test from "node:test";
import { execFileSync } from "node:child_process";
import { join } from "node:path";
import { fileURLToPath } from "node:url";

for (const [detail, expected] of [["HRESULT: 0x80073D02", "pending"], ["Registration temporarily unavailable", "deferred"]]) {
  test(`desktop update ${expected} keeps the registered release and returns a usable startup result`, { skip: process.platform !== "win32" }, () => {
    const scriptPath = fileURLToPath(new URL("../scripts/prepare-app-update.ps1", import.meta.url));
    // Only this isolated PowerShell process sees these mocks. No real package
    // registration, process shutdown, or filesystem mutation is performed.
    const script = `
function Get-AppxPackage { param($Name, [switch]$AllUsers)
  [pscustomobject]@{ Version=$(if($AllUsers){'26.930.3930.0'}else{'26.924.2738.0'}); PackageFamilyName='OpenAI.Codex_fixture'; Architecture='x64'; InstallLocation='C:\\fixture' }
}
function Get-CimInstance { param($Filter) }
function Test-Path { param($LiteralPath) $true }
function Add-AppxPackage { [CmdletBinding()]param($Register,[switch]$DisableDevelopmentMode) throw '${detail}' }
& '${scriptPath.replaceAll("'", "''")}'
`;
    const output = execFileSync(join(process.env.SystemRoot, "System32", "WindowsPowerShell", "v1.0", "powershell.exe"),
      ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", Buffer.from(script, "utf16le").toString("base64")],
      { encoding: "utf8", windowsHide: true, timeout: 10_000, stdio: ["ignore", "pipe", "pipe"] });
    const result = JSON.parse(output.trim());
    assert.equal(result.status, expected);
    assert.equal(result.version, "26.924.2738.0");
    assert.equal(result.pendingVersion, "26.930.3930.0");
  });
}
