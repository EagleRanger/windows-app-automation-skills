const Module = require("node:module");

const handlers = new Map();
handlers.set("codex_desktop:message-from-view", (_event, message) => message);
const ipcMain = { _invokeHandlers: handlers };
const electronReadyAt = Date.now() + 800;
const originalLoad = Module._load;

Module._load = function(request, parent, isMain) {
  if (request === "electron") {
    if (Date.now() < electronReadyAt) {
      const error = new Error("Cannot find module 'electron' during cold startup");
      error.code = "MODULE_NOT_FOUND";
      throw error;
    }
    return { ipcMain };
  }
  return originalLoad.call(this, request, parent, isMain);
};

console.log("READY");
setInterval(() => {}, 1_000);
