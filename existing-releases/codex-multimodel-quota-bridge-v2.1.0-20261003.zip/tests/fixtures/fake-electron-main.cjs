const Module = require("node:module");
const readline = require("node:readline");

const handlers = new Map();
handlers.set("codex_desktop:message-from-view", (_event, message) => message);
const ipcMain = { _invokeHandlers: handlers };
const originalLoad = Module._load;
Module._load = function(request, parent, isMain) {
  if (request === "electron") return { ipcMain };
  return originalLoad.call(this, request, parent, isMain);
};

console.log("READY");
const lines = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
lines.on("line", (line) => {
  const message = JSON.parse(line);
  const result = handlers.get("codex_desktop:message-from-view")({}, message);
  console.log(JSON.stringify(result));
});
