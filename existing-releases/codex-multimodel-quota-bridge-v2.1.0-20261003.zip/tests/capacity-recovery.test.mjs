import test from 'node:test';
import assert from 'node:assert/strict';
import { createCapacityRecovery } from '../vendor/codex-model-picker/src/capacity-recovery.mjs';

function fixture(options = {}) {
  const calls = [], notices = [];
  const source = { id: 'source', model: 'gpt-5.6-sol', modelProvider: 'openai' };
  const target = options.target || { threadId: 'source', model: 'gpt-5.6-terra', provider: 'openai', effort: 'medium' };
  const turn = { id: 'turn-1', status: 'inProgress', items: [{ type: 'userMessage', content: [{ type: 'text', text: 'Continue the bounded task' }] }, { type: 'reasoning' }] };
  let ledger = options.ledger || {}, selectedId = 'source', switched = false;
  const controller = createCapacityRecovery({
    readLedger: () => ledger,
    writeLedger: value => { if (options.storageFailure) throw new Error('storage full'); ledger = structuredClone(value); },
    pause: async () => {},
    selected: id => id === selectedId,
    notify: (...args) => notices.push(args),
    candidates: () => options.noCandidate ? [] : [target],
    switchTask: async () => { calls.push(['switch']); if (options.switchError) throw new Error('switch failed'); switched = true; selectedId = target.threadId; return { threadId: target.threadId }; },
    request: async (method, params) => {
      calls.push([method, structuredClone(params)]);
      if (method === 'thread/turns/list') return { data: [params.threadId === 'source' ? turn : { id: 'old-target', status: options.targetBusy ? 'inProgress' : 'completed', items: [] }] };
      if (method === 'turn/interrupt') { if (!options.stopFailure) turn.status = 'interrupted'; return {}; }
      if (method === 'thread/read') return { thread: switched ? { id: target.threadId, model: target.model, modelProvider: target.provider } : source };
      if (method === 'turn/start') { if (options.dispatchError) throw new Error('transport timeout'); return { turn: { id: 'recovery-turn' } }; }
      return {};
    },
  });
  const capture = () => {
    controller.observe({ type: 'codex-capacity-turn-request', requestId: 'req-1', model: source.model, params: { threadId: 'source', model: source.model, input: [{ type: 'text', text: 'Continue the bounded task' }], ...options.params } });
    controller.observe({ type: 'mcp-response', message: { id: 'req-1', result: { turn: { id: 'turn-1' } } } });
  };
  const error = (patch = {}) => controller.observe({ type: 'mcp-notification', method: 'error', params: { threadId: 'source', turnId: 'turn-1', willRetry: true, error: { message: 'Selected model is at capacity. Please try a different model.' }, ...patch } });
  if (!options.noCapture) capture();
  return { controller, calls, notices, turn, source, error, ledger: () => ledger };
}

test('capacity before tools interrupts, verifies and replays exactly once with original input', async () => {
  const f = fixture(); await Promise.all([f.error(), f.error()]); await f.error();
  assert.equal(f.calls.filter(c => c[0] === 'turn/interrupt').length, 1);
  const starts = f.calls.filter(c => c[0] === 'turn/start'); assert.equal(starts.length, 1);
  assert.equal(starts[0][1].model, 'gpt-5.6-terra'); assert.equal(starts[0][1].effort, 'medium');
  assert.equal(starts[0][1].input[0].text, 'Continue the bounded task');
  assert.equal(f.controller.diagnostics.replayed, 1);
});
for (const item of ['commandExecution', 'mcpToolCall', 'functionCall', 'functionCallOutput', 'fileChange', 'webSearch', 'agentMessage', 'unknownNewItem']) {
  test(`capacity after ${item} stops without replay or switch`, async () => {
    const f = fixture(); f.turn.items.push({ type: item }); await f.error();
    assert.equal(f.calls.some(c => c[0] === 'turn/interrupt'), true);
    assert.equal(f.calls.some(c => ['switch','turn/start','thread/archive'].includes(c[0])), false);
    assert.equal(f.notices.length, 1);
  });
}
for (const message of ['rate limit exceeded', 'usage limit reached', '502 Bad Gateway', 'Unknown Model', 'network timeout']) {
  test(`does not misclassify ${message}`, async () => {
    const f = fixture(); await f.error({ error: { message } }); assert.equal(f.calls.length, 0);
  });
}
for (const options of [{ noCapture: true }, { storageFailure: true }, { stopFailure: true }, { noCandidate: true }, { params: { toolOutput: {} } }, { params: { input: [{ type: 'image', url: 'local' }] } }]) {
  test(`fails closed for ${JSON.stringify(options)}`, async () => {
    const f = fixture(options); await f.error(); assert.equal(f.calls.some(c => c[0] === 'turn/start'), false);
  });
}
test('a stale error never interrupts a newer turn', async () => {
  const f = fixture(); f.turn.id = 'new-turn'; await f.error(); assert.equal(f.calls.some(c => c[0] === 'turn/interrupt'), false);
});
test('a newer request prevents replay of older work', async () => {
  const f = fixture(); f.controller.observe({ type: 'codex-capacity-turn-request', requestId: 'req-2', params: { threadId: 'source' } });
  await f.error(); assert.equal(f.calls.some(c => c[0] === 'turn/start'), false);
});
test('manual model change wins', async () => {
  const f = fixture(); f.source.model = 'gpt-6-astra'; await f.error(); assert.equal(f.calls.some(c => c[0] === 'switch'), false);
});
test('cross-provider recovery requires explicit preserved permission policies', async () => {
  const f = fixture({ target: { threadId: 'zai-slot', model: 'glm-5.3-flash', provider: 'zai', effort: 'high' } });
  await f.error(); assert.equal(f.calls.some(c => c[0] === 'switch'), false);
});
test('cross-provider recovery reuses slot and preserves permission policies', async () => {
  const params = { approvalPolicy: 'on-request', sandboxPolicy: { type: 'readOnly' } };
  const f = fixture({ params, target: { threadId: 'zai-slot', model: 'glm-5.3-flash', provider: 'zai', effort: 'high' } });
  await f.error(); const start = f.calls.find(c => c[0] === 'turn/start');
  assert.equal(start[1].threadId, 'zai-slot'); assert.deepEqual(start[1].sandboxPolicy, params.sandboxPolicy);
  assert.equal(start[1].approvalPolicy, 'on-request'); assert.equal(f.calls.some(c => c[0] === 'thread/start'), false);
});
test('an occupied paired slot is never interrupted or changed', async () => {
  const f = fixture({ targetBusy: true, params: { approvalPolicy: 'on-request', sandboxPolicy: { type: 'readOnly' } }, target: { threadId: 'zai-slot', model: 'glm-5.3-flash', provider: 'zai' } });
  await f.error(); assert.equal(f.calls.some(c => c[0] === 'switch'), false);
});
test('uncertain dispatch is retained in durable ledger and not resent after reload', async () => {
  const f = fixture({ dispatchError: true }); await f.error();
  const restarted = fixture({ ledger: f.ledger() }); await restarted.error(); assert.equal(restarted.calls.length, 0);
  assert.equal(f.calls.filter(c => c[0] === 'turn/start').length, 1);
});
test('a recovered turn cannot start a fallback chain', async () => {
  const f = fixture(); await f.error(); f.turn.id = 'recovery-turn'; f.turn.status = 'inProgress';
  await f.error({ turnId: 'recovery-turn' });
  assert.equal(f.calls.filter(c => c[0] === 'turn/start').length, 1);
});

test('remote host notifications cannot interrupt a local task', async () => {
  const f = fixture();
  await f.controller.observe({type:'mcp-notification',hostId:'remote',method:'error',params:{threadId:'source',turnId:'turn-1',error:{codexErrorInfo:'serverOverloaded'}}});
  assert.equal(f.calls.length,0);
});
