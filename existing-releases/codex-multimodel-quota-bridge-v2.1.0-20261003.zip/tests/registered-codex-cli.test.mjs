import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve, sep } from "node:path";
import test from "node:test";
import { resolveCodexCli } from "../scripts/codex-cli.mjs";
import { publishRegisteredCliBundle, REQUIRED_RUNTIME_FILES } from "../scripts/registered-codex-cli.mjs";

test("registered package CLI copy is selected before an older desktop cache", async () => {
  const local = await mkdtemp(join(tmpdir(), "picker-cli-selection-"));
  try {
    const root = join(local, "CodexModelPicker", "official-cli");
    const current = join(root, "26.930.3930.0", "codex.exe");
    const old = join(local, "OpenAI", "Codex", "bin", "codex.exe");
    await mkdir(join(root, "26.930.3930.0"), { recursive: true });
    await mkdir(join(local, "OpenAI", "Codex", "bin"), { recursive: true });
    await writeFile(current, "test");
    await writeFile(old, "test");
    const files = [];
    for (const name of REQUIRED_RUNTIME_FILES) {
      await writeFile(join(dirname(current), name), "test");
      files.push({ name, size: 4 });
    }
    await writeFile(join(dirname(current), "runtime-manifest.json"), JSON.stringify({ bundleVersion: 1, bundleId: "test", files }));
    await writeFile(join(root, "state.json"), JSON.stringify({ path: current, bundleVersion: 1, bundleId: "test" }));
    const env = { LOCALAPPDATA: local, PATH: "", CODEX_CLI_PATH: "" };
    assert.equal(resolveCodexCli({ platform: "win32", preferInstalled: true, env }), current);
    await writeFile(join(root, "state.json"), JSON.stringify({ path: join(local, "outside.exe") }));
    assert.equal(resolveCodexCli({ platform: "win32", preferInstalled: true, env }), old);
  } finally {
    assert.ok(resolve(local).startsWith(resolve(tmpdir()) + sep));
    await rm(local, { recursive: true, force: true });
  }
});

async function fixture(fn) {
  const local = await mkdtemp(join(tmpdir(), "picker-cli-bundle-"));
  try {
    const root = join(local, "CodexModelPicker", "official-cli");
    const source = join(local, "source");
    await mkdir(source);
    for (const name of [...REQUIRED_RUNTIME_FILES, "codex-windows-sandbox-service.exe"]) await writeFile(join(source, name), name);
    const old = join(local, "OpenAI", "Codex", "bin", "codex.exe");
    await mkdir(dirname(old), { recursive: true });
    await writeFile(old, "native");
    const env = { LOCALAPPDATA: local, PATH: "", CODEX_CLI_PATH: "" };
    const publish = () => publishRegisteredCliBundle({ root, registered: { version: "26.930.3930.0", executable: join(source, "codex.exe") },
      getVersion: async path => {
        assert.equal(await readFile(join(dirname(path), "codex-command-runner.exe"), "utf8"), "codex-command-runner.exe");
        return "0.160.0";
      } });
    await fn({ local, root, source, old, env, publish });
  } finally {
    assert.ok(resolve(local).startsWith(resolve(tmpdir()) + sep));
    await rm(local, { recursive: true, force: true });
  }
}

test("publishes all official helpers and reuses only a verified complete bundle", () => fixture(async f => {
  const state = await f.publish();
  assert.equal(state.changed, true);
  assert.equal(await readFile(join(dirname(state.path), "codex-windows-sandbox-service.exe"), "utf8"), "codex-windows-sandbox-service.exe");
  assert.equal(resolveCodexCli({ platform: "win32", preferInstalled: true, env: f.env }), state.path);
  assert.equal((await f.publish()).changed, false);
}));

test("missing helper makes resolver fall back; repair leaves active bundle untouched", () => fixture(async f => {
  const before = await f.publish();
  await rm(join(dirname(before.path), "codex-code-mode-host.exe"));
  assert.equal(resolveCodexCli({ platform: "win32", preferInstalled: true, env: f.env }), f.old);
  const repaired = await f.publish();
  assert.notEqual(repaired.path, before.path);
  assert.equal(await readFile(before.path, "utf8"), "codex.exe");
  assert.equal(resolveCodexCli({ platform: "win32", preferInstalled: true, env: f.env }), repaired.path);
}));

test("incomplete official source never replaces last working state", () => fixture(async f => {
  await f.publish();
  const before = await readFile(join(f.root, "state.json"), "utf8");
  await rm(join(f.source, "codex-code-mode-host.exe"));
  await assert.rejects(f.publish(), /incomplete.*code-mode-host/);
  assert.equal(await readFile(join(f.root, "state.json"), "utf8"), before);
}));

test("same-size corruption is detected; legacy lone copies are rejected", () => fixture(async f => {
  const before = await f.publish();
  await writeFile(join(dirname(before.path), "codex-code-mode-host.exe"), "x".repeat("codex-code-mode-host.exe".length));
  assert.notEqual((await f.publish()).path, before.path);
  await writeFile(join(f.root, "state.json"), JSON.stringify({ path: before.path }));
  assert.equal(resolveCodexCli({ platform: "win32", preferInstalled: true, env: f.env }), f.old);
}));
