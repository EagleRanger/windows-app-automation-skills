import test from "node:test";
import assert from "node:assert/strict";
import vm from "node:vm";
import { EventEmitter } from "node:events";
import { spawn, spawnSync } from "node:child_process";
import { createServer } from "node:net";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { buildMainInjectionSource } from "../vendor/codex-model-picker/src/main-injection-source.mjs";

const pluginRoot = fileURLToPath(new URL("..", import.meta.url));

async function getFreePort() {
  const server = createServer();
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  const port = server.address().port;
  await new Promise((resolve) => server.close(resolve));
  return port;
}

function waitForLine(stream, predicate, timeoutMs = 10_000) {
  return new Promise((resolve, reject) => {
    let buffer = "";
    const timer = setTimeout(() => finish(new Error("Timed out waiting for child output.")), timeoutMs);
    const onData = (chunk) => {
      buffer += chunk;
      const lines = buffer.split(/\r?\n/);
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        if (predicate(line)) return finish(null, line);
      }
    };
    const finish = (error, value) => {
      clearTimeout(timer);
      stream.off("data", onData);
      if (error) reject(error); else resolve(value);
    };
    stream.on("data", onData);
  });
}

function installRouter(providerByModel, responder = null, projectLoopRoots = []) {
  const captured = [];
  const viewMessages = [];
  const capacityMessages = [];
  const loopReads = [];
  const original = (_event, message) => {
    captured.push(message);
    return typeof responder === "function" ? responder(message) : "ok";
  };
  const handlers = new Map([["codex_desktop:message-from-view", original]]);
  const context = vm.createContext({
    setTimeout,
    require(name) {
      if (name === "electron") return { ipcMain: { _invokeHandlers: handlers } };
      if (name === "node:path") return path;
      if (name === "node:fs/promises") {
        return {
          async readFile(file) {
            loopReads.push(file);
            if (file.endsWith(`${path.sep}.project-reasoning${path.sep}STATE.md`)) {
              return "# 项目状态\n- 当前阶段：验证。";
            }
            const error = new Error("not found");
            error.code = "ENOENT";
            throw error;
          },
        };
      }
      throw new Error(`unexpected require: ${name}`);
    },
  });
  const source = buildMainInjectionSource({
    providerByModel,
    defaultProvider: "openai",
    projectLoopRoots,
  });
  const result = new vm.Script(source).runInContext(context);
  assert.equal(result.status, "patched");
  const event = {
    sender: {
      send(channel, message) {
        (message.type === 'codex-capacity-turn-request' ? capacityMessages : viewMessages).push({ channel, message });
      },
    },
  };
  return {
    captured,
    viewMessages,
    capacityMessages,
    loopReads,
    event,
    diagnostics: result,
    handler: handlers.get("codex_desktop:message-from-view"),
  };
}

test("a held renderer settings request receives its matching completion reply", async () => {
  const f = installRouter({"glm-5.3-flash":"zai"});
  f.diagnostics.providerByThreadId.source = "openai";
  await f.handler(f.event, {type:"mcp-request", request:{id:"menu-change-123",method:"thread/settings/update",params:{threadId:"source",model:"glm-5.3-flash",effort:"high"}}});
  assert.equal(f.captured.length,0);
  const replies=f.viewMessages.filter(x=>x.message.type==="mcp-response");
  assert.equal(replies.length,1);
  assert.equal(replies[0].message.message.id,"menu-change-123");
  assert.deepEqual(Object.keys(replies[0].message.message.result),[]);
});

test("provider router assigns OpenAI, DeepSeek, and Z.ai when a new task starts", () => {
  const { captured, handler } = installRouter({
    "deepseek-flash": "deepseek",
    "deepseek-v4-pro": "deepseek",
    "glm-5.3-flash": "zai",
  });
  handler({}, {
    type: "app-server-request",
    request: { method: "thread/start", params: { model: "deepseek-flash", modelProvider: "openai" } },
  });
  handler({}, {
    request: { method: "thread/start", params: { model: "gpt-6-astra" } },
  });
  handler({}, {
    request: { method: "thread/start", params: { model: "glm-5.3-flash" } },
  });
  assert.equal(captured[0].request.params.modelProvider, "deepseek");
  assert.equal(captured[1].request.params.modelProvider, "openai");
  assert.equal(captured[2].request.params.modelProvider, "zai");
});

test("turn capture preserves permissions and strips recovery marker for both IPC encodings", () => {
  for (const serialized of [false, true]) {
    const f = installRouter({ "gpt-5.6-terra": "openai" });
    const message = { type: "mcp-request", request: { id: "capture", method: "turn/start", params: {
      threadId: "existing", model: "gpt-5.6-terra", input: [{ type: "text", text: "test input" }],
      approvalPolicy: "on-request", sandboxPolicy: { type: "readOnly" }, __codexCapacityRecovery: true,
    } } };
    f.handler(f.event, serialized ? JSON.stringify(message) : message);
    const capture = f.capacityMessages[0].message;
    assert.equal(capture.type, "codex-capacity-turn-request");
    assert.equal(capture.recovery, true);
    assert.equal(capture.params.approvalPolicy, "on-request");
    const actual = serialized ? JSON.parse(f.captured[0]) : f.captured[0];
    assert.equal(actual.request.params.__codexCapacityRecovery, undefined);
    assert.equal(actual.request.params.sandboxPolicy.type, "readOnly");
  }
});

test("new queue input and manual effort changes invalidate recovery snapshots", () => {
  const f = installRouter({});
  for (const method of ['thread/queue/add','thread/settings/update']) {
    f.handler(f.event,{request:{id:method,method,params:{threadId:'source',reasoningEffort:'low'}}});
  }
  const messages=f.capacityMessages;
  assert.equal(messages.length,2);
  assert.equal(messages.every(x=>x.message.recovery===true),true);
});

test("provider router restores the renderer hook after a Codex document reload", async () => {
  const handlers = new Map([["codex_desktop:message-from-view", () => "ok"]]);
  const executed = [];
  const contents = new EventEmitter();
  contents.getURL = () => "app://-/index.html";
  contents.isDestroyed = () => false;
  contents.executeJavaScript = async (source) => { executed.push(source); };
  const app = new EventEmitter();
  const context = vm.createContext({
    setTimeout,
    require(name) {
      if (name === "electron") {
        return {
          ipcMain: { _invokeHandlers: handlers },
          app,
          webContents: { getAllWebContents: () => [contents] },
        };
      }
      throw new Error(`unexpected require: ${name}`);
    },
  });
  const source = buildMainInjectionSource({
    rendererHookSource: "globalThis.__rendererHookRestored = true;",
    rendererHookVersion: 56,
  });
  const diagnostics = new vm.Script(source).runInContext(context);
  await Promise.resolve();
  assert.equal(diagnostics.rendererHookPersistence, "active");
  assert.equal(executed.length, 1);
  contents.emit("did-finish-load");
  await Promise.resolve();
  assert.equal(executed.length, 2);
  assert.equal(executed[1], "globalThis.__rendererHookRestored = true;");
});

test("provider router reads only the source project's fixed Loop state path", async () => {
  const { captured, viewMessages, loopReads, event, handler } = installRouter({});
  const result = await handler(event, {
    request: {
      id: "loop-read-1",
      method: "codex/project-loop/read",
      params: { cwd: "C:\\project", maxChars: 99_999 },
    },
  });
  assert.equal(Object.keys(result).length, 0);
  assert.equal(captured.length, 0);
  assert.deepEqual(loopReads, [path.join("C:\\project", ".project-reasoning", "STATE.md")]);
  assert.equal(viewMessages.length, 1);
  assert.equal(JSON.stringify(viewMessages[0].message), JSON.stringify({
    type: "mcp-response",
    message: {
    id: "loop-read-1",
    result: {
      status: "loaded",
      source: ".project-reasoning/STATE.md",
      truncated: false,
      content: "# 项目状态\n- 当前阶段：验证。",
    },
    },
  }));
});

test("provider router resolves a named execution task to its exact project Loop root", async () => {
  const genericCwd = "C:\\Users\\Example\\Documents\\Automation";
  const projectRoot = "C:\\Users\\Example\\Documents\\Automation\\example_project";
  const { loopReads, event, handler } = installRouter(
    {},
    null,
    [{ cwd: genericCwd, titleIncludes: "CAD开发与调试", projectRoot }],
  );
  await handler(event, {
    request: {
      id: "loop-read-cad",
      method: "codex/project-loop/read",
      params: { cwd: genericCwd, threadTitle: "【执行】CAD开发与调试", maxChars: 8_000 },
    },
  });
  assert.deepEqual(loopReads, [path.join(projectRoot, ".project-reasoning", "STATE.md")]);
});

test("provider router can map a historical workspace root to its canonical project Loop without a title rule", async () => {
  const historicalRoot = "C:\\Users\\Example\\Documents\\HistoricalFramework";
  const canonicalRoot = "C:\\Users\\Example\\Documents\\Framework";
  const { loopReads, event, handler } = installRouter(
    {},
    null,
    [{ cwd: historicalRoot, projectRoot: canonicalRoot }],
  );
  await handler(event, {
    request: {
      id: "loop-read-framework",
      method: "codex/project-loop/read",
      params: { cwd: historicalRoot, threadTitle: "【项目】Skill管理", maxChars: 8_000 },
    },
  });
  assert.deepEqual(loopReads, [path.join(canonicalRoot, ".project-reasoning", "STATE.md")]);
});

test("provider router assigns providers when an existing task resumes or forks", () => {
  const { captured, handler } = installRouter({ "deepseek-flash": "deepseek" });
  handler({}, {
    request: { method: "thread/resume", params: { threadId: "old", model: "deepseek-flash" } },
  });
  handler({}, {
    request: { method: "thread/fork", params: { threadId: "old", model: "gpt-6-astra" } },
  });
  assert.equal(captured[0].request.params.modelProvider, "deepseek");
  assert.equal(captured[1].request.params.modelProvider, "openai");
});

test("provider router carries an existing task model choice into a model-less native fork", async () => {
  const { captured, viewMessages, event, diagnostics, handler } = installRouter({
    "deepseek-flash": "deepseek",
  });
  await handler(event, {
    request: {
      method: "thread/settings/update",
      params: { threadId: "source-thread", model: "deepseek-flash" },
    },
  });
  assert.equal(captured.length, 0);
  handler(event, {
    request: {
      method: "thread/fork",
      params: { threadId: "source-thread", model: null },
    },
  });
  assert.equal(captured[0].request.params.model, "deepseek-flash");
  assert.equal(captured[0].request.params.modelProvider, "deepseek");
  assert.equal(diagnostics.inferredForkModels, 1);
  assert.equal(viewMessages.length, 1);
  assert.equal(viewMessages[0].channel, "codex_desktop:message-for-view");
  assert.deepEqual(
    {
      type: viewMessages[0].message.type,
      sourceThreadId: viewMessages[0].message.sourceThreadId,
      model: viewMessages[0].message.model,
      provider: viewMessages[0].message.provider,
    },
    {
      type: "codex-provider-switch-request",
      sourceThreadId: "source-thread",
      model: "deepseek-flash",
      provider: "deepseek",
    },
  );
});

test("provider router releases an explicitly verified same-provider settings update", async () => {
  const { captured, handler } = installRouter({ "deepseek-flash": "deepseek" });
  await handler({}, {
    request: {
      method: "thread/settings/update",
      params: {
        threadId: "source-thread",
        model: "deepseek-flash",
        __codexProviderSwitchBypass: true,
      },
    },
  });
  assert.equal(captured.length, 1);
  assert.equal(captured[0].request.params.model, "deepseek-flash");
  assert.equal("__codexProviderSwitchBypass" in captured[0].request.params, false);
});

test("provider router learns an existing DeepSeek task from thread/read before an effort-only update", async () => {
  const { captured, viewMessages, event, diagnostics, handler } = installRouter(
    { "deepseek-flash": "deepseek" },
    (message) => message.request.method === "thread/read"
      ? { thread: { id: "deepseek-thread", model: "deepseek-flash", modelProvider: "deepseek" } }
      : "ok",
  );
  await handler(event, {
    request: { method: "thread/read", params: { threadId: "deepseek-thread", includeTurns: false } },
  });
  await handler(event, {
    request: {
      method: "thread/settings/update",
      params: { threadId: "deepseek-thread", model: "deepseek-flash", reasoningEffort: "high" },
    },
  });
  assert.equal(diagnostics.providerByThreadId["deepseek-thread"], "deepseek");
  assert.equal(captured.length, 2);
  assert.equal(captured[1].request.params.reasoningEffort, "high");
  assert.equal(viewMessages.length, 0);
});

test("provider router leaves an untracked OpenAI task to Codex native model switching", () => {
  const { captured, viewMessages, handler } = installRouter({ "deepseek-flash": "deepseek" });
  handler({}, {
    request: {
      method: "thread/settings/update",
      params: { threadId: "openai-thread", model: "gpt-5.6-sol" },
    },
  });
  assert.equal(captured.length, 1);
  assert.equal(viewMessages.length, 0);
  assert.equal(captured[0].request.params.model, "gpt-5.6-sol");
});

test("provider router only holds a verified cross-provider model switch", async () => {
  const { captured, viewMessages, event, diagnostics, handler } = installRouter({ "deepseek-flash": "deepseek" });
  diagnostics.providerByThreadId["deepseek-thread"] = "deepseek";
  const intercepted = await handler(event, {
    request: {
      method: "thread/settings/update",
      params: { threadId: "deepseek-thread", model: "gpt-5.6-sol" },
    },
  });
  assert.equal(Object.keys(intercepted).length, 0);
  assert.equal(captured.length, 0);
  assert.equal(viewMessages.length, 1);
  assert.equal(viewMessages[0].message.provider, "openai");
  assert.equal(viewMessages[0].message.settings.model, "gpt-5.6-sol");

  diagnostics.providerByThreadId["same-deepseek-thread"] = "deepseek";
  handler(event, {
    request: {
      method: "thread/settings/update",
      params: { threadId: "same-deepseek-thread", model: "deepseek-flash" },
    },
  });
  assert.equal(captured.length, 1);
  assert.equal(viewMessages.length, 1);
});

test("provider-family sync keeps an external task external after a stale OpenAI model read", async () => {
  const { captured, viewMessages, event, diagnostics, handler } = installRouter({
    "glm-5.3-flash": "zai",
  });
  await handler(event, {
    request: {
      id: "provider-sync-1",
      method: "codex/provider-families/sync",
      params: {
        version: 1,
        providerByThreadId: { "zai-thread": "zai" },
      },
    },
  });
  await handler(event, {
    request: { method: "thread/read", params: { threadId: "zai-thread" } },
  });
  diagnostics.providerByThreadId["zai-thread"] = "openai";
  const intercepted = await handler(event, {
    request: {
      method: "thread/settings/update",
      params: { threadId: "zai-thread", model: "gpt-5.6-terra" },
    },
  });
  assert.equal(Object.keys(intercepted).length, 0);
  assert.equal(captured.length, 1);
  assert.equal(captured[0].request.method, "thread/read");
  assert.equal(viewMessages.at(-1).message.type, "codex-provider-switch-request");
  assert.equal(viewMessages.at(-1).message.provider, "openai");
  assert.equal(diagnostics.familyProviderByThreadId["zai-thread"], "zai");
});

test("provider router preserves an access update while routing an external model switch", async () => {
  const { captured, viewMessages, event, diagnostics, handler } = installRouter({
    "deepseek-flash": "deepseek",
  });
  diagnostics.providerByThreadId["deepseek-thread"] = "deepseek";
  await handler(event, {
    request: {
      method: "thread/settings/update",
      params: {
        threadId: "deepseek-thread",
        model: "gpt-5.6-sol",
        sandbox: "elevated",
        approvalPolicy: "on-request",
      },
    },
  });
  assert.equal(captured.length, 1);
  assert.equal(captured[0].request.params.sandbox, "elevated");
  assert.equal(captured[0].request.params.approvalPolicy, "on-request");
  assert.equal("model" in captured[0].request.params, false);
  assert.equal(viewMessages.length, 1);
  assert.equal(viewMessages[0].message.provider, "openai");
  assert.equal(diagnostics.sanitizedExternalModelUpdates, 1);
});

test("provider router never forwards a GLM model from an untracked OpenAI task", async () => {
  const { captured, viewMessages, event, diagnostics, handler } = installRouter({
    "glm-5.3-flash": "zai",
  });
  await handler(event, {
    request: {
      method: "thread/settings/update",
      params: {
        threadId: "openai-thread",
        model: "glm-5.3-flash",
        reasoningEffort: "high",
        sandbox: "elevated",
      },
    },
  });
  assert.equal(captured.length, 1);
  assert.equal(captured[0].request.params.sandbox, "elevated");
  assert.equal("model" in captured[0].request.params, false);
  assert.equal(viewMessages.length, 1);
  assert.equal(viewMessages[0].message.provider, "zai");
  assert.equal(diagnostics.sanitizedExternalModelUpdates, 1);
});

test("provider router leaves provider sticky when resume or fork has no model choice", () => {
  const { captured, handler } = installRouter({ "deepseek-flash": "deepseek" });
  handler({}, {
    request: { method: "thread/resume", params: { threadId: "source-thread" } },
  });
  handler({}, {
    request: { method: "thread/fork", params: { threadId: "untracked-thread" } },
  });
  assert.equal("modelProvider" in captured[0].request.params, false);
  assert.equal("modelProvider" in captured[1].request.params, false);
});

test("provider router handles serialized messages and removes provider filtering", () => {
  const { captured, handler } = installRouter({ "deepseek-flash": "deepseek" });
  handler({}, JSON.stringify({
    request: { method: "thread/list", params: { limit: 20, modelProviders: ["openai"] } },
  }));
  const parsed = JSON.parse(captured[0]);
  assert.deepEqual(parsed.request.params.modelProviders, []);
});

test("provider router leaves ordinary turn input completely untouched", () => {
  const { captured, handler } = installRouter({ "deepseek-flash": "deepseek" });
  const input = { type: "text", text: "normal GPT turn" };
  input.self = input;
  handler({}, {
    request: { method: "turn/start", params: { threadId: "gpt-thread", input } },
  });
  assert.equal(captured.length, 1);
  assert.equal(captured[0].request.params.input, input);
  assert.equal(captured[0].request.params.input.self, input);
});

test("provider router rejects invalid provider mappings", () => {
  assert.throws(
    () => buildMainInjectionSource({ providerByModel: { "bad model": "deepseek" } }),
    /invalid/,
  );
});

test("main-process inspector installs and routes a real IPC handler", async () => {
  const port = await getFreePort();
  const fixture = new URL("./fixtures/fake-electron-main.cjs", import.meta.url);
  const child = spawn(process.execPath, [
    `--inspect=127.0.0.1:${port}`,
    fileURLToPath(fixture),
  ], { stdio: ["pipe", "pipe", "pipe"] });
  child.stdout.setEncoding("utf8");
  try {
    await waitForLine(child.stdout, (line) => line === "READY");
    const providerMap = Buffer.from(JSON.stringify({ "deepseek-v4-pro": "deepseek" })).toString("base64url");
    const result = spawnSync(process.execPath, [
      `${pluginRoot}/vendor/codex-model-picker/src/main-injector.mjs`,
      `--port=${port}`,
      `--provider-map=${providerMap}`,
      "--default-provider=openai",
    ], { encoding: "utf8", timeout: 35_000 });
    assert.equal(result.status, 0, result.stderr || result.stdout);

    const routedLine = waitForLine(child.stdout, (line) => line.startsWith("{"));
    child.stdin.write(`${JSON.stringify({ request: {
      method: "thread/start",
      params: { model: "deepseek-v4-pro" },
    } })}\n`);
    const routed = JSON.parse(await routedLine);
    assert.equal(routed.request.params.modelProvider, "deepseek");
  } finally {
    child.kill();
  }
});

test("main-process injector survives Electron becoming available after cold start", async () => {
  const port = await getFreePort();
  const fixture = new URL("./fixtures/fake-electron-main-delayed.cjs", import.meta.url);
  const child = spawn(process.execPath, [
    `--inspect=127.0.0.1:${port}`,
    fileURLToPath(fixture),
  ], { stdio: ["ignore", "pipe", "pipe"] });
  child.stdout.setEncoding("utf8");
  try {
    await waitForLine(child.stdout, (line) => line === "READY");
    const providerMap = Buffer.from(JSON.stringify({ "deepseek-flash": "deepseek" })).toString("base64url");
    const result = spawnSync(process.execPath, [
      `${pluginRoot}/vendor/codex-model-picker/src/main-injector.mjs`,
      `--port=${port}`,
      `--provider-map=${providerMap}`,
      "--default-provider=openai",
    ], { encoding: "utf8", timeout: 35_000 });
    assert.equal(result.status, 0, result.stderr || result.stdout);
  } finally {
    child.kill();
  }
});
