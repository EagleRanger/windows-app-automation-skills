import test from 'node:test';
import assert from 'node:assert/strict';
import { createSwitchReceipts, assertPairIdentity } from '../vendor/codex-model-picker/src/switch-receipt.mjs';

const intent = { sourceThreadId: 'a', provider: 'zai', model: 'glm-5.3-flash', fingerprint: 'hash' };
function fixture() {
  const registry = { threadToFamily: { a: 'f' }, families: { f: { providers: { openai: 'a' } } } };
  let persisted;
  const save = () => { persisted = JSON.stringify(registry); };
  return { registry, journal: createSwitchReceipts({ registry, save }), get persisted() { return persisted; } };
}
test('ambiguous creation survives restart and forbids a second native creation', () => {
  const f = fixture(), receipt = f.journal.begin('f', intent);
  f.journal.dispatch(receipt, 'req-1', 'create');
  const copy = JSON.parse(f.persisted), restarted = createSwitchReceipts({ registry: copy, save() {} });
  assert.throws(() => restarted.begin('f', intent), /unknown/);
  assert.equal(restarted.settle({ id: 'req-other', result: { thread: { id: 'wrong' } } }), false);
  assert.equal(restarted.settle({ id: 'req-1', result: { thread: { id: 'b', modelProvider: 'zai' } } }), true);
  assert.equal(copy.families.f.providers.zai, 'b');
  assert.equal(restarted.begin('f', intent).handoffConfirmed, true);
});
test('confirmed handoff is reusable, a new delta receives a new receipt', () => {
  const f = fixture(), r = f.journal.begin('f', intent);
  f.journal.dispatch(r, 'inject', 'handoff');
  f.journal.settle({ id: 'inject', result: {} });
  assert.equal(f.journal.begin('f', intent).id, r.id);
  assert.equal(f.journal.begin('f', intent).handoffConfirmed, true);
  assert.equal(f.journal.begin('f', { ...intent, fingerprint: 'new delta' }).handoffConfirmed, false);
});
test('unknown method may retry alternate spelling; ambiguous errors cannot', () => {
  const f = fixture(), r = f.journal.begin('f', intent);
  f.journal.dispatch(r, 'one', 'handoff');
  f.journal.settle({ id: 'one', error: { message: 'method not found' } });
  f.journal.dispatch(r, 'two', 'handoff');
  f.journal.settle({ id: 'two', error: { message: 'transport failed after write' } });
  assert.throws(() => f.journal.begin('f', intent), /unknown/);
});
test('late or duplicate responses cannot overwrite a newer switch or another family', () => {
  const f = fixture(), r = f.journal.begin('f', intent);
  f.journal.dispatch(r, 'one', 'create');
  f.journal.settle({ id: 'one', result: { thread: { id: 'b', modelProvider: 'zai' } } });
  const newer = f.journal.begin('f', { ...intent, fingerprint: 'new' });
  assert.equal(f.journal.settle({ id: 'one', result: { thread: { id: 'evil' } } }), false);
  assert.equal(f.registry.families.f.providers.zai, 'b');
  assert.equal(newer.handoffConfirmed, false);
});
test('native conflicting provider or occupied slot cannot be accepted', () => {
  for (const response of [{ id: 'b', modelProvider: 'deepseek' }, { id: 'a', modelProvider: 'zai' }, {}]) {
    const f = fixture(), r = f.journal.begin('f', intent);
    f.journal.dispatch(r, 'one', 'create');
    f.journal.settle({ id: 'one', result: { thread: response } });
    assert.equal(f.journal.unresolved(r), true);
    assert.equal(f.registry.families.f.providers.zai, undefined);
  }
});
test('storage failure stops before sending a mutation', () => {
  const f = fixture();
  const journal = createSwitchReceipts({ registry: f.registry, save() { throw Error('disk full'); } });
  assert.throws(() => journal.begin('f', intent), /disk full/);
});
test('only a matching post-switch native turn proves a reply, never semantic correctness', () => {
  const f = fixture(), r = f.journal.begin('f', intent);
  f.journal.dispatch(r, 'one', 'create');
  f.journal.settle({ id: 'one', result: { thread: { id: 'b' } } });
  f.journal.patch(r, { phase: 'committed' });
  const p = { threadId: 'b', turn: { id: 'turn', status: 'completed', items: [{ type: 'agentMessage', text: 'ok' }] } };
  assert.equal(f.journal.observeTurn(p, 'turn/completed'), false);
  assert.equal(f.journal.observeTurn(p, 'turn/started'), true);
  assert.equal(f.journal.observeTurn({ ...p, threadId: 'a' }, 'turn/completed'), false);
  assert.equal(f.journal.observeTurn(p, 'turn/completed'), true);
  assert.equal(r.continuation, 'reply_observed');
  assert.equal(r.semanticHandoff, undefined);
});
test('same title or shared directory never establishes family ownership', () => {
  const registry = { threadToFamily: { a: 'f', b: 'g' }, families: { f: { providers: { openai: 'a', zai: 'b' } } } };
  const a = { id: 'a', cwd: 'C:\\shared', name: 'Same' }, b = { id: 'b', cwd: 'C:\\shared', name: 'Same' };
  assert.throws(() => assertPairIdentity(a, b, registry, 'f', 'zai'), /family/);
  registry.threadToFamily.b = 'f';
  assertPairIdentity(a, b, registry, 'f', 'zai');
  assert.throws(() => assertPairIdentity(a, { ...b, cwd: 'C:\\other' }, registry, 'f', 'zai'), /workspaces/);
  assert.throws(() => assertPairIdentity(a, { ...b, modelProvider: 'openai' }, registry, 'f', 'zai'), /provider/);
  assert.throws(() => assertPairIdentity({ ...a, projectId: 'P1' }, { ...b, projectId: 'P2' }, registry, 'f', 'zai'), /project identities/);
});
