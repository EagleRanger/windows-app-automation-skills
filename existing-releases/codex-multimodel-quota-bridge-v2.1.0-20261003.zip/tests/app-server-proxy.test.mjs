import assert from "node:assert/strict";
import test from "node:test";
import { createAppServerRouter } from "../scripts/app-server-proxy-core.mjs";

const router = () => createAppServerRouter({
  defaultProvider: "openai",
  providerByModel: {
    "glm-5.3-flash": "zai",
    "deepseek-flash": "deepseek",
  },
});

test("new external tasks and resumes carry their actual provider", () => {
  const subject = router();
  const start = { id: 1, method: "thread/start", params: { model: "glm-5.3-flash" } };
  assert.equal(subject.route(start).forward.params.modelProvider, "zai");
  subject.observe({ id: 1, result: { thread: { id: "glm-task", model: "glm-5.3-flash" } } });
  const resume = { id: 2, method: "thread/resume", params: { threadId: "glm-task" } };
  assert.equal(subject.route(resume).forward.params.modelProvider, "zai");
});

test("cross-provider model selection signals handoff and leaves source model intact", () => {
  const subject = router();
  subject.route({ id: 1, method: "codex/provider-families/sync", params: {
    version: 1, providerByThreadId: { source: "zai" },
  } });
  const selected = subject.route({ id: 2, method: "thread/settings/update", params: {
    threadId: "source", model: "deepseek-flash", reasoningEffort: "high",
  } });
  assert.deepEqual(selected.reply, { id: 2, result: {} });
  assert.equal(selected.notifications[0].method, "codex/provider-switch-request");
  assert.equal(selected.notifications[0].params.provider, "deepseek");
  const same = subject.route({ id: 3, method: "thread/resume", params: { threadId: "source" } });
  assert.equal(same.forward.params.modelProvider, "zai");
  const stale = subject.route({ id: 4, method: "thread/resume", params: {
    threadId: "source", model: "deepseek-flash", reasoningEffort: "high",
  } });
  assert.equal(stale.forward.params.modelProvider, "zai");
  assert.equal(stale.forward.params.model, undefined);
  assert.equal(stale.forward.params.reasoningEffort, undefined);
});

test("full settings snapshot preserves access update without forwarding external model", () => {
  const subject = router();
  const selected = subject.route({ id: 1, method: "thread/settings/update", params: {
    threadId: "openai-task", model: "deepseek-flash", approvalPolicy: "never",
  } });
  assert.equal(selected.forward.params.model, undefined);
  assert.equal(selected.forward.params.approvalPolicy, "never");
  assert.equal(selected.notifications.length, 1);
});

test("same-provider selection and model list pass through", () => {
  const subject = router();
  subject.route({ id: 1, method: "codex/provider-families/sync", params: {
    version: 1, providerByThreadId: { source: "deepseek" },
  } });
  const selected = subject.route({ id: 2, method: "thread/settings/update", params: {
    threadId: "source", model: "deepseek-flash",
  } });
  assert.equal(selected.notifications.length, 0);
  assert.equal(selected.forward.params.model, "deepseek-flash");
  const listed = subject.route({ id: 3, method: "thread/list", params: { modelProviders: ["openai"] } });
  assert.deepEqual(listed.forward.params.modelProviders, []);
});

test("provider sync validates identity and router status is read-only", () => {
  const subject = router();
  const bad = subject.route({ id: 1, method: "codex/provider-families/sync", params: {
    version: 1, providerByThreadId: { source: "unknown" },
  } });
  assert.equal(bad.reply.error.code, -32602);
  const status = subject.route({ id: 2, method: "codex/provider-router/status", params: {} });
  assert.equal(status.reply.result.status, "active");
  assert.equal(status.reply.result.counts.starts, 0);
});

test("scheduled turn model override cannot send GPT through the GLM slot", () => {
  const subject = router();
  subject.route({ id: 1, method: "codex/provider-families/sync", params: { version: 1, providerByThreadId: { source: "zai" } } });
  const result = subject.route({ id: 2, method: "turn/start", params: {
    threadId: "source", model: "gpt-6-sol", effort: "xhigh", input: [{ type: "text", text: "run once" }],
  } });
  assert.equal(result.forward, undefined);
  assert.equal(result.reply.error.code, -32602);
  assert.equal(result.notifications.length, 1);
  assert.equal(result.notifications[0].method, "codex/provider-switch-request");
  assert.equal(result.notifications[0].params.provider, "openai");
  assert.equal(result.notifications[0].params.settings.reasoningEffort, "xhigh");
});

test("same provider turns pass; collaboration model overrides cannot bypass provider identity", () => {
  const subject = router();
  subject.route({ id: 1, method: "codex/provider-families/sync", params: { version: 1, providerByThreadId: { source: "zai" } } });
  for (const method of ["turn/start", "turn/steer", "thread/queue/add"]) {
    const good = subject.route({ id: 2, method, params: { threadId: "source", model: "glm-5.3-flash" } });
    assert.equal(good.forward.method, method);
    const bad = subject.route({ id: 3, method, params: { threadId: "source", collaborationMode: { settings: { model: "gpt-6-luna" } } } });
    assert.equal(bad.forward, undefined);
    assert.ok(bad.reply.error);
  }
});
