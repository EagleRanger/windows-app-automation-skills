import assert from "node:assert/strict";
import test from "node:test";
import {
  selectCodexAppPages,
  selectCodexTaskPage,
} from "../vendor/codex-model-picker/src/devtools.mjs";
import { createCdpClient } from "../vendor/codex-model-picker/src/cdp-client.mjs";

test("renderer injection selects the active Codex task page before overlays", () => {
  const selected = selectCodexTaskPage([
    { type: "page", url: "app://-/index.html?initialRoute=%2Favatar-overlay", webSocketDebuggerUrl: "ws://overlay" },
    { type: "page", url: "app://-/detached-window.html?initialRoute=%2Fdetached-window", webSocketDebuggerUrl: "ws://detached" },
    { type: "page", url: "app://-/index.html", webSocketDebuggerUrl: "ws://task" },
  ]);
  assert.equal(selected.webSocketDebuggerUrl, "ws://task");
});

test("hot updates cover every Codex application page, including detached windows", () => {
  const pages = selectCodexAppPages([
    { type: "webview", url: "https://example.invalid", webSocketDebuggerUrl: "ws://webview" },
    { type: "page", url: "app://-/index.html", webSocketDebuggerUrl: "ws://task" },
    { type: "page", url: "app://-/index.html?initialRoute=%2Favatar-overlay", webSocketDebuggerUrl: "ws://overlay" },
    { type: "page", url: "app://-/detached-window.html?initialRoute=%2Fdetached-window", webSocketDebuggerUrl: "ws://detached" },
  ]);
  assert.deepEqual(
    pages.map((page) => page.webSocketDebuggerUrl),
    ["ws://task", "ws://overlay", "ws://detached"],
  );
});

test("renderer injection has a bounded fallback when only an overlay exists", () => {
  const selected = selectCodexTaskPage([
    { type: "webview", url: "https://example.invalid", webSocketDebuggerUrl: "ws://webview" },
    { type: "page", url: "app://-/index.html?initialRoute=%2Favatar-overlay", webSocketDebuggerUrl: "ws://overlay" },
  ]);
  assert.equal(selected.webSocketDebuggerUrl, "ws://overlay");
});

test("CDP client keeps an immediate renderer response", async () => {
  class ImmediateSocket {
    constructor() { this.listeners = new Map(); queueMicrotask(() => this.emit("open", {})); }
    addEventListener(type, callback) { this.listeners.set(type, callback); }
    emit(type, payload) { this.listeners.get(type)?.(payload); }
    send(raw) {
      const request = JSON.parse(raw);
      this.emit("message", { data: JSON.stringify({ id: request.id, result: { ok: true } }) });
    }
    close() {}
  }
  const cdp = createCdpClient("ws://fixture", ImmediateSocket);
  await cdp.opened;
  assert.deepEqual(await cdp.send("Runtime.evaluate"), { ok: true });
});
