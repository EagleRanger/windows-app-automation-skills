import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

test('native audit detects a lost active original but permits archived historical tasks', () => {
  const root = mkdtempSync(join(tmpdir(), 'picker-audit-'));
  try {
    execFileSync('python', ['-c', `import sqlite3,sys
c=sqlite3.connect(sys.argv[1])
c.execute('create table threads(id,name,cwd,model_provider,archived,rollout_path)')
for i,a,p in [('original',0,'openai'),('new',0,'openai'),('glm',1,'zai'),('old',1,'openai')]:
 c.execute('insert into threads values(?,?,?,?,?,?)',(i,'Packaging',sys.argv[2],p,a,'missing'))
c.commit()`, join(root,'state_5.sqlite'), root], { windowsHide: true });
    const run = mappedIds => JSON.parse(execFileSync('python', ['-X','utf8',fileURLToPath(new URL('../scripts/verify-native-task-catalog.py', import.meta.url))], {input:JSON.stringify({codexHome:root,mappedIds,sidebarRows:[],familyIds:['original']}),encoding:'utf8',windowsHide:true}));
    assert.deepEqual(run(['new','glm'])._unmappedActivePeers.map(r=>r.id), ['original']);
    assert.deepEqual(run(['original','new','glm'])._unmappedActivePeers, []);
  } finally { rmSync(root, {recursive:true,force:true}); }
});
