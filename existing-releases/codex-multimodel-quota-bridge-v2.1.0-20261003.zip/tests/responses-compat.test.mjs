import assert from "node:assert/strict";
import { Readable } from "node:stream";
import test from "node:test";
import {
  DEEPSEEK_INPUT_SOFT_LIMIT_BYTES,
  createSseEventWatchdog,
  createSseSanitizer,
  finishAfterStreamFailure,
  measureRequest,
  normalize,
  sanitizeExecCommandArguments,
} from "../scripts/responses-compat.mjs";

test("compatibility layer preserves paired tool calls and converts only orphan outputs", () => {
  const source = { model: "deepseek-flash", input: [
    { type: "function_call_output", namespace: "codex_app", name: "send_message_to_thread", output: "continue" },
    { type: "function_call", call_id: "call-1", name: "read", arguments: "{}" },
    { type: "function_call_output", call_id: "call-1", output: "ok" },
  ], tools: [{ type: "function", name: "x", parameters: { oneOf: [{ type: "object" }] } }] };
  const before = JSON.stringify(source);
  const result = normalize(source);
  assert.equal(JSON.stringify(source), before);
  assert.equal(result.body.input[0].type, "message");
  assert.match(result.body.input[0].content[0].text, /continue/);
  assert.deepEqual(result.body.input.slice(1), source.input.slice(1));
  assert.equal(result.body.tools[0].parameters.type, "object");
  assert.deepEqual(normalize(result.body).body, result.body);
});

test("compatibility layer turns restored calls without outputs into safe history", () => {
  const source = { model: "deepseek-flash", input: [
    { type: "function_call", call_id: "call-complete", name: "read", arguments: "{}" },
    { type: "function_call_output", call_id: "call-complete", output: "ok" },
    { type: "function_call", call_id: "call-stale", name: "exec_command", arguments: "{}" },
  ] };
  const result = normalize(source);
  assert.deepEqual(result.body.input.slice(0, 2), source.input.slice(0, 2));
  assert.equal(result.body.input[2].type, "message");
  assert.equal(result.body.input[2].role, "user");
  assert.match(result.body.input[2].content[0].text, /exec_command/);
  assert.equal(result.stats.unpairedCalls, 1);
  assert.deepEqual(normalize(result.body).body, result.body);
});

test("compatibility layer keeps parallel tool outputs together across Codex developer notices", () => {
  const resizeNotice = {
    type: "message",
    role: "developer",
    content: [{ type: "input_text", text: "<image_resize_notice>resized</image_resize_notice>" }],
  };
  const source = { model: "deepseek-flash", input: [
    { type: "function_call", call_id: "call-image", name: "view_image", arguments: "{}" },
    { type: "function_call", call_id: "call-command", name: "exec_command", arguments: "{}" },
    { type: "function_call_output", call_id: "call-image", output: [{ type: "input_image", image_url: "data:image/png;base64,AA==" }] },
    resizeNotice,
    { type: "function_call_output", call_id: "call-command", output: "exit 0" },
    { type: "message", role: "assistant", content: [{ type: "output_text", text: "done" }] },
  ] };

  const result = normalize(source);
  assert.deepEqual(result.body.input.map((item) => item.call_id || item.role), [
    "call-image",
    "call-command",
    "call-image",
    "call-command",
    "developer",
    "assistant",
  ]);
  assert.equal(result.stats.interleavedToolItems, 1);
  assert.deepEqual(normalize(result.body).body, result.body);
});

test("compatibility layer constrains DeepSeek exec waits to the Windows runtime limit", () => {
  const source = { model: "deepseek-flash", tools: [
    { type: "custom", name: "exec", description: "Run JavaScript." },
    { type: "function", name: "exec_command", parameters: { type: "object", properties: {
      yield_time_ms: { type: "integer" },
    } } },
  ] };

  const result = normalize(source);
  assert.match(result.body.tools[0].description, /10000-30000/);
  assert.match(result.body.tools[0].description, /tools\.write_stdin/);
  assert.equal(result.body.tools[1].parameters.properties.yield_time_ms.minimum, 10_000);
  assert.equal(result.body.tools[1].parameters.properties.yield_time_ms.maximum, 30_000);
  assert.equal(result.stats.execGuardrails, 2);
  assert.deepEqual(normalize(result.body).body, result.body);
});

test("stream sanitizer force-clamps oversized exec_command waits across fragmented deltas", async () => {
  const original = JSON.stringify({ cmd: "echo ok", yield_time_ms: 600000, max_output_tokens: 4 });
  const events = [
    ["response.output_item.added", { type: "response.output_item.added", sequence_number: 1, output_index: 0, item: { id: "fc-1", type: "function_call", name: "exec_command", arguments: "" } }],
    ["response.function_call_arguments.delta", { type: "response.function_call_arguments.delta", sequence_number: 2, output_index: 0, item_id: "fc-1", delta: original.slice(0, 31) }],
    ["response.function_call_arguments.delta", { type: "response.function_call_arguments.delta", sequence_number: 3, output_index: 0, item_id: "fc-1", delta: original.slice(31) }],
    ["response.function_call_arguments.done", { type: "response.function_call_arguments.done", sequence_number: 4, output_index: 0, item_id: "fc-1", arguments: original }],
    ["response.output_item.done", { type: "response.output_item.done", sequence_number: 5, output_index: 0, item: { id: "fc-1", type: "function_call", name: "exec_command", arguments: original } }],
    ["response.completed", { type: "response.completed", sequence_number: 6, response: { output: [{ id: "fc-1", type: "function_call", name: "exec_command", arguments: original }] } }],
  ];
  const sse = events.map(([name, data]) => encodeURIComponent(`event: ${name}\ndata: ${JSON.stringify(data)}\n\n`)).map(decodeURIComponent).join("");
  let clampCount = 0;
  let output = "";
  const source = Readable.from([sse.slice(0, 137), sse.slice(137, 311), sse.slice(311)]);
  for await (const chunk of source.pipe(createSseSanitizer(() => { clampCount += 1; }))) output += chunk;

  assert.equal(clampCount, 1);
  assert.doesNotMatch(output, /600000/);
  assert.match(output, /30000/);
  const deltaData = output.split("\n\n")
    .map((block) => block.split("\n").find((line) => line.startsWith("data: "))?.slice(6))
    .filter(Boolean)
    .map(JSON.parse)
    .find((event) => event.type === "response.function_call_arguments.delta");
  assert.equal(JSON.parse(deltaData.delta).yield_time_ms, 30_000);
});

test("argument sanitizer preserves valid waits and clamps both ends of the runtime range", () => {
  assert.equal(JSON.parse(sanitizeExecCommandArguments('{"yield_time_ms":30000}').arguments).yield_time_ms, 30_000);
  assert.equal(JSON.parse(sanitizeExecCommandArguments('{"yield_time_ms":900000}').arguments).yield_time_ms, 30_000);
  assert.equal(JSON.parse(sanitizeExecCommandArguments('{"yield_time_ms":1}').arguments).yield_time_ms, 10_000);
});

test("premature SSE closes end the client response instead of destroying its composer state", () => {
  const response = {
    headersSent: true,
    destroyed: false,
    writableEnded: false,
    ended: 0,
    destroyedWith: null,
    end() { this.ended += 1; this.writableEnded = true; },
    destroy(error) { this.destroyedWith = error; },
  };
  assert.equal(finishAfterStreamFailure(response), "clean-eof");
  assert.equal(response.ended, 1);
  assert.equal(response.destroyedWith, null);
});

test("stream failures before response headers remain explicit 502 errors", () => {
  const response = {
    headersSent: false,
    destroyed: false,
    writableEnded: false,
    status: null,
    body: null,
    writeHead(status) { this.status = status; },
    end(body) { this.body = body; this.writableEnded = true; },
  };
  assert.equal(finishAfterStreamFailure(response), "json-error");
  assert.equal(response.status, 502);
  assert.match(response.body, /Local compatibility stream failed/);
});

test("request meter logs history pressure without inventing a token hard stop", () => {
  const measured = measureRequest({
    input: [{ type: "message", role: "user", content: "x".repeat(DEEPSEEK_INPUT_SOFT_LIMIT_BYTES + 1) }],
    instructions: "stable",
    tools: [{ type: "function", name: "read" }],
  });
  assert.equal(measured.overSoftLimit, true);
  assert.equal("overHardLimit" in measured, false);
  assert.ok(measured.inputBytes > measured.instructionsBytes);
  assert.ok(measured.inputBytes > measured.toolsBytes);
});

test("SSE event watchdog fails a silent stream instead of hanging indefinitely", async () => {
  const watchdog = createSseEventWatchdog(15);
  const source = new Readable({ read() {} });
  await assert.rejects(async () => {
    for await (const _chunk of source.pipe(watchdog)) {}
  }, /DeepSeek model-event idle timeout/);
});

test("SSE event watchdog ignores transport keepalives without model data", async () => {
  const watchdog = createSseEventWatchdog(20);
  const source = new Readable({ read() {} });
  const keepalive = setInterval(() => source.push(": keepalive\n\n"), 4);
  try {
    await assert.rejects(async () => {
      for await (const _chunk of source.pipe(watchdog)) {}
    }, /DeepSeek model-event idle timeout/);
  } finally {
    clearInterval(keepalive);
  }
});
