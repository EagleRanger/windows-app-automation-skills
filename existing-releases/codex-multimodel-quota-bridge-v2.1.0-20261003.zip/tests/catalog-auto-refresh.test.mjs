import test from "node:test";
import assert from "node:assert/strict";
import { startCatalogAutoRefresh } from "../scripts/catalog-auto-refresh.mjs";

test("automatic refresh is single-flight, retains errors, and stops without retrying", async () => {
  let tick;
  let calls = 0;
  let resolveFirst;
  const first = new Promise(resolve => { resolveFirst = resolve; });
  const watcher = startCatalogAutoRefresh({
    home: "test-home", intervalMs: 60_000,
    sync: async () => { calls++; if (calls === 1) return first; throw Error("offline"); },
    setIntervalImpl: callback => { tick = callback; return { unref() {} }; },
    clearIntervalImpl: () => {},
  });
  const joined = watcher.refresh(); tick();
  assert.equal(calls, 1);
  resolveFirst({ models: ["gpt-6-sol", "gpt-6.1-sol"], changed: true });
  await joined;
  assert.equal(watcher.status.modelCount, 2);
  assert.ok(watcher.status.lastChangedAt);
  await watcher.refresh();
  assert.equal(watcher.status.lastError, "offline");
  watcher.stop(); tick();
  assert.equal(calls, 2);
});
