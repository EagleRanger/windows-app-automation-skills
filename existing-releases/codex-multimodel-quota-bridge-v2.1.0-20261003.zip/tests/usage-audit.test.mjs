import test from 'node:test';
import assert from 'node:assert/strict';
import { auditUsage } from '../scripts/usage-audit.mjs';

const before = '2026-09-10T00:00:00Z', now = '2026-09-12T00:00:00Z';
const window = { since: Date.parse('2026-09-11T00:00:00Z'), until: Date.parse('2026-09-13T00:00:00Z') };
const usage = (n) => ({ input_tokens:n, cached_input_tokens:n/2, output_tokens:n/10, reasoning_output_tokens:n/20, total_tokens:n*1.1 });
// Avoid floating point fixture artifacts in total_tokens.
const u = n => ({ ...usage(n), total_tokens: n + n/10 });
const meta = { type:'session_meta', payload:{ id:'root', cwd:'C:/project', timestamp:before } };
const ctx = (model='gpt-5.6-terra', effort='high') => ({ type:'turn_context', payload:{ model, effort, turn_id:model } });
const event = (n, last=n, timestamp=now) => ({ timestamp, type:'event_msg', payload:{ type:'token_count', info:{ total_token_usage:u(n), last_token_usage:u(last) } } });
const stream = records => ({ name:'a', records });

test('event time filtering preserves the pre-window baseline and ignores repeats', async () => {
  const r = await auditUsage([stream([meta,ctx(),event(1000,1000,before),event(1200,200),event(1200,200)])],window);
  assert.equal(r.rows[0].total,220);
  assert.equal(r.rows[0].cached,100);
  assert.equal(r.rows[0].uncached,100);
  assert.equal(r.diagnostics.duplicates,1);
});
test('same-size consecutive responses count when cumulative counters grow', async () => {
  const r = await auditUsage([stream([meta,ctx(),event(200),event(400,200)])],window);
  assert.equal(r.rows[0].events,2); assert.equal(r.rows[0].total,440);
});
test('models, effort and projects remain separate', async () => {
  const other = {type:'session_meta',payload:{id:'other',cwd:'C:/other',timestamp:before}};
  const r=await auditUsage([stream([meta,ctx(),event(200),ctx('deepseek-flash'),event(400,200),ctx('deepseek-flash','low'),event(600,200)]),stream([other,ctx(),event(200)])],window);
  assert.equal(r.rows.length,4); assert.equal(r.rows.reduce((n,x)=>n+x.total,0),880);
});
test('copied session log is deduplicated', async () => {
  const records=[meta,ctx(),event(200),event(400,200)];
  const r=await auditUsage([stream(records),{name:'copy',records}],window);
  assert.equal(r.rows[0].total,440); assert.equal(r.diagnostics.duplicates,2);
});
test('child inherited history is not charged to the child', async () => {
  const child={type:'session_meta',payload:{id:'child',parent_thread_id:'root',cwd:'C:/project',timestamp:'2026-09-11T12:00:00Z'}};
  const r=await auditUsage([stream([child,ctx('gpt-6-astra'),event(1000,1000,'2026-09-11T01:00:00Z'),ctx(),event(1200,200)])],window);
  assert.equal(r.rows[0].total,220); assert.equal(r.rows[0].model,'gpt-5.6-terra');
  assert.equal(r.rows[0].parentThread,'root'); assert.equal(r.diagnostics.inheritedRecords,1);
});
test('first baseline and reset use last usage rather than whole cumulative history',async()=>{
  const r=await auditUsage([stream([meta,ctx(),event(1000,200),event(100,100)])],window);
  assert.equal(r.rows[0].total,330); assert.equal(r.diagnostics.rebasedCounters,2);
});
test('missing counters, invalid subsets and timestamps are not fabricated as usage',async()=>{
  const missing=event(100); delete missing.payload.info.total_token_usage;
  const invalid=event(100); invalid.payload.info.total_token_usage.cached_input_tokens=200;
  const r=await auditUsage([stream([meta,ctx(),missing,invalid,event(100,100,'invalid')])],window);
  assert.equal(r.rows.length,0); assert.equal(r.diagnostics.missingCounters,2); assert.equal(r.diagnostics.invalidRecords,1);
});
