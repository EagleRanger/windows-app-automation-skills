import assert from "node:assert/strict";
import test from "node:test";
import { rebindHeartbeatAutomations } from "../vendor/codex-model-picker/src/automation-rebind.mjs";

const item = id => ({ id, kind: "heartbeat", name: id, prompt: "Do work", status: "ACTIVE",
  rrule: "RRULE:FREQ=DAILY;BYHOUR=12", targetThreadId: "source" });

test("moves only heartbeats bound to the source, preserving their contract", async () => {
  const rows = [item("one"), { ...item("other"), targetThreadId: "unrelated" },
    { ...item("cron"), kind: "cron" }];
  const result = await rebindHeartbeatAutomations({
    sourceThreadId: "source", targetThreadId: "target",
    listAutomations: async () => ({ items: rows.map(row => ({ ...row })) }),
    updateAutomation: async value => Object.assign(rows.find(row => row.id === value.id), value),
  });
  assert.deepEqual(result, { ids: ["one"], moved: 1 });
  assert.equal(rows[0].targetThreadId, "target");
  assert.equal(rows[1].targetThreadId, "unrelated");
  assert.equal(rows[2].targetThreadId, "source");
});

test("failure on a later heartbeat rolls an earlier move back to the source", async () => {
  const rows = [item("one"), item("two")];
  await assert.rejects(rebindHeartbeatAutomations({
    sourceThreadId: "source", targetThreadId: "target",
    listAutomations: async () => ({ items: rows.map(row => ({ ...row })) }),
    updateAutomation: async value => {
      if (value.id === "two" && value.targetThreadId === "target") throw new Error("offline");
      Object.assign(rows.find(row => row.id === value.id), value);
    },
  }), error => error.rollbackVerified === true);
  assert.deepEqual(rows.map(row => row.targetThreadId), ["source", "source"]);
});

test("unverified rollback is explicit and cannot be reported as a safe switch", async () => {
  const rows = [item("one"), item("two")];
  await assert.rejects(rebindHeartbeatAutomations({
    sourceThreadId: "source", targetThreadId: "target",
    listAutomations: async () => ({ items: rows.map(row => ({ ...row })) }),
    updateAutomation: async value => {
      if (value.id === "two" || value.targetThreadId === "source") throw new Error("offline");
      Object.assign(rows.find(row => row.id === value.id), value);
    },
  }), error => error.rollbackVerified === false && /binding needs inspection/.test(error.message));
  assert.equal(rows[0].targetThreadId, "target");
});

test('multiple heartbeats preserve nested notification policy and recheck all bindings', async () => {
  const rows = [item('one'), { ...item('two'), notificationPolicy: { notifyOn: ['failure'], quiet: true } }];
  let checkpoint;
  await rebindHeartbeatAutomations({ sourceThreadId: 'source', targetThreadId: 'target',
    listAutomations: async () => ({ items: structuredClone(rows) }),
    updateAutomation: async value => Object.assign(rows.find(row => row.id === value.id), value),
    writeCheckpoint: value => { checkpoint = value; },
  });
  assert.equal(checkpoint.status, 'confirmed');
  assert.equal(checkpoint.entries.length, 2);
  assert.equal(JSON.stringify(checkpoint).includes('Do work'), false);
  assert.deepEqual(rows[1].notificationPolicy, { notifyOn: ['failure'], quiet: true });
});

test('restart reconciles previously moved heartbeat without replay and rolls back the whole group on later failure', async () => {
  const rows = [item('one'), item('two')];
  let checkpoint;
  // Capture the pre-mutation durable checkpoint; simulate a process exit after moving one.
  await assert.rejects(rebindHeartbeatAutomations({ sourceThreadId: 'source', targetThreadId: 'target',
    listAutomations: async () => ({ items: structuredClone(rows) }),
    updateAutomation: async () => {},
    writeCheckpoint: value => { if (!checkpoint) checkpoint = value; throw Error('simulated exit'); },
  }));
  rows[0].targetThreadId = 'target';
  const updates = [];
  await assert.rejects(rebindHeartbeatAutomations({ sourceThreadId: 'source', targetThreadId: 'target',
    readCheckpoint: () => checkpoint, writeCheckpoint: value => { checkpoint = value; },
    listAutomations: async () => ({ items: structuredClone(rows) }),
    updateAutomation: async value => {
      updates.push(value.id + ':' + value.targetThreadId);
      if (value.id === 'two' && value.targetThreadId === 'target') throw Error('network failure');
      Object.assign(rows.find(row => row.id === value.id), value);
    },
  }), error => error.rollbackVerified === true);
  assert.deepEqual(rows.map(row => row.targetThreadId), ['source', 'source']);
  assert.equal(updates.includes('one:target'), false);
  assert.equal(checkpoint.status, 'rolled_back');
});

test('a new source-bound heartbeat appearing mid-migration prevents success', async () => {
  const rows = [item('one')];
  let added = false;
  await assert.rejects(rebindHeartbeatAutomations({ sourceThreadId: 'source', targetThreadId: 'target',
    listAutomations: async () => ({ items: structuredClone(rows) }),
    updateAutomation: async value => {
      Object.assign(rows.find(row => row.id === value.id), value);
      if (!added) { rows.push(item('new')); added = true; }
    },
  }), error => error.rollbackVerified === true);
  assert.ok(rows.every(row => row.targetThreadId === 'source'));
});
