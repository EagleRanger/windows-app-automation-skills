import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { fetchOfficialCatalog, readOfficialCache, replaceOpenAiModels, syncOpenAiCatalog, validateOfficialCatalog } from "../scripts/openai-catalog.mjs";
const model = (slug, visibility = "list") => ({ slug, display_name: slug, supported_reasoning_levels: [], visibility });
const latest = { models: [model("gpt-6-sol"), model("gpt-6.1-sol"), model("gpt-6-luna"), model("gpt-reserve", "hide")] };
test("replaces old OpenAI catalog exactly, retaining external metadata and hidden flag", () => {
 const ds = { slug:"deepseek-flash", context_window:131072 }; const glm = {slug:"glm-5.3-flash", input_modalities:["text","image"]};
 const x = replaceOpenAiModels({models:[model("gpt-5.4"),ds,glm]},latest);
 assert.deepEqual(x.models, [...latest.models,ds,glm]); assert.equal(x.models[3].visibility,"hide");
});
test("rejects invalid or foreign official payload before replacement", () => {
 for (const x of [{models:[]},{models:[model("deepseek-flash")]},{models:[model("gpt-6-sol"),model("gpt-6-sol")]}]) assert.throws(()=>validateOfficialCatalog(x));
});
async function home(fn){const d=await mkdtemp(join(tmpdir(),"picker-catalog-test-"));try{
 await writeFile(join(d,"auth.json"),JSON.stringify({auth_mode:"chatgpt",tokens:{access_token:"TEST_ONLY",account_id:"TEST_ACCOUNT"}}));
 await writeFile(join(d,"deepseek-picker-models.json"),JSON.stringify({models:[model("gpt-5.4"),{slug:"glm-5.3"}]}));await fn(d);
}finally{await rm(d,{recursive:true,force:true})}}
test("official request is direct, redirect-blocked, bounded, and retains authentic metadata",async()=>home(async d=>{
 const fetched = await fetchOfficialCatalog(d,{clientVersion:"1.2.3",fetchImpl:async(url,opts)=>{
 assert.equal(url,"https://chatgpt.com/backend-api/codex/models?client_version=1.2.3");assert.equal(opts.redirect,"error");assert.ok(opts.signal);assert.equal(opts.headers.Authorization,"Bearer TEST_ONLY");return {ok:true,json:async()=>latest};}});
 assert.deepEqual(fetched,latest);const cache=await readOfficialCache(d);assert.deepEqual(cache.models,latest.models);assert.ok(!JSON.stringify(cache).includes("TEST_ONLY"));
}));
test("network or malformed response never replaces the working catalog",async()=>home(async d=>{
 const p=join(d,"deepseek-picker-models.json"),before=await readFile(p,"utf8");
 for(const fetchImpl of [async()=>{throw Error("offline")},async()=>({ok:false,status:401}),async()=>({ok:true,json:async()=>({models:[]})})]){
 await assert.rejects(()=>syncOpenAiCatalog(d,{clientVersion:"1",fetchImpl}));assert.equal(await readFile(p,"utf8"),before);}
}));
test("replacement keeps external models and provides a reusable offline snapshot",async()=>home(async d=>{
 const x=await syncOpenAiCatalog(d,{clientVersion:"1",fetchImpl:async()=>({ok:true,json:async()=>latest})});assert.equal(x.externalModelsPreserved,1);assert.equal(x.changed,true);assert.deepEqual((await readOfficialCache(d)).models,latest.models);
 assert.deepEqual(JSON.parse(await readFile(join(d,"deepseek-picker-models.json"),"utf8")).models.map(m=>m.slug),["gpt-6-sol","gpt-6.1-sol","gpt-6-luna","gpt-reserve","glm-5.3"]);
 const before=await readFile(join(d,"deepseek-picker-models.json"),"utf8");
 const repeated=await syncOpenAiCatalog(d,{clientVersion:"1",fetchImpl:async()=>({ok:true,json:async()=>latest})});
 assert.equal(repeated.changed,false);assert.equal(await readFile(join(d,"deepseek-picker-models.json"),"utf8"),before);
}));
