import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { executeSubagentSpec, normalizeSpec } from "../scripts/subagent-dispatch.mjs";

test("default route preserves GLM first and prioritizes GPT-6.1 Sol among OpenAI candidates", () => {
  const spec = normalizeSpec({ version: 1, task: "bounded work" });
  assert.deepEqual(spec.candidates, [
    { provider: "zai", model: "glm-5.3-flash", effort: "high" },
    { provider: "deepseek", model: "deepseek-flash", effort: "high" },
    { provider: "openai", model: "gpt-6.1-sol", effort: "high" },
    { provider: "openai", model: "gpt-6-luna", effort: "high" },
  ]);
});

test("explicit model and effort override the default route while candidates remain bounded", () => {
  const candidates = [{ provider: "zai", model: "glm-5.3", effort: "low" }];
  assert.deepEqual(normalizeSpec({ version: 1, task: "bounded work", candidates }).candidates, candidates);
  assert.throws(() => normalizeSpec({ version: 1, task: "bounded work", candidates: Array(5).fill(candidates[0]) }), /1 至 4/);
});

test("falls through only when thread creation fails and returns the verified route", async () => {
  const cwd = await mkdtemp(join(tmpdir(), "subagent-dispatch-"));
  const calls = [];
  const audits = [];
  const fake = {
    request: async (method, params) => {
      calls.push({ method, params });
      if (method === "initialize") return {};
      if (method === "thread/start" && params.modelProvider !== "openai") throw new Error("provider unavailable");
      if (method === "thread/start") return { thread: { id: "child-1", modelProvider: params.modelProvider, model: params.model } };
      if (method === "turn/start") return { turn: { id: "turn-1" } };
      throw new Error(`unexpected ${method}`);
    },
    notify: () => {},
    waitFor: async () => ({ method: "turn/completed", params: { threadId: "child-1", turn: { id: "turn-1", status: "completed", items: [{ type: "agentMessage", text: "progress", phase: "commentary" }, { type: "agentMessage", text: "done", phase: "final_answer" }] } } }),
    close: () => {},
  };
  try {
    const result = await executeSubagentSpec(
      { version: 1, task: "bounded work", cwd },
      { makeClient: () => fake, writeAudit: async (record) => { audits.push(record); return "audit.json"; } },
    );
    assert.equal(result.provider, "openai");
    assert.equal(result.model, "gpt-6.1-sol");
    assert.equal(result.startFailures.length, 2);
    assert.deepEqual(calls.filter((call) => call.method === "thread/start").map((call) => call.params.model), ["glm-5.3-flash", "deepseek-flash", "gpt-6.1-sol"]);
    assert.equal(result.reply, "done");
    assert.equal(result.auditPath, "audit.json");
    assert.equal(audits[0].provider, "openai");
    assert.equal(audits[0].model, "gpt-6.1-sol");
    assert.equal(audits[0].taskChars, "bounded work".length);
    assert.equal("task" in audits[0], false);
    assert.equal(calls.filter((call) => call.method === "turn/start").length, 1);
  } finally {
    await rm(cwd, { recursive: true, force: true });
  }
});

test("does not replay a failed turn on the next provider", async () => {
  const cwd = await mkdtemp(join(tmpdir(), "subagent-dispatch-"));
  let starts = 0;
  const audits = [];
  const fake = {
    request: async (method, params) => {
      if (method === "initialize") return {};
      if (method === "thread/start") { starts += 1; return { thread: { id: "child-1", modelProvider: params.modelProvider, model: params.model } }; }
      if (method === "turn/start") return { turn: { id: "turn-1" } };
      throw new Error(`unexpected ${method}`);
    },
    notify: () => {},
    waitFor: async () => ({ method: "turn/completed", params: { threadId: "child-1", turn: { id: "turn-1", status: "failed", error: { message: "tool failed after write" } } } }),
    close: () => {},
  };
  try {
    await assert.rejects(
      () => executeSubagentSpec(
        { version: 1, task: "bounded work", cwd },
        { makeClient: () => fake, writeAudit: async (record) => { audits.push(record); return "audit.json"; } },
      ),
      /tool failed after write/,
    );
    assert.equal(starts, 1);
    assert.equal(audits[0].status, "failed_after_turn_start");
    assert.equal(audits[0].provider, "zai");
    assert.equal(audits[0].model, "glm-5.3-flash");
  } finally {
    await rm(cwd, { recursive: true, force: true });
  }
});

test('ambiguous thread creation acknowledgement never falls through to another provider', async () => {
  let starts = 0;
  const cwd = await mkdtemp(join(tmpdir(), 'worker-unknown-'));
  const fake = {
    request: async method => {
      if (method === 'initialize') return {};
      if (method === 'thread/start') { starts++; const error = Error('outcome unknown'); error.outcomeUnknown = true; throw error; }
      throw Error('unexpected call');
    }, notify() {}, close() {},
  };
  try {
    await assert.rejects(executeSubagentSpec({ version: 1, task: 'bounded work', cwd }, { makeClient: () => fake, writeAudit: async () => 'audit.json' }), /outcome unknown/);
    assert.equal(starts, 1);
  } finally { await rm(cwd, { recursive: true, force: true }); }
});
