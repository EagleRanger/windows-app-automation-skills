import test from "node:test";
import assert from "node:assert/strict";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { resolveCodexCli } from "../scripts/codex-cli.mjs";
import { getAppUserModelIdFromPath } from "../vendor/codex-model-picker/src/app-discovery.mjs";

const pluginRoot = fileURLToPath(new URL("..", import.meta.url));
const manager = join(pluginRoot, "scripts", "manager.mjs");

test("Windows PowerShell entry scripts keep their UTF-8 BOM", async () => {
  const scripts = [
    "codex-deepseek-token.ps1",
    "codex-zhipu-token.ps1",
    "launch-deepseek.ps1",
    "migrate-credentials.ps1",
    "run-handoff.ps1",
    "run-manager.ps1",
    "start-compat.ps1",
    "start-quota-dashboard.ps1",
    "switch-provider.ps1",
  ];
  for (const script of scripts) {
    const content = await readFile(join(pluginRoot, "scripts", script));
    assert.deepEqual([...content.subarray(0, 3)], [0xef, 0xbb, 0xbf], `${script} must remain UTF-8 BOM for Windows PowerShell 5.1`);
  }
});

test("Codex CLI discovery works with the minimal PATH used by desktop shortcuts", async () => {
  const parent = await mkdtemp(join(tmpdir(), "codex-cli-"));
  const executable = join(parent, "OpenAI", "Codex", "bin", "build-id", "codex.exe");
  await mkdir(join(parent, "OpenAI", "Codex", "bin", "build-id"), { recursive: true });
  await writeFile(executable, "test", "utf8");
  try {
    assert.equal(resolveCodexCli({
      env: { LOCALAPPDATA: parent, PATH: "" },
      platform: "win32",
    }), executable);
  } finally {
    await rm(parent, { recursive: true, force: true });
  }
});

test("packaged Codex paths resolve to the Windows application activation ID", () => {
  assert.equal(
    getAppUserModelIdFromPath("C:\\Program Files\\WindowsApps\\OpenAI.Codex_26.908.4834.0_x64__2p2nqsd0c76g0\\app\\ChatGPT.exe"),
    "OpenAI.Codex_2p2nqsd0c76g0!App",
  );
  assert.equal(getAppUserModelIdFromPath("C:\\Program Files\\OpenAI\\Codex\\ChatGPT.exe"), null);
});

function run(home, ...args) {
  const result = spawnSync(process.execPath, [manager, ...args, `--codex-home=${home}`], {
    encoding: "utf8",
  });
  assert.equal(result.status, 0, result.stderr || result.stdout);
  return result.stdout;
}

test("refresh, enable, and disable preserve unrelated config on a Chinese path", async () => {
  const parent = await mkdtemp(join(tmpdir(), "深度求索-"));
  const home = join(parent, ".codex");
  await mkdir(home, { recursive: true });
  const original = `service_tier = "default"\nmodel = "gpt-6-astra"\nmodel_reasoning_effort = "medium"\n\n[features]\nmemories = true\n\n[model_providers.deepseek]\nname = "DeepSeek"\nbase_url = "https://api.deepseek.com/"\nwire_api = "responses"\nenv_key = "DEEPSEEK_API_KEY"\n`;
  await writeFile(join(home, "config.toml"), original, "utf8");
  try {
    run(home, "refresh", "--offline");
    const catalog = JSON.parse(await readFile(join(home, "deepseek-picker-models.json"), "utf8"));
    assert.deepEqual(catalog.models.map((model) => model.slug), ["deepseek-flash", "deepseek-v4-pro"]);
    assert.equal(catalog.models[0].display_name, "DeepSeek V4.1 Flash");
    assert.equal(catalog.models[0].context_window, 131072);
    assert.equal(catalog.models[0].auto_compact_token_limit, 98304);
    assert.deepEqual(catalog.models[0].input_modalities, ["text", "image"]);
    assert.deepEqual(catalog.models[1].supported_reasoning_levels.map((item) => item.effort), ["low", "high", "max"]);

    run(home, "enable");
    let enabled = await readFile(join(home, "config.toml"), "utf8");
    assert.match(enabled, /^model = "deepseek-flash"$/m);
    assert.match(enabled, /^model_provider = "deepseek"$/m);
    assert.match(enabled, /^model_catalog_json = ".*deepseek-picker-models\.json"$/m);
    assert.match(enabled, /\[features\]\nmemories = true/);

    enabled += "\n[projects.'C:\\\\测试']\ntrust_level = \"trusted\"\n";
    await writeFile(join(home, "config.toml"), enabled, "utf8");
    run(home, "disable");
    const restored = await readFile(join(home, "config.toml"), "utf8");
    assert.match(restored, /^model = "gpt-6-astra"$/m);
    assert.match(restored, /^model_reasoning_effort = "medium"$/m);
    assert.doesNotMatch(restored, /^model_provider = /m);
    assert.doesNotMatch(restored, /^model_catalog_json = /m);
    assert.match(restored, /\[projects\.'C:\\\\测试'\]/);
  } finally {
    await rm(parent, { recursive: true, force: true });
  }
});

test("usage report streams session logs and attributes tokens to the active model", async () => {
  const parent = await mkdtemp(join(tmpdir(), "deepseek-usage-"));
  const home = join(parent, ".codex");
  const sessionDir = join(home, "sessions", "2026", "09", "12");
  await mkdir(sessionDir, { recursive: true });
  const timestamp = new Date().toISOString();
  const rows = [
    { timestamp, type: "turn_context", model: "deepseek-flash" },
    {
      timestamp,
      type: "event_msg",
      payload: {
        type: "token_count",
        info: {
          total_token_usage: {
            input_tokens: 1000, cached_input_tokens: 500, output_tokens: 100,
            reasoning_output_tokens: 20, total_tokens: 1100,
          },
          last_token_usage: {
            input_tokens: 1000,
            cached_input_tokens: 500,
            output_tokens: 100,
            reasoning_output_tokens: 20,
            total_tokens: 1100,
          },
        },
      },
    },
  ];
  await writeFile(join(sessionDir, "sample.jsonl"), `${rows.map((row) => JSON.stringify(row)).join("\n")}\n`, "utf8");
  try {
    const output = run(home, "usage", "--days=7");
    assert.match(output, /deepseek-flash \/ unknown：1 个用量事件，1,100 tokens/);
    assert.match(output, /非账户扣费/);
    assert.doesNotMatch(output, /DeepSeek 估算 \$/);
    const json = JSON.parse(run(home, "usage", "--days=7", "--json"));
    assert.equal(json.rows[0].uncached, 500);
    assert.equal(json.rows[0].cacheHitRate, 0.5);
  } finally {
    await rm(parent, { recursive: true, force: true });
  }
});

test("unified install migrates the old exclusive mode without replacing OpenAI defaults", async () => {
  const parent = await mkdtemp(join(tmpdir(), "统一模型-"));
  const home = join(parent, ".codex");
  await mkdir(home, { recursive: true });
  const original = `service_tier = "default"\nmodel = "gpt-6-astra"\nmodel_reasoning_effort = "medium"\n\n[features]\nmemories = true\n\n[model_providers.deepseek]\nname = "DeepSeek"\nbase_url = "https://api.deepseek.com/"\nwire_api = "responses"\nenv_key = "DEEPSEEK_API_KEY"\n`;
  const bundledPath = join(parent, "bundled.json");
  await writeFile(join(home, "config.toml"), original, "utf8");
  await writeFile(bundledPath, `${JSON.stringify({
    etag: "test-bundled",
    models: [{
      slug: "gpt-6-astra",
      display_name: "GPT-6-Astra",
      description: "Test OpenAI model",
      visibility: "list",
      priority: 1,
      supported_in_api: true,
    }],
  })}\n`, "utf8");
  try {
    run(home, "refresh", "--offline");
    run(home, "enable");
    run(home, "install", "--offline", `--bundled-catalog=${bundledPath}`);

    const installed = await readFile(join(home, "config.toml"), "utf8");
    assert.match(installed, /^model = "gpt-6-astra"$/m);
    assert.match(installed, /^model_reasoning_effort = "medium"$/m);
    assert.doesNotMatch(installed, /^model_provider = /m);
    assert.doesNotMatch(installed, /^preferred_auth_method = /m);
    assert.doesNotMatch(installed, /^forced_login_method = /m);
    assert.match(installed, /^model_catalog_json = ".*deepseek-picker-models\.json"$/m);
    assert.equal((installed.match(/\[model_providers\.deepseek\]/g) ?? []).length, 1);
    assert.match(installed, /\[model_providers\.deepseek\.auth\]/);
    assert.match(installed, /^command = "powershell\.exe"$/m);
    assert.doesNotMatch(installed, /^env_key = "DEEPSEEK_API_KEY"$/m);

    const catalog = JSON.parse(await readFile(join(home, "deepseek-picker-models.json"), "utf8"));
    assert.deepEqual(catalog.models.map((model) => model.slug), [
      "gpt-6-astra",
      "deepseek-flash",
      "deepseek-v4-pro",
    ]);
    assert.equal(catalog.models.find((model) => model.slug === "deepseek-flash").auto_compact_token_limit, 98304);
    assert.equal(catalog.models.find((model) => model.slug === "deepseek-v4-pro").auto_compact_token_limit, 98304);
    const routing = JSON.parse(await readFile(join(home, "desktop-model-providers.json"), "utf8"));
    assert.equal(routing.default_provider, "openai");
    assert.equal(routing.model_providers["deepseek-flash"], "deepseek");
    assert.equal(routing.model_providers["deepseek-v4-pro"], "deepseek");

    run(home, "uninstall");
    const restored = await readFile(join(home, "config.toml"), "utf8");
    assert.match(restored, /^model = "gpt-6-astra"$/m);
    assert.match(restored, /^model_reasoning_effort = "medium"$/m);
    assert.doesNotMatch(restored, /^model_catalog_json = /m);
    assert.equal((restored.match(/\[model_providers\.deepseek\]/g) ?? []).length, 1);
    assert.match(restored, /^env_key = "DEEPSEEK_API_KEY"$/m);
    assert.doesNotMatch(restored, /\[model_providers\.deepseek\.auth\]/);
    assert.match(restored, /\[features\]\nmemories = true/);
  } finally {
    await rm(parent, { recursive: true, force: true });
  }
});

test("Z.ai install is additive, uses DPAPI auth, and can be removed cleanly", async () => {
  const parent = await mkdtemp(join(tmpdir(), "zai-provider-"));
  const home = join(parent, ".codex");
  await mkdir(home, { recursive: true });
  const original = `model = "gpt-6-astra"\nmodel_reasoning_effort = "medium"\n\n[model_providers.deepseek]\nname = "DeepSeek"\nbase_url = "http://127.0.0.1:18779"\nwire_api = "responses"\n`;
  await writeFile(join(home, "config.toml"), original, "utf8");
  await writeFile(join(home, "deepseek-picker-models.json"), `${JSON.stringify({
    etag: "test",
    models: [{ slug: "deepseek-flash", display_name: "DeepSeek V4.1 Flash", description: "source", priority: 1 }],
  })}\n`, "utf8");
  await writeFile(join(home, "desktop-model-providers.json"), `${JSON.stringify({
    version: 1,
    default_provider: "openai",
    providers: [{ id: "deepseek", label: "DeepSeek" }],
    model_providers: { "deepseek-flash": "deepseek" },
  })}\n`, "utf8");
  const bundledPath = join(parent, "bundled.json");
  await writeFile(bundledPath, `${JSON.stringify({
    etag: "test-bundled",
    models: [{
      slug: "gpt-6-astra",
      display_name: "GPT-6-Astra",
      description: "Test OpenAI model",
      visibility: "list",
      priority: 1,
      supported_in_api: true,
    }],
  })}\n`, "utf8");
  try {
    run(home, "install-zai");
    run(home, "install", "--offline", `--bundled-catalog=${bundledPath}`);
    const installed = await readFile(join(home, "config.toml"), "utf8");
    assert.match(installed, /\[model_providers\.zai\]/);
    assert.match(installed, /^base_url = "https:\/\/api\.z\.ai\/api\/v1"$/m);
    assert.match(installed, /\[model_providers\.zai\.auth\]/);
    assert.match(installed, /codex-zhipu-token\.ps1/);
    assert.doesNotMatch(installed, /\[profiles\.zai\]/);
    assert.match(installed, /\[model_providers\.deepseek\]/);
    assert.doesNotMatch(installed, /experimental_bearer_token|ZAI_API_KEY/);

    const routing = JSON.parse(await readFile(join(home, "desktop-model-providers.json"), "utf8"));
    assert.equal(routing.default_provider, "openai");
    assert.equal(routing.model_providers["glm-5.3"], "zai");
    assert.equal(routing.model_providers["glm-5.3-flash"], "zai");
    assert.equal(routing.model_providers["glm-5.2"], undefined);
    assert.equal(routing.model_providers["deepseek-flash"], "deepseek");

    const catalog = JSON.parse(await readFile(join(home, "deepseek-picker-models.json"), "utf8"));
    assert.deepEqual(catalog.models.filter((model) => model.slug.startsWith("glm-")).map((model) => model.slug), ["glm-5.3", "glm-5.3-flash"]);
    assert.deepEqual(catalog.models.find((model) => model.slug === "glm-5.3-flash").input_modalities, ["text", "image"]);
    assert.deepEqual(catalog.models.find((model) => model.slug === "glm-5.3").input_modalities, ["text"]);
    assert.ok(catalog.models.some((model) => model.slug === "deepseek-flash"));

    run(home, "uninstall-zai");
    const restored = await readFile(join(home, "config.toml"), "utf8");
    assert.doesNotMatch(restored, /\[model_providers\.zai/);
    assert.doesNotMatch(restored, /\[profiles\.zai\]/);
    assert.match(restored, /\[model_providers\.deepseek\]/);
  } finally {
    await rm(parent, { recursive: true, force: true });
  }
});

test("plugin source contains no embedded DeepSeek API key", async () => {
  const candidates = [
    join(pluginRoot, "scripts", "manager.mjs"),
    join(pluginRoot, "vendor", "codex-model-picker", "src", "main-injection-source.mjs"),
    join(pluginRoot, "vendor", "codex-model-picker", "src", "main-injector.mjs"),
    join(pluginRoot, "README.md"),
    join(pluginRoot, "skills", "codex-multimodel-bridge", "SKILL.md"),
  ];
  for (const path of candidates) {
    const text = await readFile(path, "utf8");
    assert.doesNotMatch(text, /sk-[A-Za-z0-9_-]{12,}/);
  }
});
