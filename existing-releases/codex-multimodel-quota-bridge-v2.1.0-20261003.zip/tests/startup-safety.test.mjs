import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { isRetryableProviderRouterStatus } from "../vendor/codex-model-picker/src/main-injector-policy.mjs";

const pluginRoot = fileURLToPath(new URL("..", import.meta.url));

test("cold-start provider states remain retryable inside one launch", () => {
  for (const status of [
    "waiting",
    "electron_unavailable",
    "handler_map_unavailable",
    "handler_waiting",
  ]) {
    assert.equal(isRetryableProviderRouterStatus(status), true, status);
  }
  assert.equal(isRetryableProviderRouterStatus("patched"), false);
  assert.equal(isRetryableProviderRouterStatus("invalid"), false);
});

test("normal launch scripts never identify or terminate DSH Desktop", async () => {
  const launch = (await readFile(`${pluginRoot}/scripts/launch-deepseek.ps1`, "utf8")).replaceAll("\r\n", "\n");
  const compat = await readFile(`${pluginRoot}/scripts/start-compat.ps1`, "utf8");
  const combined = `${launch}\n${compat}`;

  assert.doesNotMatch(combined, /DSH Desktop/i);
  assert.doesNotMatch(launch, /Stop-Process|taskkill|TerminateProcess/i);
  assert.match(compat, /responses-compat\.mjs/);
  assert.match(compat, /OwningProcess/);
  assert.match(compat, /\[Regex\]::Escape\(\$expectedScript\)/);
  assert.match(compat, /Wait-CodexMainExit/);
  assert.match(compat, /Wait-CompatHealth/);
  assert.match(compat, /仍在等待旧进程退出/);
  assert.match(compat, /return/);
});

test("normal launch is serialized and bounds official refresh before offline fallback", async () => {
  const launcher = await readFile(pluginRoot + "/vendor/codex-model-picker/src/launcher.mjs", "utf8");
  const launch = (await readFile(`${pluginRoot}/scripts/launch-deepseek.ps1`, "utf8")).replaceAll("\r\n", "\n");
  assert.match(launch, /CodexModelPickerLaunch/);
  const offlineIndex = launch.indexOf("install --offline");
  const onlineIndex = launch.indexOf("run-manager.ps1') install\n", offlineIndex);
  assert.ok(launch.indexOf("refresh-openai --best-effort") >= 0);
  assert.ok(launch.indexOf("refresh-openai --best-effort") < offlineIndex);
  assert.ok(offlineIndex >= 0);
  assert.ok(onlineIndex > offlineIndex);
  assert.match(launch, /--doctor/);
  assert.match(launch, /install-cli-proxy\.ps1/);
  assert.match(launch, /--doctor --proxy/);
  assert.match(launcher, /verifyAppServerProxy/);
  assert.match(launcher, /routingMode: "app-server-proxy"/);
  assert.doesNotMatch(launch, /--doctor --no-wait/);
  assert.match(launch, /\[1\/4\]/);
  assert.match(launch, /启动未完成/);
  assert.match(launcher, /waitForCodexExit/);
  assert.match(launcher, /检测到普通方式启动的 Codex/);
  assert.match(launcher, /Codex 仍在运行，请从系统托盘完全退出/);
});

test("OpenAI recovery also removes the user-level proxy binding", async () => {
  const restore = await readFile(`${pluginRoot}/恢复-OpenAI.cmd`, "utf8");
  const installer = await readFile(`${pluginRoot}/scripts/install-cli-proxy.ps1`, "utf8");
  assert.match(restore, /install-cli-proxy\.ps1" -Restore/);
  assert.match(installer, /previousValue/);
  assert.match(installer, /Broadcast-EnvironmentChange/);
});

test("desktop entry keeps Windows CRLF line endings", async () => {
  for (const name of ["启动-Codex-多模型.cmd", "查看-API额度.cmd"]) {
    const entry = await readFile(`${pluginRoot}/${name}`);
    const text = entry.toString("utf8");
    const lineFeeds = [...text].filter((character) => character === "\n").length;
    const carriageReturns = [...text].filter((character) => character === "\r").length;
    assert.ok(lineFeeds > 0, name);
    assert.equal(carriageReturns, lineFeeds, name);
  }
});
