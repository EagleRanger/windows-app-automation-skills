import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { prepare, run, inspect, accept, checkCandidate } from '../scripts/handoff.mjs';

async function fixture() {
  const root=await mkdtemp(join(tmpdir(),'handoff-test-'));
  await writeFile(join(root,'settings.json'),'{"worker":"terra","frozen":"keep"}\n');
  const spec={version:1,root,goal:'只改 worker 为 deepseek',nextAction:'执行后自检',constraints:['frozen 不变'],decisions:['只改指定字段'],rejected:[],acceptance:['worker 更新且 frozen 不变'],files:[{path:'settings.json',write:true}],checks:[{kind:'json-equals',path:'settings.json',pointer:'/worker',value:'deepseek'},{kind:'json-preserve',path:'settings.json',pointer:'/frozen'}]};
  const directory=join(root,'packet');await prepare(spec,directory);
  return {root,directory,spec};
}
const candidate=(worker='deepseek',frozen='keep')=>({files:[{path:'settings.json',content:JSON.stringify({worker,frozen})+'\n'}],summary:'修改执行模型',unresolved:[],nextAction:'请主模型核对并合入'});
const final={summary:'本地两项检查通过，等待审核',unresolved:[],nextAction:'核对文件及合入'};
function mock(candidates=[candidate()]) {
  const calls=[];
  return {calls,transport:async body=>{
    calls.push(structuredClone(body)); const name=body.tools[0].name;
    assert.equal(body.model,'deepseek-flash'); assert.equal(body.reasoning.effort,'high');
    return {id:'resp-'+calls.length,model:'deepseek-flash',status:'completed',usage:{input_tokens:100,output_tokens:50},output:[{type:'function_call',call_id:'call-'+calls.length,name,arguments:JSON.stringify(name==='submit_candidate'?candidates.shift():final)}]};
  }};
}
const review = state => ({...state,decision:'accept',reviewer:'test-planner',reason:'核对目标、冻结字段和机器检查'});

test('round trip requires a fresh review; source changes only after acceptance',async()=>{
  const f=await fixture(),m=mock();
  const result=await run(f.directory,m);assert.equal(result.accepted,false);
  assert.equal(JSON.parse(await readFile(join(f.root,'settings.json'),'utf8')).worker,'terra');
  assert.equal(m.calls.length,2);
  assert.equal(JSON.parse(m.calls[1].input.find(x=>x.type==='function_call_output').output).pass,true);
  const state=await inspect(f.directory);
  await accept(f.directory,review(state));
  assert.equal(JSON.parse(await readFile(join(f.root,'settings.json'),'utf8')).worker,'deepseek');
  assert.equal((await inspect(f.directory)).status,'accepted');
  if(process.platform==='win32') {
    const entry=fileURLToPath(new URL('../scripts/run-handoff.ps1',import.meta.url));
    const output=execFileSync('powershell.exe',['-NoProfile','-ExecutionPolicy','Bypass','-File',entry,'-Action','inspect','-PacketDirectory',f.directory],{encoding:'utf8',windowsHide:true});
    assert.equal(JSON.parse(output).status,'accepted');
  }
  await assert.rejects(accept(f.directory,review(state)),/已合入/);
});
test('source drift stops execution before making a paid request',async()=>{
  const f=await fixture(),m=mock();await writeFile(join(f.root,'settings.json'),'{}');
  await assert.rejects(run(f.directory,m),/源文件已变化/); assert.equal(m.calls.length,0);
});
test('source drift on return cannot overwrite newer work',async()=>{
  const f=await fixture();await run(f.directory,mock());const s=await inspect(f.directory);
  await writeFile(join(f.root,'settings.json'),'{"worker":"new-work"}');
  await assert.rejects(accept(f.directory,review(s)),/源文件已变化/);
  assert.equal(JSON.parse(await readFile(join(f.root,'settings.json'),'utf8')).worker,'new-work');
});
test('duplicate dispatch and changed candidate cannot be replayed',async()=>{
  const f=await fixture();await run(f.directory,mock());
  const m=mock();await assert.rejects(run(f.directory,m),/不得重复派发/);assert.equal(m.calls.length,0);
  await writeFile(join(f.directory,'candidate.json'),JSON.stringify(candidate('different')));
  await assert.rejects(inspect(f.directory),/候选在自检后发生变化/);
});
test('packet tampering and stale review IDs are rejected',async()=>{
  const f=await fixture();await run(f.directory,mock());const s=await inspect(f.directory);
  await assert.rejects(accept(f.directory,{...review(s),packetId:'old'}),/审核记录/);
  const p=JSON.parse(await readFile(join(f.directory,'packet.json'),'utf8'));p.goal='changed';await writeFile(join(f.directory,'packet.json'),JSON.stringify(p));
  await assert.rejects(inspect(f.directory),/交接包已变化/);
});
test('failed invariant is returned to the worker and corrected in one additional call',async()=>{
  const f=await fixture(),m=mock([candidate('deepseek','wrong'),candidate()]);await run(f.directory,m);
  assert.equal(m.calls.length,3);assert.equal(JSON.parse(m.calls[1].input.find(x=>x.type==='function_call_output').output).pass,false);
  assert.equal((await inspect(f.directory)).checks.pass,true);
  assert.equal(JSON.parse(await readFile(join(f.directory,'attempt-1.checks.json'),'utf8')).pass,false);
  assert.equal(JSON.parse(await readFile(join(f.directory,'attempt-2.checks.json'),'utf8')).pass,true);
});
test('scope escape and writes to frozen files are rejected',async()=>{
  const f=await fixture();
  await assert.rejects(prepare({...f.spec,files:[{path:'../escape',write:true}]},join(f.root,'bad')),/路径/);
  const p=JSON.parse(await readFile(join(f.directory,'packet.json'),'utf8'));
  assert.throws(()=>checkCandidate(p,{...candidate(),files:[{path:'outside.txt',content:'x'}]}),/未授权/);
  assert.equal(checkCandidate(p,candidate('deepseek','broken')).pass,false);
  assert.equal(checkCandidate({...p,checks:[{kind:'json-preserve',path:'settings.json',pointer:'/missing'}]},candidate()).pass,false);
});
test('unknown network outcome remains blocked and is not automatically replayed',async()=>{
  const f=await fixture();let calls=0;
  await assert.rejects(run(f.directory,{transport:async()=>{calls++;throw new Error('network-uncertain');}}),/network-uncertain/);
  assert.equal(JSON.parse(await readFile(join(f.directory,'state.json'),'utf8')).status,'blocked');
  await assert.rejects(run(f.directory,{transport:async()=>{calls++;}}),/不得重复派发/);assert.equal(calls,1);
});
