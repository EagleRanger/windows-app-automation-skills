import test from 'node:test';
import assert from 'node:assert/strict';
import { mergeProviderRouting } from '../scripts/routing-config.mjs';
test('refreshing DeepSeek catalog retains project Loop mapping and other providers', () => {
  const previous = { project_loop_roots: [{ cwd: 'shared', projectRoot: 'actual' }], providers: [{ id: 'zai' }], model_providers: { 'glm-5.3-flash': 'zai' } };
  const next = mergeProviderRouting(previous, { providers: [{ id: 'deepseek' }], model_providers: { 'deepseek-flash': 'deepseek' } });
  assert.deepEqual(next.project_loop_roots, previous.project_loop_roots);
  assert.equal(next.model_providers['glm-5.3-flash'], 'zai');
  assert.deepEqual(next.providers.map(p => p.id), ['zai', 'deepseek']);
});
