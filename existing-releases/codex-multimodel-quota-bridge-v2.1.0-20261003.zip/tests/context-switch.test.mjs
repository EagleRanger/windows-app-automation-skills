import assert from "node:assert/strict";
import test from "node:test";
import { buildContextPacket } from "../scripts/context-switch.mjs";

test("context packet keeps user and assistant text, skips tool internals, and appends the current instruction", () => {
  const packet = buildContextPacket({
    sourceThreadId: "source-1",
    thread: { title: "Source", cwd: "C:/project" },
    turns: [{ items: [
      { type: "userMessage", content: [{ type: "text", text: "older request" }] },
      { type: "functionCallOutput", output: "secret noisy output" },
      { type: "agentMessage", text: "finished A" },
    ] }],
    instruction: "latest request",
  });
  assert.deepEqual(packet.messages, [
    { role: "user", text: "older request" },
    { role: "assistant", text: "finished A" },
    { role: "user", text: "latest request" },
  ]);
  assert.equal(JSON.stringify(packet).includes("secret noisy output"), false);
});

test("context cap preserves newest messages", () => {
  const packet = buildContextPacket({
    sourceThreadId: "source-2",
    thread: {},
    turns: [{ items: [
      { type: "userMessage", content: [{ text: "A".repeat(700) }] },
      { type: "agentMessage", text: "B".repeat(700) },
    ] }],
    instruction: "LATEST",
    maxChars: 500,
  });
  assert.equal(packet.messages.at(-1).text, "LATEST");
  assert.ok(JSON.stringify(packet).length < 1_400);
});

test("context packet preserves the source task identity for a later return", () => {
  const packet = buildContextPacket({
    sourceThreadId: "original-codex-thread",
    thread: { name: "Project", cwd: "C:/project" },
    turns: [],
  });
  assert.deepEqual(packet.source, {
    threadId: "original-codex-thread",
    title: "Project",
    cwd: "C:/project",
  });
});
