import assert from "node:assert/strict";
import test from "node:test";
import { mkdtemp, mkdir, writeFile, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { prepareDesktopRuntime } from "../scripts/desktop-runtime.mjs";
import { waitForDesktopRenderer, readDesktopBootstrapFailure } from "../vendor/codex-model-picker/src/desktop-startup.mjs";

test("desktop runtime repair fills missing files, verifies contents, and reuses the official cache", async () => {
  const root = await mkdtemp(join(tmpdir(), "picker-desktop-runtime-"));
  try {
    const source = join(root, "source"), cache = join(root, "cache");
    await mkdir(join(source, "bin", "node_modules", "sample"), { recursive: true });
    await writeFile(join(source, "manifest.json"), JSON.stringify({ platform: "windows", node_path: "bin/node.exe", node_repl_path: "bin/node_repl.exe" }));
    await writeFile(join(source, "bin", "node.exe"), "node-fixture");
    await writeFile(join(source, "bin", "node_repl.exe"), "repl-fixture");
    await writeFile(join(source, "bin", "node_modules", "sample", "runtime.js"), "sample");
    const first = await prepareDesktopRuntime(source, cache);
    assert.equal(first.files, 4);
    assert.equal(first.copied, 4);
    const again = await prepareDesktopRuntime(source, cache);
    assert.equal(again.copied, 0);
    assert.equal(again.cacheId, first.cacheId);
    const damaged = join(cache, first.cacheId, "bin", "node_modules", "sample", "runtime.js");
    await writeFile(damaged, "keep-existing");
    await assert.rejects(prepareDesktopRuntime(source, cache), /未覆盖现有文件/);
    assert.equal(await readFile(damaged, "utf8"), "keep-existing");
  } finally { await rm(root, { recursive: true, force: true }); }
});

test("desktop startup waits through delayed page readiness and refuses success from a process ID alone", async () => {
  let time = 0, calls = 0;
  const page = { type: "page", url: "app://-/index.html", webSocketDebuggerUrl: "ws://127.0.0.1:1234/devtools/page/test" };
  const options = { now: () => time, sleep: async (ms) => { time += ms; }, fetchTargets: async () => { calls++; return time >= 25_000 ? [page] : []; } };
  assert.equal(await waitForDesktopRenderer(1234, options), page);
  assert.ok(calls > 80);
  time = 0;
  await assert.rejects(waitForDesktopRenderer(1234, { ...options, timeoutMs: 1000, fetchTargets: async () => [] }), { code: "RENDERER_UNAVAILABLE" });
});

test("desktop startup reports the actual fatal startup error without another launch", async () => {
  let calls = 0;
  await assert.rejects(waitForDesktopRenderer(1234, {
    readFailure: async () => "桌面后端启动失败：spawn EPERM",
    fetchTargets: async () => { calls++; return []; },
  }), /spawn EPERM/);
  assert.equal(calls, 0);
});

test("desktop startup diagnostics use only the launched process and ignore older or recoverable errors", async () => {
  const root = await mkdtemp(join(tmpdir(), "picker-desktop-logs-"));
  try {
    const directory = join(root, "2026", "10", "03");
    await mkdir(directory, { recursive: true });
    const file = join(directory, "codex-desktop-test-42-t0-i1-test.log");
    const options = { processId: 42, startedAt: "2026-10-03T08:20:00.000Z", logsRoot: root };
    await writeFile(file, '2026-10-03T08:19:00.000Z error Desktop bootstrap failed to start the main app\n2026-10-03T08:20:01.000Z error fatal_error_broadcasted errorMessage="temporary"\n');
    assert.equal(await readDesktopBootstrapFailure(options), null);
    await writeFile(file, '2026-10-03T08:20:01.000Z error fatal_error_broadcasted errorMessage="spawn EPERM"\n2026-10-03T08:20:02.000Z error Desktop bootstrap failed to start the main app\n');
    assert.match(await readDesktopBootstrapFailure(options), /spawn EPERM/);
    assert.equal(await readDesktopBootstrapFailure({ ...options, processId: 43 }), null);
  } finally { await rm(root, { recursive: true, force: true }); }
});
