import assert from "node:assert/strict";
import test from "node:test";
import vm from "node:vm";
import { webcrypto } from "node:crypto";
import {
  buildInjectionSource,
  shouldHideRetiredModelLabel,
} from "../vendor/codex-model-picker/src/injection-source.mjs";

test("retired GLM aliases are hidden while current GLM models stay visible", () => {
  const catalog = ["glm-5.3", "glm-5.3-flash"];
  assert.equal(shouldHideRetiredModelLabel("GLM-4.5", catalog), true);
  assert.equal(shouldHideRetiredModelLabel("GLM-5.3-FLASHX", catalog), true);
  assert.equal(shouldHideRetiredModelLabel("GLM-5.3", catalog), false);
  assert.equal(shouldHideRetiredModelLabel("GLM-5.3-FLASH", catalog), false);
  assert.equal(shouldHideRetiredModelLabel("GPT-5.5", catalog), false);
});

function installFixture({ sourceProvider, sourceModel, targetProvider, targetModel, targetInitiallyHidden = false, prepaired = false, omitReadProvider = false, omitInitialPairedMetadata = false, turnsResponseShape = "data", projectLoopStatus = "loaded", sourceReadProvider = sourceProvider, sourceReadModel = sourceModel, targetHistoryUnmaterialized = false, dropPairedResume = false, sourceHistoryError = false, automations = [], failAutomationUpdate = false, dropMutation = null, storage = null, targetCwd = "C:\\project", nativeTargetProvider = targetProvider, busyReceiptLock = false }) {
  const listeners = new Map();
  const requests = [];
  const nativeRequests = [];
  const events = [];
  const automationRows = automations.map(item => ({ ...item }));
  let targetOpens = 0;
  let listExpansions = 0;
  let targetVisible = !targetInitiallyHidden;
  let targetReads = 0;
  let targetMaterialized = !targetHistoryUnmaterialized;
  const emit = (type, data) => {
    for (const listener of listeners.get(type) ?? []) listener(data);
  };
  const targetThread = {
    id: "target-thread",
    forkedFromId: "source-thread",
    ...(omitReadProvider ? {} : { modelProvider: nativeTargetProvider }),
    cwd: targetCwd,
    model: targetModel,
  };
  const bridge = {
    sendMessageFromView(message) {
      if (message.type === "fetch") {
        const action = message.url.replace("vscode://codex/", "");
        const params = JSON.parse(message.body);
        nativeRequests.push({ action, params });
        events.push(action);
        let response;
        if (action === "list-automations") response = { items: automationRows.map(item => ({ ...item })) };
        else if (action === "automation-update" && failAutomationUpdate) {
          setTimeout(() => emit("message", { data: { type: "fetch-response", responseType: "error", requestId: message.requestId, status: 500, error: "update failed" } }), 0);
          return Promise.resolve();
        } else if (action === "automation-update") {
          const row = automationRows.find(item => item.id === params.id);
          Object.assign(row, params);
          response = { item: { ...row } };
        } else throw new Error("Unexpected native action: " + action);
        setTimeout(() => emit("message", { data: { type: "fetch-response", responseType: "success", requestId: message.requestId, status: 200, bodyJsonString: JSON.stringify(response) } }), 0);
        return Promise.resolve();
      }
      requests.push(message.request);
      events.push(message.request.method);
      const { id, method, params } = message.request;
      if (dropPairedResume && method === "thread/resume" && params.threadId === "target-thread") return;
      if (method === dropMutation) return;
      let result = {};
      if (method === "thread/read" && params.threadId === "source-thread") {
        result = { thread: { id: "source-thread", name: "Source", cwd: "C:\\project", ...(omitReadProvider ? {} : { modelProvider: sourceReadProvider }), model: sourceReadModel } };
      }
      if (method === "thread/read" && params.threadId === "target-thread") {
        targetReads += 1;
        result = { thread: omitInitialPairedMetadata && targetReads === 1 ? { id: "target-thread" } : targetThread };
      }
      if (method === "thread/start") {
        result = { thread: targetThread };
      }
      if (method === "turn/start" && params.threadId === "target-thread") {
        targetMaterialized = true;
        result = { turn: { id: "handoff-turn" } };
      }
      if (method === "thread/resume") {
        result = params.threadId === "source-thread"
          ? { thread: { id: "source-thread", modelProvider: sourceProvider, model: sourceModel } }
          : { thread: targetThread };
      }
      let error = sourceHistoryError && method === "thread/turns/list" && params.threadId === "source-thread" ? { message: "history unavailable" } : null;
      if (method === "thread/turns/list" && params.threadId === "target-thread" && !targetMaterialized) {
        error = { message: "thread target-thread is not materialized yet; thread/turns/list is unavailable before first user message" };
      } else if (method === "thread/turns/list") {
        const turns = [{ id: targetMaterialized ? "handoff-turn" : "existing-turn", status: "completed", items: [{ type: "userMessage", content: [{ type: "text", text: "latest instruction" }] }] }];
        result = turnsResponseShape === "turns" ? { turns } : { data: turns };
      }
      if (method === "codex/project-loop/read") {
        result = projectLoopStatus === "loaded"
          ? { status: "loaded", source: ".project-reasoning/STATE.md", truncated: false, content: "# 当前状态\\n- 只承接未完成项。" }
          : { status: projectLoopStatus, reason: "fixture" };
      }
      setTimeout(() => {
        emit("message", { data: { type: "mcp-response", message: error ? { id, error } : { id, result } } });
      }, 0);
    },
  };
  const targetRow = {
    dataset: {
      appActionSidebarThreadId: "local:target-thread",
      appActionSidebarThreadSelected: "false",
      appActionSidebarThreadActive: "false",
    },
    click() {
      targetOpens += 1;
      this.dataset.appActionSidebarThreadSelected = "true";
    },
  };
  const sourceRow = { dataset: { appActionSidebarThreadId: 'local:source-thread', appActionSidebarThreadSelected: 'false' }, click() { this.dataset.appActionSidebarThreadSelected = 'true'; } };
  const showMoreButton = {
    textContent: "展开显示",
    click() {
      listExpansions += 1;
      targetVisible = true;
    },
  };
  const body = { appendChild() {} };
  const composer = {
    isConnected: true,
    getBoundingClientRect() { return { width: 640, height: 96 }; },
  };
  const document = {
    body,
    getElementById() { return null; },
    createElement() { return { style: {}, remove() {} }; },
    querySelectorAll(selector) {
      if (selector.includes("!=")) throw new Error("Invalid CSS selector");
      if (selector === '[data-app-action-sidebar-thread-id]') return targetVisible ? [sourceRow, targetRow] : [sourceRow];
      if (selector.includes('textarea:not([disabled])')) return [composer];
      if (selector === "button") return [showMoreButton];
      return [];
    },
  };
  const window = {
    electronBridge: bridge,
    postMessage(data) {
      emit("message", { data });
    },
    addEventListener(type, listener) {
      const current = listeners.get(type) ?? [];
      current.push(listener);
      listeners.set(type, current);
    },
    getComputedStyle() { return { visibility: "visible", display: "block" }; },
  };
  const stored = storage ?? new Map();
  if (prepaired && !stored.has("codex-provider-thread-families-v1")) {
    stored.set("codex-provider-thread-families-v1", JSON.stringify({
      version: 1,
      threadToFamily: { "source-thread": "source-thread", "target-thread": "source-thread" },
      families: { "source-thread": { providers: { [sourceProvider]: "source-thread", [targetProvider]: "target-thread" } } },
    }));
  }
  const localStorage = {
    getItem(key) { return stored.get(key) ?? null; },
    setItem(key, value) { stored.set(key, value); },
  };
  const context = vm.createContext({
    window,
    document,
    localStorage,
    navigator: busyReceiptLock ? { locks: { request: async (_name, options, callback) => { if (typeof options === "object" && options.ifAvailable) return callback(null); await new Promise(r => setTimeout(r, 35)); return options({}); } } } : undefined,
    crypto: webcrypto,
    TextEncoder,
    setTimeout: (fn, ms) => setTimeout(fn, (dropPairedResume && ms === 90_000) || (dropMutation && [12_000, 20_000].includes(ms)) ? 20 : ms),
    clearTimeout,
    console,
  });
  new vm.Script(buildInjectionSource({
    catalogModels: sourceProvider === "openai" ? [sourceModel] : [targetModel],
    additionalModels: sourceProvider === "deepseek" ? [sourceModel] : [targetModel],
  })).runInContext(context);
  return {
    context,
    requests,
    nativeRequests,
    events,
    automationRows,
    stored,
    emitNative(data) { emit("message", { data }); },
    emitSwitch(settings = null, extra = {}) {
      emit("message", {
        data: {
          type: "codex-provider-switch-request",
          sourceThreadId: "source-thread",
          model: targetModel,
          provider: targetProvider,
          ...(settings ? { settings } : {}),
          ...extra,
        },
      });
    },
    get targetOpens() { return targetOpens; },
    get listExpansions() { return listExpansions; },
  };
}

test("capacity recovery never creates a missing provider slot", async () => {
  const f = installFixture({ sourceProvider: 'openai', sourceModel: 'gpt-5.6-sol', targetProvider: 'zai', targetModel: 'glm-5.3-flash' });
  f.emitSwitch(null, { existingOnly: true });
  await new Promise(r => setTimeout(r, 700));
  assert.equal(f.requests.some(r => r.method === 'thread/start' || r.method === 'turn/start' || r.method === 'thread/archive'), false);
  assert.equal(f.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status, 'failed');
});

const receiptFixture = { sourceProvider: 'openai', sourceModel: 'gpt-6-sol', targetProvider: 'zai', targetModel: 'glm-5.3-flash' };
test('lost create acknowledgement cannot create another task after renderer restart; late ack recovers the slot', async () => {
  const f = installFixture({ ...receiptFixture, dropMutation: 'thread/start' });
  f.emitSwitch();
  await new Promise(r => setTimeout(r, 400));
  const request = f.requests.find(r => r.method === 'thread/start');
  assert.ok(request);
  const restored = installFixture({ ...receiptFixture, storage: f.stored });
  restored.emitSwitch();
  await new Promise(r => setTimeout(r, 400));
  assert.equal(restored.requests.some(r => r.method === 'thread/start'), false);
  restored.emitNative({ type: 'mcp-response', message: { id: request.id, result: { thread: { id: 'target-thread', modelProvider: 'zai' } } } });
  restored.emitSwitch();
  await new Promise(r => setTimeout(r, 700));
  assert.equal(restored.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status, 'completed');
  assert.equal(restored.requests.some(r => ['thread/start', 'thread/inject_items'].includes(r.method)), false);
});
test('lost handoff acknowledgement never reinjects blindly and a late ack enables safe reuse', async () => {
  const f = installFixture({ ...receiptFixture, prepaired: true, dropMutation: 'thread/inject_items' });
  f.emitSwitch();
  await new Promise(r => setTimeout(r, 400));
  const request = f.requests.find(r => r.method === 'thread/inject_items');
  const restored = installFixture({ ...receiptFixture, storage: f.stored });
  restored.emitSwitch();
  await new Promise(r => setTimeout(r, 400));
  assert.equal(restored.requests.some(r => r.method === 'thread/inject_items'), false);
  restored.emitNative({ type: 'mcp-response', message: { id: request.id, result: {} } });
  restored.emitSwitch();
  await new Promise(r => setTimeout(r, 700));
  assert.equal(restored.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status, 'completed');
  assert.equal(restored.requests.some(r => r.method === 'thread/inject_items'), false);
});
test('repeated successful switch reuses the existing confirmed handoff', async () => {
  const f = installFixture({ ...receiptFixture, prepaired: true });
  f.emitSwitch(); f.emitSwitch();
  await new Promise(r => setTimeout(r, 700));
  f.emitSwitch();
  await new Promise(r => setTimeout(r, 700));
  assert.equal(f.requests.filter(r => r.method === 'thread/inject_items').length, 1);
  assert.equal(f.requests.some(r => r.method === 'thread/start'), false);
});
test('cross-project or native-provider conflicts stop before changing the paired task', async () => {
  for (const mismatch of [{ targetCwd: 'C:\\unrelated' }, { nativeTargetProvider: 'deepseek' }]) {
    const f = installFixture({ ...receiptFixture, prepaired: true, ...mismatch });
    f.emitSwitch();
    await new Promise(r => setTimeout(r, 400));
    assert.equal(f.requests.some(r => ['thread/unarchive', 'thread/resume', 'thread/inject_items', 'thread/archive'].includes(r.method)), false);
    assert.equal(f.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status, 'failed');
  }
});

test("unreadable handoff history stops before opening, creating, or archiving a task", async () => {
  const f=installFixture({sourceProvider:"openai",sourceModel:"gpt-6-luna",targetProvider:"zai",targetModel:"glm-5.3-flash",prepaired:true,sourceHistoryError:true});
  f.emitSwitch();await new Promise(r=>setTimeout(r,500));
  assert.equal(f.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status,"failed");
  assert.equal(f.requests.some(r=>['thread/start','thread/archive','thread/unarchive','thread/resume'].includes(r.method)),false);
  assert.equal(f.requests.some(r=>r.method==='thread/read'&&r.params.includeTurns===true),false);
  assert.equal(f.requests.find(r=>r.method==='thread/turns/list').params.itemsView,'summary');
});

test("capacity recovery requires a loaded Loop before touching a paired task", async () => {
  const f = installFixture({ sourceProvider: 'openai', sourceModel: 'gpt-5.6-sol', targetProvider: 'zai', targetModel: 'glm-5.3-flash', prepaired: true, projectLoopStatus: 'missing' });
  f.emitSwitch(null, { existingOnly: true });
  await new Promise(r => setTimeout(r, 700));
  assert.equal(f.requests.some(r => ['thread/start','turn/start','thread/unarchive','thread/archive'].includes(r.method)), false);
});

test("same-provider model changes stay in the existing task", async () => {
  const fixture = installFixture({
    sourceProvider: "openai",
    sourceModel: "gpt-6-astra",
    targetProvider: "openai",
    targetModel: "gpt-5.6-sol",
  });
  fixture.emitSwitch({
    threadId: "source-thread",
    model: "gpt-5.6-sol",
    reasoningEffort: "high",
  });
  await new Promise((resolve) => setTimeout(resolve, 30));
  assert.equal(fixture.targetOpens, 0);
  assert.deepEqual(
    fixture.requests.map((request) => request.method).filter((method) => method !== "codex/provider-families/sync"),
    ["thread/read", "thread/settings/update"],
  );
  assert.equal(
    fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status,
    "same_provider",
  );
  const settingsUpdate = fixture.requests.find((request) => request.method === "thread/settings/update");
  assert.equal(settingsUpdate.params.reasoningEffort, "high");
  assert.equal(settingsUpdate.params.__codexProviderSwitchBypass, true);
});

test("an explicit empty-turn recovery interrupts only the named task turn", async () => {
  const fixture = installFixture({
    sourceProvider: "deepseek",
    sourceModel: "deepseek-flash",
    targetProvider: "deepseek",
    targetModel: "deepseek-flash",
  });
  await fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.interruptTurn("stuck-thread", "stuck-turn");
  const interrupt = fixture.requests.find((request) => request.method === "turn/interrupt");
  assert.deepEqual(
    { threadId: interrupt.params.threadId, turnId: interrupt.params.turnId },
    { threadId: "stuck-thread", turnId: "stuck-turn" },
  );
});

test("cross-provider model changes leave the target input-ready after bounded handoff, verification, rename, and source archive", async () => {
  const fixture = installFixture({
    sourceProvider: "openai",
    sourceModel: "gpt-6-astra",
    targetProvider: "deepseek",
    targetModel: "deepseek-flash",
    targetInitiallyHidden: true,
  });
  fixture.emitSwitch();
  await new Promise((resolve) => setTimeout(resolve, 1_200));
  assert.equal(fixture.targetOpens, 1);
  assert.equal(fixture.listExpansions, 1);
  assert.deepEqual(
    fixture.requests.map((request) => request.method).filter((method) => method !== "codex/provider-families/sync"),
    ["thread/read", "codex/project-loop/read", "thread/turns/list", "thread/start", "thread/read", "thread/turns/list", "thread/name/set", "thread/read", "thread/read", "thread/archive"],
  );
  const start = fixture.requests.find((request) => request.method === "thread/start");
  const sourceTurns = fixture.requests.find((request) =>
    request.method === "thread/turns/list" && request.params.threadId === "source-thread",
  );
  assert.equal(start.params.modelProvider, "deepseek");
  assert.equal(sourceTurns.params.modelProvider, "openai");
  assert.match(start.params.developerInstructions, /codex-cross-provider-bounded-handoff/);
  assert.match(start.params.developerInstructions, /项目 Loop 热状态/);
  assert.match(start.params.developerInstructions, /只承接未完成项/);
  assert.equal(fixture.requests.some((request) => request.method === "turn/start"), false);
  assert.equal(
    fixture.requests.find((request) => request.method === "thread/archive").params.modelProvider,
    "openai",
  );
  const status = fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch;
  assert.equal(status.status, "completed");
  assert.equal(status.lastTargetThreadId, "target-thread");
  assert.equal(status.created, 1);
  assert.equal(status.lastProjectLoopStatus, "loaded");
  assert.deepEqual(JSON.parse(JSON.stringify(status.lastAcceptance)), {
    targetProviderAndModel: true,
    targetHistory: "readable",
    targetSelectedInCurrentWindow: true,
    targetComposerEditable: true,
    projectLoopStatus: "loaded",
    sourceArchived: true,
    modelReply: "unverified",
    semanticHandoff: "unverified",
    automationRebind: { ids: [], moved: 0 },
  });
});

test("cross-provider handoff rebinds the existing heartbeat before archiving its source", async () => {
  const original = {
    id: "daily", kind: "heartbeat", name: "Daily", prompt: "Run daily",
    status: "ACTIVE", rrule: "RRULE:FREQ=DAILY;BYHOUR=12;BYMINUTE=0",
    targetThreadId: "source-thread", model: null, reasoningEffort: null,
  };
  const fixture = installFixture({
    sourceProvider: "openai", sourceModel: "gpt-6-astra",
    targetProvider: "deepseek", targetModel: "deepseek-flash",
    automations: [original],
  });
  fixture.emitSwitch();
  await new Promise(resolve => setTimeout(resolve, 1_200));
  assert.equal(fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status, "completed");
  assert.equal(fixture.automationRows[0].targetThreadId, "target-thread");
  for (const key of ["id", "name", "prompt", "status", "rrule"]) {
    assert.equal(fixture.automationRows[0][key], original[key]);
  }
  assert.ok(fixture.events.indexOf("automation-update") < fixture.events.indexOf("thread/archive"));
  assert.deepEqual(JSON.parse(JSON.stringify(fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.lastAutomationRebind)),
    { ids: ["daily"], moved: 1 });
});

test("automation update failure keeps the original scheduled target and does not archive the source", async () => {
  const fixture = installFixture({
    sourceProvider: "openai", sourceModel: "gpt-6-astra",
    targetProvider: "deepseek", targetModel: "deepseek-flash",
    automations: [{ id: "daily", kind: "heartbeat", name: "Daily", prompt: "Run daily",
      status: "ACTIVE", rrule: "RRULE:FREQ=DAILY", targetThreadId: "source-thread" }],
    failAutomationUpdate: true,
  });
  fixture.emitSwitch();
  await new Promise(resolve => setTimeout(resolve, 1_200));
  const status = fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch;
  assert.equal(status.status, "failed");
  assert.equal(fixture.automationRows[0].targetThreadId, "source-thread");
  assert.equal(fixture.requests.some(request => request.method === "thread/archive" && request.params.threadId === "source-thread"), false);
  assert.match(status.lastError, /Scheduled task handoff failed/);
});

test("a new paired task is materialized before it is opened or the source is archived", async () => {
  const fixture = installFixture({
    sourceProvider: "zai",
    sourceModel: "glm-5.3-flash",
    targetProvider: "openai",
    targetModel: "gpt-5.6-terra",
    targetHistoryUnmaterialized: true,
  });
  fixture.emitSwitch();
  await new Promise((resolve) => setTimeout(resolve, 1_200));
  const status = fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch;
  assert.equal(status.status, "completed");
  assert.equal(status.lastAcceptance.targetHistory, "materialized");
  assert.equal(status.lastAcceptance.sourceArchived, true);
  const methods = fixture.requests.map((request) => request.method);
  assert.equal(methods.includes("turn/start"), true);
  assert.ok(methods.indexOf("turn/start") < methods.indexOf("thread/archive"));
  assert.equal(fixture.targetOpens, 1);
});

test("cross-provider changes reuse and unarchive the existing provider-paired task", async () => {
  const fixture = installFixture({
    sourceProvider: "openai",
    sourceModel: "gpt-6-astra",
    targetProvider: "deepseek",
    targetModel: "deepseek-flash",
    prepaired: true,
  });
  fixture.emitSwitch();
  await new Promise((resolve) => setTimeout(resolve, 1_200));
  assert.equal(fixture.targetOpens, 1);
  assert.deepEqual(
    fixture.requests.map((request) => request.method).filter((method) => method !== "codex/provider-families/sync"),
    ["thread/read", "codex/project-loop/read", "thread/turns/list", "thread/read", "thread/unarchive", "thread/resume", "thread/settings/update", "thread/inject_items", "thread/read", "thread/turns/list", "thread/name/set", "thread/read", "thread/read", "thread/archive"],
  );
  assert.equal(fixture.requests.some((request) => request.method === "thread/start"), false);
  const resume = fixture.requests.find((request) => request.method === "thread/resume");
  const unarchive = fixture.requests.find((request) => request.method === "thread/unarchive");
  assert.equal(unarchive.params.modelProvider, "deepseek");
  assert.equal(resume.params.excludeTurns, true);
  assert.equal(resume.params.model, "deepseek-flash");
  const inject=fixture.requests.find(r=>r.method==='thread/inject_items');
  assert.match(inject.params.items[0].content[0].text,/latest instruction/);
  assert.ok(fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.lastHandoffMessageCount>0);
  assert.equal(fixture.requests.some((request) => request.method === "turn/start"), false);
  const status = fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch;
  assert.equal(status.status, "completed");
  assert.equal(status.reused, 1);
  assert.equal(status.created, 0);
});

test("a resume timeout preserves the provider slot and retries never create a duplicate", async () => {
  const fixture = installFixture({ sourceProvider: "zai", sourceModel: "glm-5.3-flash", targetProvider: "openai", targetModel: "gpt-6-luna", prepaired: true, dropPairedResume: true });
  for (let attempt = 0; attempt < 2; attempt += 1) {
    fixture.emitSwitch();
    await new Promise(resolve => setTimeout(resolve, 600));
    const status = fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch;
    assert.equal(status.status, "failed");
    assert.equal(status.attempts, attempt + 1);
    assert.match(status.lastError, /pairing preserved/);
    const family = JSON.parse(fixture.stored.get("codex-provider-thread-families-v1"));
    assert.equal(family.families["source-thread"].providers.openai, "target-thread");
    assert.equal(family.threadToFamily["target-thread"], "source-thread");
  }
  assert.equal(fixture.requests.some(r => r.method === "thread/start" || r.method === "turn/start"), false);
  assert.deepEqual(fixture.requests.filter(r => r.method === "thread/archive").map(r => r.params.threadId), ["target-thread", "target-thread"]);
});

test("paired tasks are reused when Codex omits modelProvider from an unloaded thread", async () => {
  const fixture = installFixture({
    sourceProvider: "openai",
    sourceModel: "gpt-6-astra",
    targetProvider: "deepseek",
    targetModel: "deepseek-flash",
    prepaired: true,
    omitReadProvider: true,
  });
  fixture.emitSwitch();
  await new Promise((resolve) => setTimeout(resolve, 1_200));
  assert.equal(fixture.requests.some((request) => request.method === "thread/start"), false);
  const status = fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch;
  assert.equal(status.status, "completed");
  assert.equal(status.reused, 1);
  assert.equal(status.created, 0);
});

test("paired GLM tasks are recognized as Z.ai when Codex omits modelProvider", async () => {
  const fixture = installFixture({
    sourceProvider: "openai",
    sourceModel: "gpt-5.6-sol",
    targetProvider: "zai",
    targetModel: "glm-5.3-flash",
    prepaired: true,
    omitReadProvider: true,
  });
  fixture.emitSwitch();
  await new Promise((resolve) => setTimeout(resolve, 1_200));
  assert.equal(fixture.requests.some((request) => request.method === "thread/start"), false);
  const resume = fixture.requests.find((request) => request.method === "thread/resume");
  assert.equal(resume.params.model, "glm-5.3-flash");
  const status = fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch;
  assert.equal(status.status, "completed");
  assert.equal(status.reused, 1);
});

test("paired provider identity wins when a stale task read already shows the newly selected provider", async () => {
  const fixture = installFixture({
    sourceProvider: "zai",
    sourceModel: "glm-5.3-flash",
    targetProvider: "openai",
    targetModel: "gpt-5.6-terra",
    prepaired: true,
    sourceReadProvider: "openai",
    sourceReadModel: "gpt-5.6-terra",
  });
  fixture.emitSwitch();
  await new Promise((resolve) => setTimeout(resolve, 1_200));
  assert.equal(fixture.requests.some((request) => request.method === "thread/settings/update" && request.params.threadId === "source-thread"), false);
  assert.equal(fixture.requests.some((request) => request.method === "thread/resume"), true);
  assert.equal(fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status, "completed");
});

test("a completed cross-provider handoff does not create an automatic acknowledgement turn", async () => {
  const fixture = installFixture({
    sourceProvider: "openai",
    sourceModel: "gpt-5.6-sol",
    targetProvider: "zai",
    targetModel: "glm-5.3-flash",
  });
  fixture.emitSwitch();
  await new Promise((resolve) => setTimeout(resolve, 1_200));
  assert.equal(fixture.requests.some((request) => request.method === "turn/start"), false);
  const archived = fixture.requests
    .filter((request) => request.method === "thread/archive")
    .map((request) => request.params.threadId);
  assert.deepEqual(archived, ["source-thread"]);
  assert.equal(
    fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status,
    "completed",
  );
});

test("handoff accepts the current turns response shape instead of dropping context", async () => {
  const fixture = installFixture({
    sourceProvider: "openai",
    sourceModel: "gpt-5.6-sol",
    targetProvider: "zai",
    targetModel: "glm-5.3-flash",
    turnsResponseShape: "turns",
  });
  fixture.emitSwitch();
  await new Promise((resolve) => setTimeout(resolve, 1_200));
  const start = fixture.requests.find((request) => request.method === "thread/start");
  assert.match(start.params.developerInstructions, /latest instruction/);
  assert.equal(
    fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status,
    "completed",
  );
});

test("handoff records an unavailable project Loop instead of claiming it was read", async () => {
  const fixture = installFixture({
    sourceProvider: "openai",
    sourceModel: "gpt-5.6-sol",
    targetProvider: "zai",
    targetModel: "glm-5.3-flash",
    projectLoopStatus: "missing",
  });
  fixture.emitSwitch();
  await new Promise((resolve) => setTimeout(resolve, 1_200));
  const start = fixture.requests.find((request) => request.method === "thread/start");
  assert.match(start.params.developerInstructions, /未找到可读的单项目 Loop/);
  assert.match(start.params.developerInstructions, /\"status\":\"missing\"/);
  assert.equal(fixture.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status, "completed");
});

 test('user selection waits for a busy receipt lock instead of being dropped', async () => {
  const f = installFixture({ ...receiptFixture, prepaired: true, busyReceiptLock: true });
  f.emitSwitch();
  await new Promise(r => setTimeout(r, 900));
  assert.equal(f.context.__CODEX_MODEL_PICKER_OVERRIDE__.providerSwitch.status, 'completed');
  assert.equal(f.requests.filter(r => r.method === 'thread/inject_items').length, 1);
});
