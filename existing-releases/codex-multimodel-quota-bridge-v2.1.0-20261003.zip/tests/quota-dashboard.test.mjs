import assert from "node:assert/strict";
import test from "node:test";
import { parseDeepSeekBalance, parseOpenAIRateLimitEvent, parseZaiQuota } from "../scripts/quota-dashboard.mjs";

test("DeepSeek balance parser selects CNY and preserves components", () => {
  assert.deepEqual(parseDeepSeekBalance({ is_available: true, balance_infos: [{ currency: "CNY", total_balance: "69.82", granted_balance: "0.00", topped_up_balance: "69.82" }] }), { available: true, currency: "CNY", total: 69.82, granted: 0, toppedUp: 69.82 });
});

test("GLM parser keeps provider remaining counts and derives remaining percentages", () => {
  const result = parseZaiQuota({ code: 200, success: true, data: { level: "lite", limits: [
    { unit: 3, number: 5, usage: 2000, currentValue: 125, remaining: 1874, percentage: 6, nextResetTime: 1789845816557 },
    { unit: 6, number: 1, usage: 10000, currentValue: 125, remaining: 9874, percentage: 1, nextResetTime: 1790254863984 },
  ] } });
  assert.equal(result.fiveHour.remaining, 1874); assert.equal(result.fiveHour.remainingPercent, 94); assert.equal(result.weekly.remainingPercent, 99);
});

test("GLM parser tolerates a window without nextResetTime", () => {
  const result = parseZaiQuota({ code: 200, success: true, data: { level: "lite", limits: [
    { type: "CREDIT_LIMIT", unit: 3, number: 5, usage: 2000, currentValue: 0, remaining: 2000, percentage: 0 },
    { type: "CREDIT_LIMIT", unit: 6, number: 1, usage: 10000, currentValue: 4482, remaining: 5517, percentage: 44, nextResetTime: 1790254863984 },
  ] } });
  assert.equal(result.fiveHour.resetsAt, null); assert.equal(result.fiveHour.remainingPercent, 100);
  assert.equal(result.weekly.resetsAt, 1790254863984); assert.equal(result.weekly.remainingPercent, 56);
});

test("GLM parser accepts ISO date strings and rejects unreadable reset times with null", () => {
  const make = (value) => parseZaiQuota({ code: 200, success: true, data: { level: "lite", limits: [
    { unit: 3, number: 5, usage: 2000, currentValue: 0, remaining: 2000, percentage: 0, nextResetTime: value },
    { unit: 6, number: 1, usage: 10000, currentValue: 0, remaining: 10000, percentage: 0, nextResetTime: value },
  ] } }).fiveHour.resetsAt;
  assert.equal(make("2026-09-24T12:00:00Z"), Date.parse("2026-09-24T12:00:00Z"));
  assert.equal(make("1790254863984"), 1790254863984);
  assert.equal(make("not-a-time"), null);
  assert.equal(make(undefined), null);
});

test("OpenAI parser converts used percent to weekly remaining percent", () => {
  const line = JSON.stringify({ timestamp: "2026-09-19T16:19:32Z", type: "event_msg", payload: { type: "token_count", rate_limits: { limit_id: "codex", primary: { used_percent: 4, window_minutes: 10080, resets_at: 1790432064 }, plan_type: "prolite" } } });
  const result = parseOpenAIRateLimitEvent(line); assert.equal(result.remainingPercent, 96); assert.equal(result.resetsAt, 1790432064000);
});

test("OpenAI parser ignores non-weekly windows and GLM rejects malformed payloads", () => {
  assert.equal(parseOpenAIRateLimitEvent(JSON.stringify({ payload: { type: "token_count", rate_limits: { primary: { used_percent: 4, window_minutes: 300 } } } })), null);
  assert.throws(() => parseZaiQuota({ code: 200, success: true, data: { limits: [] } }), /5 小时/);
});
