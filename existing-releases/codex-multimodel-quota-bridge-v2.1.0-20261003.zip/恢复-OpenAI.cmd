@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\install-cli-proxy.ps1" -Restore
if errorlevel 1 (
  echo 多模型路由尚未恢复，已停止后续卸载以保留现有配置。
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\run-manager.ps1" uninstall
if errorlevel 1 pause
