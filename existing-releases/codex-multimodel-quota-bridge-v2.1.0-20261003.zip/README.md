# Codex 多模型桥接与额度小窗口

**Codex Desktop / Windows · OpenAI + DeepSeek + GLM · model switching · cross-provider conversation handoff · quota sidebar widget**

这是面向 Windows Codex Desktop 的实验性本地扩展，包含两个可独立调用的 Skill：

- `codex-multimodel-bridge`：在右下角模型菜单选择 OpenAI、DeepSeek、Z.ai GLM，跨供应商复用配对任务并接续工作。
- `codex-inline-quota-widget`：在左侧栏个人资料上方显示 OpenAI、GLM、DeepSeek 的只读额度摘要，点击查看详情。

本项目不是 OpenAI 官方产品，也不提供模型账户或 API 权限。它不修改 WindowsApps 中的 Codex 文件；运行时使用用户级 `CODEX_CLI_PATH` 指向版本化 app-server 代理，并维护界面模型菜单的挂载。Codex 更新后需要重新验证兼容性。

## v2.1.0 更新（2026-10-03）

- **完整运行组件**：从 Windows 已登记的 Codex 安装包复制并校验官方 CLI 与 code-mode、命令执行、sandbox 辅助程序，逐文件 SHA-256 核对；按内容标识复用完整缓存，保留正在运行的旧版本。模型目录和后端代理使用同一套已验证 CLI。
- **桌面冷启动**：补齐并核对官方 cua_node 运行组件，等待真正的界面连接、后端路由和模型菜单就绪。诊断只读取本次启动对应的日志；致命启动错误直接显示原因。Windows 暂不能登记已下载更新时沿用已登记版本，不强制结束现有任务。
- **定时与队列路由**：检查直接 `turn/start`、定时任务与队列携带的模型覆盖，防止把 GPT 请求发进 GLM/DeepSeek 配对任务。发现供应商冲突时请求原配对切换，并明确提示该条指令尚未执行，切换后由用户重新发送。
- **额度服务版本**：启动时核对额度数据源的运行组件版本，避免把仍在监听端口的旧服务当成新版；三源数值口径和侧栏视觉保持一致。
- **可配置执行候选**：临时 worker 默认按 GLM-5.3 Flash → DeepSeek Flash → GPT-6.1 Sol High → GPT-6 Luna High 创建；显式候选与用户选择优先，创建结果不明或执行开始后不自动重放。

本次发布以 `deepseek-codex-picker 0.1.0+codex.20261003174419` 的源码快照为基线。随包测试覆盖 177 项；接收方仍需在自己的 Codex 版本上验收启动、工具执行、模型切换和额度栏。

## 核心功能

- **新版路由与启动**：接入 app-server 代理；冷启动在同一次启动中有界等待，重复启动采用单实例锁。页面刷新后由本地 hook keeper 恢复菜单；只看到菜单或进程存在仍不代表后端路由已生效。
- **模型目录**：从当前 ChatGPT 登录态可访问的 OpenAI 官方目录更新 OpenAI 部分，保留 DeepSeek 与 Z.ai；运行时定期复查，失败时保留上次成功目录。不为目录更新强制重启正在运行的任务。
- **跨供应商接续**：每个任务族为 OpenAI、DeepSeek、Z.ai 保留配对槽位。先读取该项目唯一的 Loop 热状态，再提取最近用户与助手文本；Loop 最多 8,000 字符，交接包合计最多 14,000 字符，不复制工具输出或私有推理。切换回执可在确认丢失后用于对账，结果不明时不自动新建或重放。
- **定时任务绑定**：来源任务有 heartbeat 时，切换前逐项迁移到目标配对任务并读回；迁移、回滚或绑定状态无法确认时，保留来源任务，不把基础切换完成误写为定时任务接续成功。
- **容量错误接续**：仅对有完整原生证据的容量不足或服务器过载轮次尝试一次安全接续；已出现工具执行、助手输出、附件或不明结果时停止自动重放。隔离故障注入通过不代表真实容量故障已自然验收。
- **额度小窗口**：继续显示 OpenAI 的本机 Codex 周额度回执、GLM 5 小时与每周窗口、DeepSeek 官方人民币余额；不可读时显示不可用，不推算额度或发起模型调用。

## 搜索与发现词

`Codex Desktop Windows 多模型`、`Codex DeepSeek GLM 接入`、`Codex 右下角模型切换`、`Codex 跨供应商对话接续`、`Codex 项目 Loop 交接`、`Codex heartbeat 模型切换迁移`、`Codex app-server CODEX_CLI_PATH`、`Codex 自动刷新模型目录`、`Codex quota sidebar widget`、`OpenAI DeepSeek GLM API 额度`。

## 使用与验收

1. 准备 Windows 10/11、已正常安装的 Codex Desktop 和 Node.js 22+，把整个包解压到稳定目录。在包根目录的 PowerShell 中运行 `& '.\scripts\run-manager.ps1' install` 配置 DeepSeek；需要 GLM 时运行 `& '.\scripts\run-manager.ps1' install-zai`。使用自己的账号与独立 Windows DPAPI 凭据，不复制他人的账号配置或加密文件。
2. 完全退出旧 Codex，使用 `启动-Codex-多模型.cmd` 启动。首次启动要核对真实后端代理、右下角模型菜单和左侧额度栏；`scripts/run-manager.ps1 status` 可查看本机状态。需要时用 `刷新-模型目录.cmd` 主动刷新；`恢复-OpenAI.cmd` 用于恢复安装前的 OpenAI 路由设置。
3. 分别用 OpenAI、DeepSeek、GLM 做各自有权限的新任务，再在一个已核对的任务族做跨供应商往返，验证目标供应商、历史可读、窗口选中、输入框可编辑与来源归档。若任务绑定 heartbeat，还要核对定时任务目标；额度栏要实机展开并刷新。

静态测试、启动检查、真实任务切换、模型回答与跨机器兼容性是不同验收层次。仓库随附 `scripts/verify-runtime-acceptance.mjs`、`scripts/verify-handoff-semantics.mjs`、`scripts/verify-capacity-runtime.mjs`，接收方可在自己的环境中按需运行。`恢复-OpenAI.cmd` 不关闭独立的 DeepSeek Harness。

同供应商内换模型沿用当前任务。跨供应商交接材料会发送给目标供应商；是否允许发送私人材料取决于用户对该供应商的授权。不同供应商的图像、工具、MCP 和桌面控制能力需分别验证，菜单可选不表示能力等价。

## 额度栏定位和同类参考

[Codex Quota](https://github.com/keaipiao/codex-quota) 也提供 Windows Codex 侧栏额度面板。本组件是参考同类产品后自行实现、与多模型插件集成的三源 API 显示小窗口，不宣称首创或唯一。GLM 监控接口尚无公开文档，响应结构不符时会显示不可读取。额度读取经本机 app-server 代理访问 `127.0.0.1:18781`；DeepSeek 与 Z.ai 凭据仅由 Windows DPAPI 助手注入本机子进程内存。

## 来源、许可与贡献

- 包含并修改了 [Mochall/codex-model-picker](https://github.com/Mochall/codex-model-picker) 的 MIT 源码；许可证保留在 `vendor/codex-model-picker/LICENSE`。
- [Codex Quota](https://github.com/keaipiao/codex-quota) 与 [onllm-dev/onWatch](https://github.com/onllm-dev/onwatch) 是同类产品和边界研究来源；本包未复制其源码。归属说明见 `THIRD_PARTY_NOTICES.md`。
- 新增与修改部分按本仓库 `LICENSE` 的 MIT 条款发布。EagleRanger 负责需求、产品取舍、实机验收与发布；OpenAI Codex 协助整理、测试、打包和发布核对。
