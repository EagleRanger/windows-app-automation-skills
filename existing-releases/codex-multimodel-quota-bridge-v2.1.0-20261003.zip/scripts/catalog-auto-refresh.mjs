import { join } from "node:path";
import { homedir } from "node:os";
import { syncOpenAiCatalog } from "./openai-catalog.mjs";

// Only the signed-in Codex account decides which OpenAI models are visible.
// Polling updates the shared catalog without changing the selected model or
// touching external-provider credentials and processes.
export function startCatalogAutoRefresh({
  home = join(process.env.CODEX_HOME || join(process.env.USERPROFILE || homedir(), ".codex")),
  intervalMs = 15 * 60_000,
  sync = syncOpenAiCatalog,
  setIntervalImpl = setInterval,
  clearIntervalImpl = clearInterval,
} = {}) {
  if (!Number.isInteger(intervalMs) || intervalMs < 60_000) throw new Error("Catalog refresh interval is invalid.");
  const status = { lastCheckedAt: null, lastChangedAt: null, lastError: null, modelCount: null, checking: false };
  let active = true;
  let inFlight = null;
  async function refresh() {
    if (!active) return null;
    if (inFlight) return inFlight;
    status.checking = true;
    inFlight = (async () => {
      try {
        const result = await sync(home);
        status.lastCheckedAt = new Date().toISOString();
        status.modelCount = result.models.length;
        status.lastError = null;
        if (result.changed) status.lastChangedAt = status.lastCheckedAt;
        return result;
      } catch (error) {
        status.lastCheckedAt = new Date().toISOString();
        status.lastError = error instanceof Error ? error.message : String(error);
        return null;
      } finally {
        status.checking = false;
        inFlight = null;
      }
    })();
    return inFlight;
  }
  const timer = setIntervalImpl(() => { void refresh(); }, intervalMs);
  timer?.unref?.();
  void refresh();
  return { status, refresh, stop() { active = false; clearIntervalImpl(timer); } };
}
