import { fetchDevToolsTargets, selectCodexTaskPage } from "../vendor/codex-model-picker/src/devtools.mjs";

const args = new Map(process.argv.slice(2).map((arg) => {
  const [key, ...parts] = arg.replace(/^--/, "").split("=");
  return [key, parts.join("=")];
}));
const port = Number(args.get("port"));
const threadId = args.get("thread") ?? "";
const turnId = args.get("turn") ?? "";
const idPattern = /^[a-z0-9-]{8,}$/i;

if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("A valid renderer port is required.");
if (!idPattern.test(threadId) || !idPattern.test(turnId)) throw new Error("Concrete task and turn IDs are required.");

const target = selectCodexTaskPage(await fetchDevToolsTargets(port));
if (!target?.webSocketDebuggerUrl) throw new Error("The Codex task page is unavailable.");

const socket = new WebSocket(target.webSocketDebuggerUrl);
const opened = new Promise((resolve, reject) => {
  socket.addEventListener("open", resolve, { once: true });
  socket.addEventListener("error", reject, { once: true });
});
await opened;

try {
  const requestId = 1;
  const response = new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("Turn interruption timed out.")), 15_000);
    socket.addEventListener("message", (event) => {
      const message = JSON.parse(event.data);
      if (message.id !== requestId) return;
      clearTimeout(timer);
      if (message.error) reject(new Error(message.error.message));
      else resolve(message.result);
    });
  });
  const expression = `globalThis.__CODEX_MODEL_PICKER_OVERRIDE__.interruptTurn(${JSON.stringify(threadId)}, ${JSON.stringify(turnId)})`;
  socket.send(JSON.stringify({
    id: requestId,
    method: "Runtime.evaluate",
    params: { expression, awaitPromise: true, returnByValue: true },
  }));
  const result = await response;
  if (result?.exceptionDetails) {
    throw new Error(result.exceptionDetails.exception?.description ?? result.exceptionDetails.text ?? "Turn interruption failed.");
  }
  console.log(JSON.stringify(result?.result?.value ?? {}));
} finally {
  socket.close();
}
