import { homedir } from "node:os";
import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
import { open, readFile, readdir } from "node:fs/promises";
import { createCdpClient } from "../vendor/codex-model-picker/src/cdp-client.mjs";
import { fetchDevToolsTargets, selectCodexTaskPage } from "../vendor/codex-model-picker/src/devtools.mjs";
import { HOOK_VERSION } from "../vendor/codex-model-picker/src/injection-source.mjs";
import { verifyAppServerProxy } from "../vendor/codex-model-picker/src/proxy-doctor.mjs";

const args = new Set(process.argv.slice(2));
const reloadRenderer = args.has("--reload");
const localAppData = process.env.LOCALAPPDATA || join(homedir(), "AppData", "Local");
const codexHome = process.env.CODEX_HOME || join(homedir(), ".codex");
const state = JSON.parse(await readFile(join(localAppData, "CodexModelPicker", "state.json"), "utf8"));
const providerConfig = JSON.parse(await readFile(join(codexHome, "desktop-model-providers.json"), "utf8"));
const rendererPort = Number(state.port);
const mainPort = Number(state.mainInspectorPort);
const proxyMode = state.routingMode === "app-server-proxy";

async function evaluate(port, selector, expression, awaitPromise = false) {
  const targets = await fetchDevToolsTargets(port);
  const target = selector(targets);
  if (!target?.webSocketDebuggerUrl) throw new Error(`No matching inspector target on port ${port}`);
  const cdp = createCdpClient(target.webSocketDebuggerUrl);
  await cdp.opened;
  try {
    const result = await cdp.send("Runtime.evaluate", { expression, awaitPromise, returnByValue: true });
    if (result?.exceptionDetails) throw new Error(result.exceptionDetails.text || "Runtime evaluation failed");
    return result?.result?.value ?? null;
  } finally {
    await cdp.close();
  }
}

const selectMain = (targets) => targets.find((item) => item.type === "node" && item.webSocketDebuggerUrl);
if (reloadRenderer) {
  const safety = await evaluate(rendererPort, selectCodexTaskPage, `({
    draft: Array.from(document.querySelectorAll('textarea,[contenteditable="true"]')).some(e => e.getBoundingClientRect().width > 0 && String(e.value || e.innerText || '').trim()),
    switching: ['checking','handoff'].includes(globalThis.__CODEX_MODEL_PICKER_OVERRIDE__?.providerSwitch?.status)
  })`);
  if (safety?.draft || safety?.switching) throw new Error("Renderer reload skipped: a draft or provider switch is in progress.");
  const page = selectCodexTaskPage(await fetchDevToolsTargets(rendererPort));
  const cdp = createCdpClient(page.webSocketDebuggerUrl);
  await cdp.opened;
  try { await cdp.send("Page.reload", { ignoreCache: true }); } finally { await cdp.close(); }
  await new Promise((resolve) => setTimeout(resolve, 6_000));
}

const main = proxyMode
  ? await verifyAppServerProxy(rendererPort, ["openai", "deepseek", "zai"])
  : await evaluate(mainPort, selectMain, "globalThis.__CODEX_PROVIDER_ROUTER__ ?? null");
const renderer = await evaluate(rendererPort, selectCodexTaskPage, `({
  hookVersion: globalThis.__CODEX_MODEL_PICKER_OVERRIDE__?.hookVersion ?? null,
  hookStatus: globalThis.__CODEX_MODEL_PICKER_OVERRIDE__?.status ?? null,
  overrideApplied: globalThis.__CODEX_MODEL_PICKER_OVERRIDE__?.overrideApplied === true,
  catalogModels: globalThis.__CODEX_MODEL_PICKER_OVERRIDE__?.catalogModels ?? [],
  draftPresent: Array.from(document.querySelectorAll('textarea,[contenteditable="true"]')).some(e => e.getBoundingClientRect().width > 0 && String(e.value || e.innerText || '').trim()),
  quotaWidget: (() => {
    const host = document.querySelector('[id^="codex-quota-widget-host"]');
    const content = String(host?.shadowRoot?.textContent || host?.textContent || '');
    return { present: !!host, visible: !!host && host.getBoundingClientRect().width > 0,
      hasOpenAI: content.includes('OpenAI'), hasGLM: content.includes('GLM'),
      hasDeepSeek: content.includes('DeepSeek') };
  })(),
  listener: typeof globalThis.__CODEX_PROVIDER_SWITCH_LISTENER__,
  sidebarRows: Array.from(document.querySelectorAll('[data-app-action-sidebar-thread-row]')).map(row => ({id:row.dataset.appActionSidebarThreadId,title:row.dataset.appActionSidebarThreadTitle})),
  families: JSON.parse(localStorage.getItem("codex-provider-thread-families-v1") || "null")
})`);

const automationBridge = await evaluate(rendererPort, selectCodexTaskPage, `new Promise((resolve) => {
  const requestId = "automation-bridge-check-" + Date.now();
  const timer = setTimeout(() => { window.removeEventListener("message", onMessage); resolve({ passed: false, reason: "timeout" }); }, 5_000);
  function onMessage(event) {
    const data = event.data;
    if (data?.type !== "fetch-response" || data.requestId !== requestId) return;
    clearTimeout(timer);
    window.removeEventListener("message", onMessage);
    try {
      const result = JSON.parse(data.bodyJsonString ?? "null");
      resolve({ passed: data.responseType === "success" && data.status === 200 && Array.isArray(result?.items), count: result?.items?.length ?? null });
    } catch (error) { resolve({ passed: false, reason: String(error) }); }
  }
  window.addEventListener("message", onMessage);
  Promise.resolve(window.electronBridge?.sendMessageFromView?.({
    type: "fetch", requestId, method: "POST", url: "vscode://codex/list-automations",
    headers: { "content-type": "application/json" }, body: "{}",
  })).catch(error => {
    clearTimeout(timer);
    window.removeEventListener("message", onMessage);
    resolve({ passed: false, reason: String(error) });
  });
})`, true);

const loopRules = Array.isArray(providerConfig.project_loop_roots) ? providerConfig.project_loop_roots : [];
const loopChecks = proxyMode
  ? await evaluate(rendererPort, selectCodexTaskPage, `(async () => {
    const rules = ${JSON.stringify(loopRules)};
    const outputs = [];
    for (let i = 0; i < rules.length; i += 1) {
      const rule = rules[i];
      const value = await new Promise((resolve, reject) => {
        const id = "runtime-loop-" + i + "-" + Date.now();
        const timer = setTimeout(() => { window.removeEventListener("message", onMessage); reject(new Error("Project Loop request timed out")); }, 8000);
        function onMessage(event) {
          const data = event.data;
          if (data?.type !== "mcp-response" || data.message?.id !== id) return;
          clearTimeout(timer);
          window.removeEventListener("message", onMessage);
          if (data.message.error) reject(new Error(data.message.error.message || "Project Loop request failed"));
          else resolve(data.message.result);
        }
        window.addEventListener("message", onMessage);
        Promise.resolve(window.electronBridge?.sendMessageFromView?.({
          type: "mcp-request", hostId: "local", priority: "interactive", source: "thread",
          request: { id, method: "codex/project-loop/read", params: {
            cwd: rule.cwd, threadTitle: rule.titleIncludes || "runtime acceptance", maxChars: 1024,
          } },
        })).catch((error) => { clearTimeout(timer); window.removeEventListener("message", onMessage); reject(error); });
      });
      outputs.push({
        cwd: rule.cwd,
        titleIncludes: rule.titleIncludes ?? null,
        expectedRoot: rule.projectRoot,
        actualRoot: value?.root ?? null,
        status: value?.status ?? null,
        source: value?.source ?? null,
        passed: value?.status === "loaded" && value?.source === ".project-reasoning/STATE.md" && value?.root === rule.projectRoot,
      });
    }
    return outputs;
  })()`, true)
  : await evaluate(mainPort, selectMain, `(async () => {
  const electron = process.getBuiltinModule("module").createRequire(process.cwd() + "/runtime-acceptance.cjs")("electron");
  const handler = electron.ipcMain._invokeHandlers.get("codex_desktop:message-from-view");
  const rules = ${JSON.stringify(loopRules)};
  const outputs = [];
  for (let i = 0; i < rules.length; i += 1) {
    const rule = rules[i];
    let reply = null;
    await handler({ sender: { send(_channel, message) { reply = message; } } }, {
      request: { id: "runtime-loop-" + i, method: "codex/project-loop/read", params: {
        cwd: rule.cwd,
        threadTitle: rule.titleIncludes || "runtime acceptance",
        maxChars: 1024,
      } }
    });
    const value = reply?.message?.result ?? null;
    outputs.push({
      cwd: rule.cwd,
      titleIncludes: rule.titleIncludes ?? null,
      expectedRoot: rule.projectRoot,
      actualRoot: value?.root ?? null,
      status: value?.status ?? null,
      source: value?.source ?? null,
      passed: value?.status === "loaded" && value?.source === ".project-reasoning/STATE.md" && value?.root === rule.projectRoot,
    });
  }
  return outputs;
})()`, true);

const familyState = renderer?.families;
const mappedIds = Object.keys(familyState?.threadToFamily ?? {});
const sidebarRows = renderer?.sidebarRows ?? [];
const nativeRows = JSON.parse(execFileSync("python", ["-X", "utf8", fileURLToPath(new URL("./verify-native-task-catalog.py", import.meta.url))], {
  input: JSON.stringify({ codexHome, mappedIds, sidebarRows, familyIds: Object.keys(familyState?.families ?? {}) }), encoding: "utf8", windowsHide: true,
}));
const indexCounts = new Map();
for (const line of (await readFile(join(codexHome, "session_index.jsonl"), "utf8")).split(/\r?\n/)) {
  if (!line) continue;
  try {
    const id = JSON.parse(line)?.id;
    if (mappedIds.includes(id)) indexCounts.set(id, (indexCounts.get(id) ?? 0) + 1);
  } catch {}
}

async function firstRecord(path) {
  const handle = await open(path, "r");
  try {
    const buffer = Buffer.alloc(262_144);
    const { bytesRead } = await handle.read(buffer, 0, buffer.length, 0);
    const text = buffer.subarray(0, bytesRead).toString("utf8");
    const newline = text.indexOf("\n");
    return JSON.parse(newline >= 0 ? text.slice(0, newline) : text);
  } finally {
    await handle.close();
  }
}

const rolloutById = new Map();
for (const storage of ["sessions", "archived_sessions"]) {
  const root = join(codexHome, storage);
  for (const relative of await readdir(root, { recursive: true })) {
    if (!relative.endsWith(".jsonl") || !mappedIds.some((id) => relative.includes(id))) continue;
    const path = join(root, relative);
    const record = await firstRecord(path);
    const id = record?.payload?.id ?? record?.payload?.session_id;
    if (!mappedIds.includes(id)) continue;
    const entries = rolloutById.get(id) ?? [];
    entries.push({ storage, provider: record?.payload?.model_provider ?? null });
    rolloutById.set(id, entries);
  }
}

const familyChecks = [];
for (const [familyId, family] of Object.entries(familyState?.families ?? {})) {
  const members = [];
  let liveMembers = 0;
  for (const [expectedProvider, threadId] of Object.entries(family.providers ?? {})) {
    const entries = rolloutById.get(threadId) ?? [];
    const storage = [...new Set(entries.map((item) => item.storage))];
    const providers = [...new Set(entries.map((item) => item.provider).filter(Boolean))];
    if (storage.length === 1 && storage[0] === "sessions") liveMembers += 1;
    members.push({
      threadId,
      expectedProvider,
      storage,
      providers,
      indexRows: indexCounts.get(threadId) ?? 0,
      // session_index is an append-only name index; repeated ID lines alone are
      // not duplicated native tasks. Validate the authoritative row and UI.
      passed: entries.length > 0 && storage.length === 1 && providers.length === 1 && providers[0] === expectedProvider &&
        (indexCounts.get(threadId) ?? 0) >= 1 && nativeRows[threadId]?.rolloutExists === true &&
        nativeRows[threadId]?.provider === expectedProvider && nativeRows[threadId]?.archived === (storage[0] === "archived_sessions"),
    });
  }
  familyChecks.push({ familyId, liveMembers, members, passed: liveMembers === 1 && members.every((item) => item.passed) });
}

const checks = {
  noUnmappedActivePeers: nativeRows._unmappedActivePeers.length === 0,
  router: proxyMode
    ? main?.status === "active" && main?.version >= 2 && main?.providerIds?.includes("deepseek") && main?.providerIds?.includes("zai")
    : main?.routerVersion >= 20 && main?.rendererHookPersistence === "active" && !main?.lastRendererHookError,
  renderer: renderer?.hookVersion === HOOK_VERSION && renderer?.listener === "function" && renderer?.overrideApplied === true,
  automationBridge: automationBridge?.passed === true,
  quotaWidget: renderer?.quotaWidget?.present === true && renderer?.quotaWidget?.visible === true &&
    renderer?.quotaWidget?.hasOpenAI === true && renderer?.quotaWidget?.hasGLM === true && renderer?.quotaWidget?.hasDeepSeek === true,
  loops: loopChecks.length > 0 && loopChecks.every((item) => item.passed),
  families: familyChecks.length > 0 && familyChecks.every((item) => item.passed),
  // A pinned task and its project placement may render the same native task
  // twice. Verify each placement resolves to one real rollout instead.
  sidebar: sidebarRows.length > 0 &&
    sidebarRows.filter(row => row.id.startsWith("local:")).every(row => nativeRows[row.id.slice(6)]?.rolloutExists === true),
};
const output = {
  passed: Object.values(checks).every(Boolean),
  reloaded: reloadRenderer,
  checks,
  runtime: {
    routingMode: proxyMode ? "app-server-proxy" : "main-inspector",
    routerVersion: main?.routerVersion ?? main?.version ?? null,
    rendererHookVersion: main?.rendererHookVersion ?? null,
    rendererHookPersistence: main?.rendererHookPersistence ?? null,
    lastRendererHookReason: main?.lastRendererHookReason ?? null,
    listener: renderer?.listener ?? null,
    hookVersion: renderer?.hookVersion ?? null,
    hookStatus: renderer?.hookStatus ?? null,
    overrideApplied: renderer?.overrideApplied ?? false,
    catalogModelCount: renderer?.catalogModels?.length ?? 0,
    draftPresent: renderer?.draftPresent ?? null,
  },
  automationBridge,
  quotaWidget: renderer?.quotaWidget ?? null,
  loopChecks,
  familyCount: familyChecks.length,
  failedFamilies: familyChecks.filter((item) => !item.passed),
  acceptanceScope: "runtime_structure_only; native reply and semantic handoff require separate evidence",
  unmappedActivePeers: nativeRows._unmappedActivePeers,
  sidebarRowsChecked: sidebarRows.length,
  duplicateSidebarRows: sidebarRows.filter((row, index) => sidebarRows.findIndex((candidate) => candidate.id === row.id) !== index),
  invalidSidebarRows: sidebarRows.filter(row => row.id.startsWith("local:") && nativeRows[row.id.slice(6)]?.rolloutExists !== true),
};
console.log(JSON.stringify(output, null, 2));
if (!output.passed) process.exitCode = 1;
