﻿$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Verb RunAs -ArgumentList ('-NoProfile -File "' + $PSCommandPath + '"') -Wait
    exit
}
try {
    $package = Get-AppxPackage -Name OpenAI.Codex
    if (-not $package) { throw 'Codex package not found.' }
    $appRoot = $package.InstallLocation.TrimEnd('\') + '\'
    $running = @(Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($appRoot, [StringComparison]::OrdinalIgnoreCase) })
    if ($running.Count) { throw 'Please exit all Codex windows and its tray icon, then run this repair again. No process has been stopped.' }
    Add-AppxPackage -Register (Join-Path $package.InstallLocation 'AppxManifest.xml') -DisableDevelopmentMode
    Start-Service -Name 'CodexSandboxService.OpenAI.Codex'
    Get-Service -Name 'CodexSandboxService.OpenAI.Codex' | Format-Table Name,Status,StartType
    Write-Host 'Package repaired. Reopen Codex and retry Windows setup; then verify a normal command.'
} catch { Write-Host $_.Exception.Message -ForegroundColor Red }
Read-Host 'Press Enter to close'
