"""Read-only native task identity check. Never changes Codex data."""
import json, os, sqlite3, sys
sys.stdout.reconfigure(encoding='utf-8')
spec=json.load(sys.stdin)
c=sqlite3.connect('file:'+os.path.join(spec['codexHome'],'state_5.sqlite').replace('\\','/')+'?mode=ro',uri=True)
c.row_factory=sqlite3.Row
ids=set(spec['mappedIds']) | {r['id'].removeprefix('local:') for r in spec['sidebarRows'] if r['id'].startswith('local:')}
rows={}
for task_id in ids:
 row=c.execute('select id,model_provider,archived,rollout_path from threads where id=?',(task_id,)).fetchone()
 rows[task_id]=None if row is None else {'provider':row['model_provider'],'archived':bool(row['archived']),'rolloutExists':os.path.isfile(row['rollout_path'])}
# Audit only: equal names are evidence to review, never authority to merge/delete.
# Include the family key: it may be the original task that was lost from slots.
peers={}
mapped=set(spec['mappedIds'])
for task_id in mapped | set(spec.get('familyIds', [])):
 anchor=c.execute('select name,cwd from threads where id=?',(task_id,)).fetchone()
 if anchor is None or not anchor['name']:
  continue
 for peer in c.execute('select id,name,cwd,model_provider from threads where name=? and archived=0',(anchor['name'],)):
  if peer['id'] not in mapped and os.path.normcase(os.path.realpath(peer['cwd'])) == os.path.normcase(os.path.realpath(anchor['cwd'])):
   peers[peer['id']]=dict(peer)
rows['_unmappedActivePeers']=list(peers.values())
print(json.dumps(rows))
