export function mergeProviderRouting(previous, update) {
  const providers = new Map((previous?.providers ?? []).map(p => [p.id, p]));
  for (const p of update.providers ?? []) providers.set(p.id, p);
  return {
    ...previous, ...update,
    providers: [...providers.values()],
    model_providers: { ...previous?.model_providers, ...update.model_providers },
  };
}
