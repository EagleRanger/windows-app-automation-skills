import { readFile } from 'node:fs/promises';
import { join } from 'node:path';
import { homedir } from 'node:os';
import { createCdpClient } from '../vendor/codex-model-picker/src/cdp-client.mjs';
import { buildInjectionSource, HOOK_VERSION } from '../vendor/codex-model-picker/src/injection-source.mjs';
import { buildMainInjectionSource } from '../vendor/codex-model-picker/src/main-injection-source.mjs';
import { createCapacityRecovery } from '../vendor/codex-model-picker/src/capacity-recovery.mjs';

const state = JSON.parse(await readFile(join(process.env.LOCALAPPDATA || join(homedir(),'AppData','Local'),'CodexModelPicker','state.json'),'utf8'));
const routing = JSON.parse(await readFile(join(process.env.CODEX_HOME || join(homedir(),'.codex'),'desktop-model-providers.json'),'utf8'));
async function evaluate(port, predicate, expression) {
  const targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
  const target = targets.find(predicate);
  if (!target) throw new Error('Required Codex inspector target unavailable');
  const c = createCdpClient(target.webSocketDebuggerUrl); await c.opened;
  try {
    const result = await c.send('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});
    if(result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text);
    return result.result.value;
  } finally { await c.close(); }
}
const page = t => t.type === 'page' && t.url === 'app://-/index.html';
if(process.argv.includes('--install-hooks')) {
  const rendererHookSource=buildInjectionSource({catalogModels:state.selectedCatalogModels,additionalModels:state.expectedModels});
  await evaluate(state.mainInspectorPort,t=>t.type==='node',buildMainInjectionSource({providerByModel:routing.model_providers,projectLoopRoots:routing.project_loop_roots||[],rendererHookSource,rendererHookVersion:HOOK_VERSION}));
  await evaluate(state.port,page,rendererHookSource);
}
const installed = await evaluate(state.port,page,`({hookVersion:globalThis.__CODEX_MODEL_PICKER_OVERRIDE__?.hookVersion,capacityVersion:globalThis.__CODEX_MODEL_PICKER_OVERRIDE__?.capacityRecovery?.version})`);
if(installed.hookVersion!==HOOK_VERSION||installed.capacityVersion!==1) throw new Error('Current page did not load capacity controller');

// Native IPC smoke check: invalid/nonexistent thread, no thread/start, no model request.
const nativeCapture = await evaluate(state.port,page,`(async()=>{
 const before=globalThis.__CODEX_MODEL_PICKER_OVERRIDE__.capacityRecovery.capturedRequests;
 const response=await new Promise(resolve=>{
  const id='capacity-native-readiness-'+Date.now();
  const timer=setTimeout(()=>{window.removeEventListener('message',on);resolve({timeout:true})},8000);
  function on(e){if(e.data?.type==='mcp-response'&&e.data.message?.id===id){clearTimeout(timer);window.removeEventListener('message',on);resolve(e.data.message)}}
  window.addEventListener('message',on);
  window.electronBridge.sendMessageFromView({type:'mcp-request',hostId:'local',request:{id,method:'turn/start',params:{threadId:'00000000-0000-4000-8000-000000000000',model:'gpt-6-luna',input:[{type:'text',text:'Local IPC readiness check; this thread does not exist.'}]}},priority:'interactive',source:'thread'});
 });
 const after=globalThis.__CODEX_MODEL_PICKER_OVERRIDE__.capacityRecovery.capturedRequests;
 return {captured:after===before+1,rejectedBeforeExecution:!!response.error&&/not found|no rollout|unknown thread|thread.*does not exist/i.test(response.error.message),error:response.error?.message};
})()`);

const simulations = await evaluate(state.port,page,`(async()=>{
 const create=${createCapacityRecovery.toString()};
 const results=[];
 for(const mode of ['safe','tool-already-started','uncertain-dispatch']){
  const calls=[],notices=[];let model='gpt-5.6-sol',ledger={};
  const turn={id:'turn',status:'inProgress',items:[{type:'userMessage',content:[{type:'text',text:'isolated test'}]},...(mode==='tool-already-started'?[{type:'commandExecution'}]:[])]};
  const c=create({readLedger:()=>ledger,writeLedger:v=>ledger=v,pause:async()=>{},selected:()=>true,notify:(...v)=>notices.push(v),candidates:()=>[{threadId:'source',model:'gpt-6-luna',provider:'openai',effort:'high'}],switchTask:async()=>{model='gpt-6-luna';return{threadId:'source'};},request:async(method,p)=>{
   calls.push(method);
   if(method==='thread/turns/list')return{data:[turn]};
   if(method==='turn/interrupt'){turn.status='interrupted';return{};}
   if(method==='thread/read')return{thread:{id:'source',model,modelProvider:'openai'}};
   if(method==='turn/start'){if(mode==='uncertain-dispatch')throw Error('timeout');return{turn:{id:'continued'}};}
   return{};
  }});
  c.observe({type:'codex-capacity-turn-request',requestId:'req',model,params:{threadId:'source',model,input:[{type:'text',text:'isolated test'}]}});
  c.observe({type:'mcp-response',message:{id:'req',result:{turn:{id:'turn'}}}});
  const event={type:'mcp-notification',method:'error',params:{threadId:'source',turnId:'turn',willRetry:true,error:{codexErrorInfo:'serverOverloaded',message:'Selected model is at capacity. Please try a different model.'}}};
  await c.observe(event);await c.observe(event);
  const count=calls.filter(m=>m==='turn/start').length;
  results.push({mode,starts:count,interrupts:calls.filter(m=>m==='turn/interrupt').length,status:c.diagnostics.last?.status,passed:count===(mode==='tool-already-started'?0:1)&&c.diagnostics.last?.status===({safe:'replayed','tool-already-started':'unsafe','uncertain-dispatch':'dispatch_uncertain'}[mode])});
 }
 return results;
})()`);
const result={installed,nativeCapture,liveRendererFaultInjection:simulations,realProviderCapacityIncidentVerified:false,passed:nativeCapture.captured&&nativeCapture.rejectedBeforeExecution&&simulations.every(r=>r.passed)};
console.log(JSON.stringify(result,null,2));
if(!result.passed)process.exitCode=1;
