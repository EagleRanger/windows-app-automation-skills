﻿param(
    [ValidateSet('Menu', 'OpenAI', 'DeepSeekFlash', 'DeepSeekPro', 'Status')]
    [string]$Mode = 'Menu',
    [switch]$NoLaunch
)

$ErrorActionPreference = 'Stop'
$manager = Join-Path $PSScriptRoot 'run-manager.ps1'
$launcher = Join-Path $PSScriptRoot 'launch-deepseek.ps1'

if ($Mode -eq 'Status') {
    & $manager status
    exit $LASTEXITCODE
}

if ($NoLaunch) {
    & $manager install --offline
    exit $LASTEXITCODE
}

Write-Output '旧的全局供应商切换已停用；将打开统一模型菜单，ChatGPT 登录保持不变。'
& $launcher
exit $LASTEXITCODE
