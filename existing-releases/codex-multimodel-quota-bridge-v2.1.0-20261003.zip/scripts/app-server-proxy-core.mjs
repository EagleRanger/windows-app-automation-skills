export const APP_SERVER_PROXY_VERSION = 3;

const MODEL_SELECTION_KEYS = new Set([
  "model", "reasoningEffort", "modelReasoningEffort", "effort", "thinking",
]);

export function createAppServerRouter({
  providerByModel = {},
  defaultProvider = "openai",
} = {}) {
  const providerByThreadId = new Map();
  const familyProviderByThreadId = new Map();
  const selectedModelByThreadId = new Map();
  const pending = new Map();
  const counts = { starts: 0, resumes: 0, forks: 0, switches: 0 };
  const allowedProviders = new Set([defaultProvider, ...Object.values(providerByModel)]);
  const providerForModel = (model) => providerByModel[model] ?? defaultProvider;

  function syncFamilies(params) {
    if (params?.version !== 1 || !params.providerByThreadId ||
        typeof params.providerByThreadId !== "object" ||
        Array.isArray(params.providerByThreadId)) {
      throw new Error("Provider-family sync payload is invalid.");
    }
    const entries = Object.entries(params.providerByThreadId);
    if (entries.length > 5_000) throw new Error("Provider-family sync payload is too large.");
    familyProviderByThreadId.clear();
    for (const [threadId, provider] of entries) {
      if (typeof threadId !== "string" || !threadId || threadId.length > 128 ||
          !allowedProviders.has(provider)) {
        throw new Error("Provider-family sync contains an invalid mapping.");
      }
      familyProviderByThreadId.set(threadId, provider);
      providerByThreadId.set(threadId, provider);
    }
    return { version: 1, accepted: entries.length };
  }

  function route(message) {
    if (!message || typeof message !== "object" || Array.isArray(message)) {
      return { forward: message, notifications: [] };
    }
    const { method, id } = message;
    const params = message.params && typeof message.params === "object"
      ? message.params : null;
    const notifications = [];
    if (method === "codex/provider-router/status") {
      return {
        reply: { id, result: {
          version: APP_SERVER_PROXY_VERSION,
          status: "active",
          providerIds: [...allowedProviders],
          mappedModels: Object.keys(providerByModel),
          familyCount: familyProviderByThreadId.size,
          counts: { ...counts },
          pid: process.pid,
        } },
        notifications,
      };
    }
    if (method === "codex/provider-families/sync") {
      try { return { reply: { id, result: syncFamilies(params) }, notifications }; }
      catch (error) {
        return { reply: { id, error: { code: -32602, message: String(error.message) } }, notifications };
      }
    }
    if (method === "thread/list" && params) params.modelProviders = [];
    if (method === "thread/read" && params && id != null) {
      pending.set(id, { method, threadId: params.threadId });
    }
    if (["thread/start", "thread/resume", "thread/fork"].includes(method) && params) {
      const threadId = typeof params.threadId === "string" ? params.threadId : "";
      const knownProvider = threadId
        ? familyProviderByThreadId.get(threadId) ?? providerByThreadId.get(threadId)
        : null;
      if (method === "thread/fork" && !params.model && selectedModelByThreadId.has(threadId)) {
        const inheritedModel = selectedModelByThreadId.get(threadId);
        if (!knownProvider || providerForModel(inheritedModel) === knownProvider) {
          params.model = inheritedModel;
        }
      }
      let model = typeof params.model === "string" ? params.model : "";
      if (knownProvider && model && providerForModel(model) !== knownProvider) {
        delete params.model;
        for (const key of MODEL_SELECTION_KEYS) delete params[key];
        model = "";
      }
      const provider = knownProvider ?? (model ? providerForModel(model) : defaultProvider);
      params.modelProvider = provider;
      if (method === "thread/start") counts.starts++;
      if (method === "thread/resume") counts.resumes++;
      if (method === "thread/fork") counts.forks++;
      if (threadId) {
        providerByThreadId.set(threadId, provider);
        if (model) selectedModelByThreadId.set(threadId, model);
      }
      if (id != null) pending.set(id, { method, model, provider, threadId });
    }
    if (method === "thread/settings/update" && params) {
      const bypass = params.__codexProviderSwitchBypass === true;
      delete params.__codexProviderSwitchBypass;
      const model = typeof params.model === "string" ? params.model : "";
      const threadId = typeof params.threadId === "string" ? params.threadId : "";
      const provider = providerForModel(model);
      const sourceProvider = familyProviderByThreadId.get(threadId) ??
        providerByThreadId.get(threadId) ?? null;
      const needsSwitch = Boolean(model && threadId && !bypass &&
        (sourceProvider ? sourceProvider !== provider : provider !== defaultProvider));
      if (needsSwitch) {
        counts.switches++;
        notifications.push({ method: "codex/provider-switch-request", params: {
          sourceThreadId: threadId,
          model,
          provider,
          settings: { ...params },
          routerVersion: APP_SERVER_PROXY_VERSION,
          requestedAt: new Date().toISOString(),
        } });
        const onlyModel = Object.keys(params).filter((key) => key !== "threadId")
          .every((key) => MODEL_SELECTION_KEYS.has(key));
        if (onlyModel) return { reply: { id, result: {} }, notifications };
        delete params.model;
        delete params.modelProvider;
      } else if (model && threadId) {
        providerByThreadId.set(threadId, provider);
        selectedModelByThreadId.set(threadId, model);
      }
    }
    if (["turn/start", "turn/steer", "thread/queue/add"].includes(method) && params?.threadId) {
      // Schedulers and full composer snapshots can supply a model directly on
      // turn/start, bypassing thread/settings/update. Never send GPT to a GLM
      // slot (or vice versa), and never replay user work after an uncertain call.
      const sourceProvider = familyProviderByThreadId.get(params.threadId) ?? providerByThreadId.get(params.threadId);
      const model = params.model ?? params.collaborationMode?.settings?.model ?? selectedModelByThreadId.get(params.threadId);
      if (sourceProvider && model && providerForModel(model) !== sourceProvider) {
        counts.switches++;
        notifications.push({ method: "codex/provider-switch-request", params: {
          sourceThreadId: params.threadId, model, provider: providerForModel(model),
          settings: { threadId: params.threadId, model, ...(params.effort ? { reasoningEffort: params.effort } : {}) },
          routerVersion: APP_SERVER_PROXY_VERSION, requestedAt: new Date().toISOString(),
        } });
        return { reply: { id, error: { code: -32602,
          message: "模型与当前任务供应商不一致，已请求切换到配对任务。本条指令尚未执行；切换完成后请在目标任务重新发送。"
        } }, notifications };
      }
      const recovery = params.__codexCapacityRecovery === true;
      delete params.__codexCapacityRecovery;
      notifications.push({ method: "codex/capacity-turn-request", params: {
        requestId: id,
        model: params.model ?? selectedModelByThreadId.get(params.threadId) ?? null,
        params: method === "turn/start" && JSON.stringify(params).length <= 65_536
          ? { ...params } : { threadId: params.threadId },
        recovery: recovery || method !== "turn/start",
      } });
    }
    return { forward: message, notifications };
  }

  function observe(message) {
    if (!message || message.id == null) return;
    const record = pending.get(message.id);
    if (!record) return;
    pending.delete(message.id);
    if (message.error || !message.result) return;
    const thread = message.result.thread ?? message.result.result?.thread;
    const threadId = thread?.id ?? record.threadId;
    if (typeof threadId !== "string" || !threadId) return;
    const model = record.model || thread?.model || "";
    const provider = familyProviderByThreadId.get(threadId) || record.provider ||
      thread?.modelProvider || (model ? providerForModel(model) : "");
    if (provider) providerByThreadId.set(threadId, provider);
    if (model) selectedModelByThreadId.set(threadId, model);
  }

  return { route, observe, providerForModel };
}
