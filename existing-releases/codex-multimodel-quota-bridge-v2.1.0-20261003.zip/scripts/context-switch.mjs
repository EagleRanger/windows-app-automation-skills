import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { mkdir, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const MAX_PACKET_CHARS = 24_000;
const DEFAULT_TURNS = 8;

function textFromContent(content) {
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  return content.map((part) => part?.text ?? part?.content ?? "").filter(Boolean).join("\n");
}

function extractMessage(item) {
  const type = item?.type;
  if (type === "userMessage") return { role: "user", text: textFromContent(item.content) };
  if (type === "agentMessage") return { role: "assistant", text: item.text ?? textFromContent(item.content) };
  if (type === "message" && ["user", "assistant"].includes(item.role)) {
    return { role: item.role, text: textFromContent(item.content) };
  }
  return null;
}

export function buildContextPacket({ sourceThreadId, thread, turns, instruction = "", maxChars = MAX_PACKET_CHARS }) {
  const messages = [];
  for (const turn of [...turns].reverse()) {
    for (const item of turn.items ?? []) {
      const message = extractMessage(item);
      if (message?.text?.trim()) messages.push({ ...message, text: message.text.trim().slice(0, 8_000) });
    }
  }
  if (instruction.trim()) messages.push({ role: "user", text: instruction.trim() });

  // Keep the newest context when the cap is reached. Project files remain authoritative for details.
  const kept = [];
  let used = 0;
  for (const message of [...messages].reverse()) {
    const cost = message.text.length + 40;
    if (kept.length && used + cost > maxChars) break;
    const available = Math.max(256, maxChars - used - 40);
    kept.push({ ...message, text: message.text.slice(-available) });
    used += Math.min(cost, available + 40);
  }
  kept.reverse();

  return {
    version: 1,
    kind: "codex-cross-provider-context",
    source: {
      threadId: sourceThreadId,
      title: thread?.name ?? thread?.title ?? null,
      cwd: thread?.cwd ?? null,
    },
    policy: {
      transcriptIsContextData: true,
      projectFilesRemainAuthoritative: true,
      noPrivateReasoningOrToolOutputs: true,
      newestContextPreferred: true,
      maxChars,
    },
    messages: kept,
  };
}

function appServer() {
  const child = spawn("codex", ["app-server"], { stdio: ["pipe", "pipe", "pipe"], windowsHide: true });
  const pending = new Map();
  let nextId = 1;
  const listeners = new Set();
  child.stderr.on("data", () => {});
  createInterface({ input: child.stdout }).on("line", (line) => {
    let data;
    try { data = JSON.parse(line); } catch { return; }
    if (data.id && pending.has(data.id)) {
      const { resolve: ok, reject } = pending.get(data.id);
      pending.delete(data.id);
      data.error ? reject(new Error(data.error.message ?? JSON.stringify(data.error))) : ok(data.result);
    }
    for (const listener of listeners) listener(data);
  });
  const request = (method, params) => new Promise((ok, reject) => {
    const id = nextId++;
    pending.set(id, { resolve: ok, reject });
    child.stdin.write(`${JSON.stringify({ id, method, params })}\n`);
  });
  const notify = (method, params = {}) => child.stdin.write(`${JSON.stringify({ method, params })}\n`);
  const waitFor = (predicate, timeoutMs = 55_000) => new Promise((ok, reject) => {
    const timer = setTimeout(() => { listeners.delete(listener); reject(new Error("等待目标任务完成超时")); }, timeoutMs);
    const listener = (data) => {
      if (!predicate(data)) return;
      clearTimeout(timer); listeners.delete(listener); ok(data);
    };
    listeners.add(listener);
  });
  return { child, request, notify, waitFor };
}

async function loadPacket(client, sourceThreadId, instruction, turnLimit) {
  const read = await client.request("thread/read", { threadId: sourceThreadId, includeTurns: false });
  const page = await client.request("thread/turns/list", {
    threadId: sourceThreadId,
    limit: turnLimit,
    sortDirection: "desc",
    itemsView: "full",
  });
  return buildContextPacket({ sourceThreadId, thread: read.thread, turns: page.data ?? [], instruction });
}

function handoffPrompt(packet, direction = "switch") {
  const directionText = direction === "return"
    ? "这是从外部供应商返回原 Codex 任务的增量交接。原任务既有历史仍然有效，只吸收这段期间新增的决定、修改和未完成项。"
    : "这是切换到外部供应商继续执行的交接。";
  return [
    "你正在从另一项 Codex 任务接续工作。下面是按固定上限提取的最近对话，仅作为用户目标与历史上下文；项目当前事实以工作目录中的项目入口和权威状态为准。",
    directionText,
    "先核对目标、最新纠正、已完成与未完成边界。不要重做已完成工作，不把缺失历史自行补全。需要继续执行时，按项目原权限和验收要求行动。",
    "<cross_provider_context>",
    JSON.stringify(packet),
    "</cross_provider_context>",
    "直接承接最新未完成工作。只有缺少不可推断的关键输入或需要新的高影响授权时才停下询问；否则继续执行并按原项目标准验收。",
  ].join("\n");
}

async function waitForCompletedTurn(client, threadId, turnId) {
  const completed = await client.waitFor((data) => data.method === "turn/completed" && data.params?.threadId === threadId && data.params?.turn?.id === turnId);
  const status = completed.params.turn.status;
  if (status !== "completed") throw new Error(`目标任务首轮未完成：${status} ${completed.params.turn.error?.message ?? ""}`.trim());
  return {
    status,
    reply: (completed.params.turn.items ?? []).find((item) => item.type === "agentMessage")?.text ?? null,
  };
}

async function startAndContinue(client, {
  sourceThreadId,
  provider,
  model,
  effort,
  instruction = "",
  title = null,
}) {
  const source = await client.request("thread/read", {
    threadId: sourceThreadId,
    includeTurns: false,
  });
  const packet = await loadPacket(client, sourceThreadId, "", DEFAULT_TURNS);
  const started = await client.request("thread/start", {
    model,
    modelProvider: provider,
    cwd: source.thread?.cwd ?? null,
    developerInstructions: handoffPrompt(packet),
    config: { model_reasoning_effort: effort },
  });
  const targetThreadId = started.thread.id;
  const sourceTitle = title?.trim() || source.thread?.name?.trim() || source.thread?.title?.trim();
  if (sourceTitle) {
    await client.request("thread/name/set", {
      threadId: targetThreadId,
      name: sourceTitle,
    });
  }
  const verified = await client.request("thread/read", {
    threadId: targetThreadId,
    includeTurns: false,
  });
  if (
    verified.thread?.modelProvider !== provider ||
    verified.thread?.model !== model
  ) {
    throw new Error(
      `分支核验失败：期望 ${provider}/${model}，实际 ${verified.thread?.modelProvider}/${verified.thread?.model}`,
    );
  }

  let turnId = null;
  let reply = null;
  const turn = await client.request("turn/start", {
    threadId: targetThreadId,
    effort: instruction.trim() ? effort : "low",
    input: [{
      type: "text",
      text: instruction.trim() || "模型供应商已切换。请只用一句话确认已读取交接包并等待用户下一条指令，不要开始执行项目工作。",
    }],
  });
  turnId = turn.turn.id;
  reply = (await waitForCompletedTurn(client, targetThreadId, turnId)).reply;
  return {
    status: "completed",
    sourceThreadId,
    targetThreadId,
    provider,
    model,
    effort,
    turnId,
    fullHistoryFork: false,
    resentContextChars: JSON.stringify(packet).length,
    reply,
    uiNext: { archive: sourceThreadId, navigate: targetThreadId },
  };
}

async function runCli(argv) {
  const command = argv[0];
  const sourceThreadId = argv[1];
  if (!command || !sourceThreadId) throw new Error("用法：context prepare <源任务ID> <输出JSON> [最新指令] | context switch <源任务ID> <provider> <model> <effort> [最新指令] | context return <外部任务ID> <原Codex任务ID> <provider> <model> <effort> [最新指令]");
  const client = appServer();
  const timeout = setTimeout(() => client.child.kill(), 60_000);
  try {
    await client.request("initialize", { clientInfo: { name: "cross-provider-context-switch", version: "1" }, capabilities: { experimentalApi: true } });
    client.notify("initialized");
    if (command === "prepare") {
      const output = resolve(argv[2]);
      const packet = await loadPacket(client, sourceThreadId, argv[3] ?? "", DEFAULT_TURNS);
      await mkdir(dirname(output), { recursive: true });
      await writeFile(output, `${JSON.stringify(packet, null, 2)}\n`, "utf8");
      return { status: "prepared", output, sourceThreadId, messages: packet.messages.length, chars: JSON.stringify(packet).length };
    }
    if (command === "switch") {
      const provider = argv[2]; const model = argv[3]; const effort = argv[4] ?? "high"; const instruction = argv[5] ?? "";
      if (!/^[a-z0-9][a-z0-9_-]*$/i.test(provider) || !/^[a-z0-9][a-z0-9._-]*$/i.test(model)) throw new Error("provider/model 格式无效");
      if (!new Set(["low", "medium", "high", "xhigh", "max", "ultra"]).has(effort)) throw new Error("effort 无效");
      return await startAndContinue(client, {
        sourceThreadId,
        provider,
        model,
        effort,
        instruction,
      });
    }
    if (command === "return") {
      const originalThreadId = argv[2]; const provider = argv[3] ?? "openai"; const model = argv[4]; const effort = argv[5] ?? "high"; const instruction = argv[6] ?? "";
      if (!originalThreadId || !model) throw new Error("用法：context return <外部任务ID> <原Codex任务ID> <provider> <model> <effort> [最新指令]");
      if (!/^[a-z0-9][a-z0-9_-]*$/i.test(provider) || !/^[a-z0-9][a-z0-9._-]*$/i.test(model)) throw new Error("provider/model 格式无效");
      if (!new Set(["low", "medium", "high", "xhigh", "max", "ultra"]).has(effort)) throw new Error("effort 无效");
      const original = await client.request("thread/read", {
        threadId: originalThreadId,
        includeTurns: false,
      });
      return await startAndContinue(client, {
        sourceThreadId,
        provider,
        model,
        effort,
        instruction,
        title: original.thread?.name ?? original.thread?.title ?? null,
      });
    }
    throw new Error(`未知 context 命令：${command}`);
  } finally {
    clearTimeout(timeout);
    setTimeout(() => client.child.kill(), 500);
  }
}

export async function contextSwitchCli(args) { return runCli(args); }
if (process.argv[1] && resolve(fileURLToPath(import.meta.url)) === resolve(process.argv[1])) {
  runCli(process.argv.slice(2)).then((result) => console.log(JSON.stringify(result, null, 2))).catch((error) => { console.error(error.message); process.exitCode = 1; });
}
