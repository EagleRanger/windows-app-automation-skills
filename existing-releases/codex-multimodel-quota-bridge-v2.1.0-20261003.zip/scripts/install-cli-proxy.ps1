﻿param([switch]$Restore)

$ErrorActionPreference = 'Stop'
$sourceRoot = $PSScriptRoot
$runtimeRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'CodexModelPicker\proxy-runtime'))
$rollbackPath = Join-Path $runtimeRoot 'environment-rollback.json'
$registryPath = 'HKCU:\Environment'

function Get-SourceHash([string]$path) {
    $sha256 = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($path)
    try { return [BitConverter]::ToString($sha256.ComputeHash($stream)).Replace('-', '') }
    finally { $stream.Dispose(); $sha256.Dispose() }
}

function Broadcast-EnvironmentChange {
    $source = @'
using System;
using System.Runtime.InteropServices;
public static class CodexPickerEnvironmentBroadcast {
    [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    public static extern IntPtr SendMessageTimeout(IntPtr window, uint message, UIntPtr wParam,
        string lParam, uint flags, uint timeout, out UIntPtr result);
}
'@
    if (-not ('CodexPickerEnvironmentBroadcast' -as [type])) {
        Add-Type -TypeDefinition $source -Language CSharp
    }
    $result = [UIntPtr]::Zero
    [void][CodexPickerEnvironmentBroadcast]::SendMessageTimeout(
        [IntPtr]0xffff, 0x1a, [UIntPtr]::Zero, 'Environment', 0x2, 2000, [ref]$result)
}

if ($Restore) {
    if (-not (Test-Path -LiteralPath $rollbackPath)) {
        Write-Output '没有已安装的多模型 CLI 代理，无需恢复。'
        exit 0
    }
    $saved = Get-Content -LiteralPath $rollbackPath -Raw | ConvertFrom-Json
    try { $current = Get-ItemPropertyValue -Path $registryPath -Name 'CODEX_CLI_PATH' -ErrorAction Stop }
    catch { $current = $null }
    if ($null -eq $current -and -not $saved.hadPreviousValue) {
        Write-Output '用户级多模型代理未启用，无需恢复。'
        exit 0
    }
    if ($current -ne $saved.installedPath) {
        throw 'CODEX_CLI_PATH 已由其他程序修改；为避免覆盖新设置，本次没有恢复。'
    }
    if ($saved.hadPreviousValue) {
        Set-ItemProperty -Path $registryPath -Name 'CODEX_CLI_PATH' -Value $saved.previousValue
    } else {
        Remove-ItemProperty -Path $registryPath -Name 'CODEX_CLI_PATH' -ErrorAction SilentlyContinue
    }
    Broadcast-EnvironmentChange
    Write-Output 'CODEX_CLI_PATH 已恢复。正在运行的 Codex 不受本次修改影响。'
    exit 0
}

$names = @('codex-cli-proxy.cs', 'codex-cli.mjs', 'app-server-proxy.mjs', 'app-server-proxy-core.mjs')
$hashInput = ($names | ForEach-Object {
    $file = Join-Path $sourceRoot $_
    if (-not (Test-Path -LiteralPath $file)) { throw "缺少代理源文件：$file" }
    Get-SourceHash $file
}) -join ':'
$sha = [Security.Cryptography.SHA256]::Create()
try {
    $digest = [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($hashInput))).Replace('-', '').Substring(0, 12).ToLowerInvariant()
} finally { $sha.Dispose() }
$versionRoot = [IO.Path]::GetFullPath((Join-Path $runtimeRoot $digest))
if (-not $versionRoot.StartsWith($runtimeRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)) {
    throw '代理运行目录超出预期范围。'
}
New-Item -ItemType Directory -Path $versionRoot -Force | Out-Null
$shimHash = Get-SourceHash (Join-Path $sourceRoot 'codex-cli-proxy.cs')
foreach ($name in $names | Where-Object { $_ -ne 'codex-cli-proxy.cs' }) {
    Copy-Item -LiteralPath (Join-Path $sourceRoot $name) -Destination (Join-Path $versionRoot $name) -Force
    if ((Get-SourceHash (Join-Path $sourceRoot $name)) -ne
        (Get-SourceHash (Join-Path $versionRoot $name))) {
        throw "代理文件复制校验失败：$name"
    }
}
$exe = Join-Path $versionRoot 'codex-cli-proxy.exe'
if (-not (Test-Path -LiteralPath $exe)) {
    $compiler = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
    if (-not (Test-Path -LiteralPath $compiler)) { throw '系统缺少 C# 编译器。' }
    & $compiler /nologo /target:exe "/out:$exe" (Join-Path $sourceRoot 'codex-cli-proxy.cs')
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $exe)) {
        throw 'Codex CLI 代理编译失败或被安全软件隔离。'
    }
}
$shimMarker = Join-Path $versionRoot 'shim-source.sha256'
Set-Content -LiteralPath $shimMarker -Value $shimHash -Encoding ascii
$versionOutput = & $exe --version 2>&1
$cliVersionLine = $versionOutput | Where-Object { [string]$_ -match '^codex-cli\s+\S+' } | Select-Object -First 1
if ($LASTEXITCODE -ne 0 -or -not $cliVersionLine) {
    throw "Codex CLI 代理自检失败：$($versionOutput -join ' ')"
}

try { $previous = Get-ItemPropertyValue -Path $registryPath -Name 'CODEX_CLI_PATH' -ErrorAction Stop }
catch { $previous = $null }
if (-not (Test-Path -LiteralPath $rollbackPath)) {
    $saved = @{ hadPreviousValue = $null -ne $previous; previousValue = $previous; installedPath = $exe }
} else {
    $saved = Get-Content -LiteralPath $rollbackPath -Raw | ConvertFrom-Json
    if ($null -ne $previous -and $previous -ne $saved.installedPath -and $previous -ne $exe) {
        throw 'CODEX_CLI_PATH 已由其他程序修改；为避免覆盖现有设置，本次没有安装。'
    }
    $saved.installedPath = $exe
}
if ($previous -ne $exe) {
    try {
        Set-ItemProperty -Path $registryPath -Name 'CODEX_CLI_PATH' -Value $exe
    } catch [System.UnauthorizedAccessException] {
        # Some Codex-hosted shells may not write HKCU\Environment. If the
        # registered shim is ours and its C# source is unchanged, update only
        # its adjacent scripts. New processes then use the repaired router.
        $registered = if ($previous) { [IO.Path]::GetFullPath([string]$previous) } else { '' }
        $registeredRoot = if ($registered) { Split-Path -Parent $registered } else { '' }
        $registeredMarker = if ($registeredRoot) { Join-Path $registeredRoot 'shim-source.sha256' } else { '' }
        if (-not $registered.StartsWith($runtimeRoot + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or
            (Split-Path -Leaf $registered) -ne 'codex-cli-proxy.exe' -or
            -not (Test-Path -LiteralPath $registered) -or
            -not (Test-Path -LiteralPath $registeredMarker) -or
            ((Get-Content -LiteralPath $registeredMarker -Raw).Trim() -ne $shimHash)) {
            throw '当前执行环境禁止写入用户级 CODEX_CLI_PATH，且已注册代理不能安全地就地更新。请从资源管理器运行多模型启动入口。'
        }
        $backupRoot = Join-Path $runtimeRoot ('fallback-backup-' + [DateTime]::UtcNow.ToString('yyyyMMddHHmmssfff'))
        New-Item -ItemType Directory -Path $backupRoot -Force | Out-Null
        $scriptNames = $names | Where-Object { $_ -ne 'codex-cli-proxy.cs' }
        foreach ($name in $scriptNames) {
            Copy-Item -LiteralPath (Join-Path $registeredRoot $name) -Destination (Join-Path $backupRoot $name)
        }
        try {
            foreach ($name in $scriptNames) {
                Copy-Item -LiteralPath (Join-Path $versionRoot $name) -Destination (Join-Path $registeredRoot $name) -Force
                if ((Get-SourceHash (Join-Path $registeredRoot $name)) -ne (Get-SourceHash (Join-Path $versionRoot $name))) {
                    throw "已注册代理更新校验失败：$name"
                }
            }
            $registeredVersion = & $registered --version 2>&1
            $registeredVersionLine = $registeredVersion | Where-Object { [string]$_ -match '^codex-cli\s+\S+' } | Select-Object -First 1
            if ($LASTEXITCODE -ne 0 -or -not $registeredVersionLine) { throw '已注册代理更新后自检失败。' }
        } catch {
            foreach ($name in $scriptNames) {
                Copy-Item -LiteralPath (Join-Path $backupRoot $name) -Destination (Join-Path $registeredRoot $name) -Force
            }
            throw
        }
        $exe = $registered
        $saved.installedPath = $registered
    }
    if ($exe -ne $previous) { Broadcast-EnvironmentChange }
}
# Publish the rollback target only after the registry write succeeds. A failed
# update must leave the prior installed path recoverable.
$saved | ConvertTo-Json | Set-Content -LiteralPath $rollbackPath -Encoding utf8
Write-Output ($exe)
