import http from "node:http";
import { Readable, Transform } from "node:stream";
import { pipeline } from "node:stream/promises";
import { appendFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";

const logPath = process.argv
  .find((arg) => arg.startsWith("--log="))
  ?.slice("--log=".length);

const EXEC_COMMAND_MAX_YIELD_MS = 30_000;
export const DEEPSEEK_INPUT_SOFT_LIMIT_BYTES = 1 * 1024 * 1024;
export const DEEPSEEK_SSE_IDLE_TIMEOUT_MS = 180_000;
const EXEC_TOOL_GUARDRAIL =
  "Windows Codex runtime limit: every tools.exec_command call in this JavaScript must omit yield_time_ms or use 10000-30000. Keep work in the foreground and use the returned session_id with tools.write_stdin. Do not use Start-Process, ShellExecute, schtasks, WMI/CIM process creation, or detached/background child processes from Codex Desktop; these paths have caused the desktop host to exit. If work must survive an app exit, write a restart-safe checkpoint and stop instead of inventing a background launcher. Never use 600000 or 900000 for exec_command.";
const ZHIPU_MODELS = new Set(["glm-4.5", "glm-4.5-air", "glm-4.6", "glm-4.7", "glm-5", "glm-5-turbo", "glm-5.1", "glm-5.2", "glm-5.3", "glm-5.3-flash", "glm-5.3-flashx"]);

function zhipuMessages(body) {
  const messages = [];
  if (body.instructions) messages.push({ role: "system", content: body.instructions });
  for (const item of body.input ?? []) {
    if (item?.type === "message") {
      const content = typeof item.content === "string" ? item.content : (item.content ?? []).map((part) => part?.text ?? part?.input_text ?? "").join("\n");
      messages.push({ role: item.role === "assistant" ? "assistant" : "user", content });
    }
    if (item?.type === "function_call_output") messages.push({ role: "tool", tool_call_id: item.call_id, content: typeof item.output === "string" ? item.output : JSON.stringify(item.output ?? "") });
  }
  return messages;
}

function zhipuAsResponse(body, payload) {
  const message = payload?.choices?.[0]?.message ?? {};
  const output = message.content ? [{ type: "message", id: `msg_zhipu_${Date.now()}`, status: "completed", role: "assistant", content: [{ type: "output_text", text: message.content }] }] : [];
  return { id: `resp_zhipu_${Date.now()}`, object: "response", created_at: Math.floor(Date.now() / 1000), status: "completed", model: body.model, output, usage: { input_tokens: payload?.usage?.prompt_tokens ?? 0, output_tokens: payload?.usage?.completion_tokens ?? 0, total_tokens: payload?.usage?.total_tokens ?? 0 } };
}

export function sanitizeExecCommandArguments(argumentsText) {
  if (typeof argumentsText !== "string") return { arguments: argumentsText, clamped: false };
  try {
    const parsed = JSON.parse(argumentsText);
    const value = parsed?.yield_time_ms;
    if (typeof value !== "number" || !Number.isFinite(value)) {
      return { arguments: argumentsText, clamped: false };
    }
    const clampedValue = Math.min(EXEC_COMMAND_MAX_YIELD_MS, Math.max(10_000, Math.trunc(value)));
    if (clampedValue === value) return { arguments: argumentsText, clamped: false };
    parsed.yield_time_ms = clampedValue;
    return { arguments: JSON.stringify(parsed), clamped: true };
  } catch {
    return { arguments: argumentsText, clamped: false };
  }
}

function encodeSse(eventName, payload) {
  return `event: ${eventName}\ndata: ${JSON.stringify(payload)}\n\n`;
}

function jsonBytes(value) {
  return Buffer.byteLength(JSON.stringify(value ?? null), "utf8");
}

export function measureRequest(body) {
  const inputBytes = jsonBytes(body?.input ?? []);
  const instructionsBytes = jsonBytes(body?.instructions ?? "");
  const toolsBytes = jsonBytes(body?.tools ?? []);
  return {
    inputBytes,
    instructionsBytes,
    toolsBytes,
    overSoftLimit: inputBytes > DEEPSEEK_INPUT_SOFT_LIMIT_BYTES,
  };
}

// Once an SSE response has started, destroying the downstream socket makes
// Codex retain its in-flight composer state. A clean EOF lets the client settle
// the interrupted turn and expose its normal retry path.
export function finishAfterStreamFailure(response) {
  if (response.destroyed || response.writableEnded) return "unavailable";
  if (!response.headersSent) {
    response.writeHead(502, { "content-type": "application/json", "cache-control": "no-store" });
    response.end(JSON.stringify({ error: { message: "Local compatibility stream failed", type: "proxy_error" } }));
    return "json-error";
  }
  response.end();
  return "clean-eof";
}

export function createSseEventWatchdog(timeoutMs = DEEPSEEK_SSE_IDLE_TIMEOUT_MS, onTimeout = () => {}) {
  let timer;
  let tail = "";
  const stream = new Transform({
    transform(chunk, _encoding, callback) {
      const text = tail + chunk.toString("utf8");
      if (/(?:^|\r?\n)data:/.test(text)) arm();
      tail = text.slice(-16);
      callback(null, chunk);
    },
    destroy(error, callback) {
      clearTimeout(timer);
      callback(error);
    },
    final(callback) {
      clearTimeout(timer);
      callback();
    },
  });
  const arm = () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      const error = new Error(`DeepSeek model-event idle timeout after ${timeoutMs}ms`);
      error.code = "DEEPSEEK_SSE_IDLE_TIMEOUT";
      onTimeout(error);
      stream.destroy(error);
    }, timeoutMs);
  };
  arm();
  return stream;
}

export function createSseSanitizer(onClamp = () => {}) {
  let buffer = "";
  const itemNames = new Map();
  const pendingArguments = new Map();
  const reportedClamps = new Set();
  const keyOf = (payload) => payload?.item_id ?? payload?.item?.id ?? String(payload?.output_index ?? "unknown");
  const reportClamp = (key) => {
    if (reportedClamps.has(key)) return;
    reportedClamps.add(key);
    onClamp(key);
  };
  const sanitizeItem = (item, fallbackKey) => {
    if (item?.type !== "function_call" || item.name !== "exec_command") return item;
    const result = sanitizeExecCommandArguments(item.arguments);
    if (!result.clamped) return item;
    reportClamp(item.id ?? fallbackKey);
    return { ...item, arguments: result.arguments };
  };
  const processBlock = (block) => {
    const lines = block.split(/\r?\n/);
    const eventName = lines.find((line) => line.startsWith("event:"))?.slice(6).trim();
    const dataLines = lines.filter((line) => line.startsWith("data:"));
    if (!eventName || dataLines.length === 0) return `${block}\n\n`;
    let payload;
    try {
      payload = JSON.parse(dataLines.map((line) => line.slice(5).trimStart()).join("\n"));
    } catch {
      return `${block}\n\n`;
    }
    const type = payload.type ?? eventName;
    const key = keyOf(payload);
    if (type === "response.output_item.added" && payload.item?.type === "function_call") {
      itemNames.set(payload.item.id ?? key, payload.item.name);
      return encodeSse(eventName, payload);
    }
    if (type === "response.function_call_arguments.delta") {
      if (itemNames.get(key) !== "exec_command") return encodeSse(eventName, payload);
      const pending = pendingArguments.get(key) ?? { eventName, firstPayload: payload, text: "" };
      pending.text += payload.delta ?? "";
      pendingArguments.set(key, pending);
      return "";
    }
    if (type === "response.function_call_arguments.done") {
      const pending = pendingArguments.get(key);
      const fullArguments = typeof payload.arguments === "string" ? payload.arguments : pending?.text ?? "";
      const name = itemNames.get(key);
      if (name !== "exec_command" && !pending) return encodeSse(eventName, payload);
      const result = name === "exec_command"
        ? sanitizeExecCommandArguments(fullArguments)
        : { arguments: fullArguments, clamped: false };
      if (result.clamped) reportClamp(key);
      pendingArguments.delete(key);
      const flushedDelta = pending
        ? encodeSse(pending.eventName, { ...pending.firstPayload, delta: result.arguments })
        : "";
      return `${flushedDelta}${encodeSse(eventName, { ...payload, arguments: result.arguments })}`;
    }
    if (type === "response.output_item.done" && payload.item) {
      return encodeSse(eventName, { ...payload, item: sanitizeItem(payload.item, key) });
    }
    if (["response.completed", "response.incomplete", "response.failed"].includes(type) && Array.isArray(payload.response?.output)) {
      const response = {
        ...payload.response,
        output: payload.response.output.map((item) => sanitizeItem(item, item?.id ?? key)),
      };
      return encodeSse(eventName, { ...payload, response });
    }
    return encodeSse(eventName, payload);
  };
  return new Transform({
    transform(chunk, _encoding, callback) {
      buffer += chunk.toString("utf8");
      while (true) {
        const match = /\r?\n\r?\n/.exec(buffer);
        if (!match) break;
        const block = buffer.slice(0, match.index);
        buffer = buffer.slice(match.index + match[0].length);
        this.push(processBlock(block));
      }
      callback();
    },
    flush(callback) {
      if (buffer) this.push(processBlock(buffer).replace(/\n\n$/, ""));
      callback();
    },
  });
}

function errorSummary(error) {
  const name = error?.name || "Error";
  const message = error?.message || String(error);
  const code = error?.cause?.code || error?.code;
  return [name, code, message].filter(Boolean).join(": ").slice(0, 500);
}

async function log(message) {
  if (!logPath) return;
  try {
    await appendFile(logPath, `[${new Date().toISOString()}] ${message}\n`, "utf8");
  } catch {}
}

export function normalize(body) {
  const result = structuredClone(body);
  let orphanOutputs = 0;
  let unpairedCalls = 0;
  let interleavedToolItems = 0;
  let schemaRoots = 0;
  let execGuardrails = 0;
  if (Array.isArray(result.input)) {
    const outputCallIds = new Set(result.input
      .filter((item) => ["function_call_output", "custom_tool_call_output"].includes(item.type))
      .map((item) => item.call_id)
      .filter((callId) => typeof callId === "string" && callId.length > 0));
    result.input = result.input.map((item) => {
      if (["function_call", "custom_tool_call"].includes(item.type)
          && (typeof item.call_id !== "string" || !outputCallIds.has(item.call_id))) {
        unpairedCalls += 1;
        return {
          type: "message",
          role: "user",
          content: [{
            type: "input_text",
            text: `[Historical tool call ${item.name || item.type} was omitted because its paired output is unavailable in this restored context.]`,
          }],
        };
      }
      if (["function_call_output", "custom_tool_call_output"].includes(item.type) && !item.call_id) {
        orphanOutputs += 1;
        const output = typeof item.output === "string" ? item.output : JSON.stringify(item.output);
        return {
          type: "message",
          role: "user",
          content: [{ type: "input_text", text: `[Context supplied by ${item.namespace || "tool"}.${item.name || item.type}; external tool data]\n${output}` }],
        };
      }
      return item;
    });

    // Codex may insert a developer notice (for example an image resize notice)
    // between the outputs of parallel tool calls. DeepSeek treats that message
    // as the end of the tool exchange and then rejects the remaining output as
    // missing from its call. Keep the call block and all of its matched outputs
    // contiguous, while retaining the relative order of calls, outputs, and
    // deferred notices.
    for (let start = 0; start < result.input.length;) {
      if (!["function_call", "custom_tool_call"].includes(result.input[start]?.type)) {
        start += 1;
        continue;
      }

      let callsEnd = start;
      const callIds = new Set();
      while (callsEnd < result.input.length
          && ["function_call", "custom_tool_call"].includes(result.input[callsEnd]?.type)) {
        const callId = result.input[callsEnd].call_id;
        if (typeof callId === "string" && callId.length > 0) callIds.add(callId);
        callsEnd += 1;
      }

      const matchedOutputs = [];
      const deferredItems = [];
      const remaining = new Set(callIds);
      let cursor = callsEnd;
      let sawInterleaving = false;
      while (cursor < result.input.length && remaining.size > 0) {
        const item = result.input[cursor];
        const isOutput = ["function_call_output", "custom_tool_call_output"].includes(item?.type);
        if (isOutput && remaining.has(item.call_id)) {
          matchedOutputs.push(item);
          remaining.delete(item.call_id);
          if (deferredItems.length > 0) sawInterleaving = true;
          cursor += 1;
          continue;
        }
        const isConversationBarrier = item?.type === "message"
          && ["user", "assistant"].includes(item.role);
        const isNewCall = ["function_call", "custom_tool_call"].includes(item?.type);
        if (isConversationBarrier || isNewCall) break;
        deferredItems.push(item);
        cursor += 1;
      }

      if (remaining.size === 0 && sawInterleaving) {
        result.input.splice(
          callsEnd,
          cursor - callsEnd,
          ...matchedOutputs,
          ...deferredItems,
        );
        interleavedToolItems += deferredItems.length;
      }
      start = Math.max(callsEnd, cursor);
    }
  }
  const fixTool = (tool) => {
    if (tool.type === "function" && tool.parameters && !tool.parameters.type) {
      tool.parameters.type = "object";
      schemaRoots += 1;
    }
    if (tool.name === "exec" && typeof tool.description === "string" && !tool.description.includes(EXEC_TOOL_GUARDRAIL)) {
      tool.description = `${tool.description.trim()}\n\n${EXEC_TOOL_GUARDRAIL}`;
      execGuardrails += 1;
    }
    if (tool.name === "exec_command") {
      const yieldSchema = tool.parameters?.properties?.yield_time_ms;
      if (yieldSchema && typeof yieldSchema === "object") {
        if (yieldSchema.minimum !== 10_000 || yieldSchema.maximum !== EXEC_COMMAND_MAX_YIELD_MS) {
          yieldSchema.minimum = 10_000;
          yieldSchema.maximum = EXEC_COMMAND_MAX_YIELD_MS;
          execGuardrails += 1;
        }
      }
    }
    if (Array.isArray(tool.tools)) tool.tools.forEach(fixTool);
  };
  if (Array.isArray(result.tools)) result.tools.forEach(fixTool);
  return { body: result, stats: { orphanOutputs, unpairedCalls, interleavedToolItems, schemaRoots, execGuardrails } };
}

export function serve(port = 18779) {
  const metrics = {
    requests: 0,
    orphanOutputs: 0,
    unpairedCalls: 0,
    interleavedToolItems: 0,
    schemaRoots: 0,
    execGuardrails: 0,
    clampedExecWaits: 0,
    networkErrors: 0,
    streamErrors: 0,
    lastStatus: null,
    lastRequestBytes: null,
    lastInputBytes: null,
    lastInstructionsBytes: null,
    lastToolsBytes: null,
    lastEstimatedInputTokens: null,
    oversizedRequests: 0,
    idleTimeouts: 0,
    lastError: null,
    lastErrorAt: null,
  };
  const recordError = (kind, error) => {
    const summary = errorSummary(error);
    metrics.lastError = summary;
    metrics.lastErrorAt = new Date().toISOString();
    void log(`${kind}: ${summary}`);
  };
  const server = http.createServer(async (request, response) => {
    if (request.method === "GET" && request.url === "/health") {
      response.writeHead(200, { "content-type": "application/json" });
      response.end(JSON.stringify({ service: "deepseek-responses-compat", version: 13, ...metrics }));
      return;
    }
    if (request.method !== "POST" || !["/responses", "/v1/responses"].includes(request.url)) {
      response.writeHead(404); response.end(); return;
    }
    if (!request.headers.authorization?.startsWith("Bearer ")) {
      response.writeHead(401); response.end(); return;
    }
    const abort = new AbortController();
    response.on("close", () => { if (!response.writableEnded) abort.abort(); });
    try {
      let size = 0;
      const chunks = [];
      for await (const chunk of request) {
        size += chunk.length;
        chunks.push(chunk);
      }
      metrics.lastRequestBytes = size;
      const input = JSON.parse(Buffer.concat(chunks).toString("utf8"));
      if (!["deepseek-flash", "deepseek-v4-pro"].includes(input.model)) {
        response.writeHead(400); response.end("unsupported model"); return;
      }
      const adapted = normalize(input);
      const measured = measureRequest(adapted.body);
      metrics.lastInputBytes = measured.inputBytes;
      metrics.lastInstructionsBytes = measured.instructionsBytes;
      metrics.lastToolsBytes = measured.toolsBytes;
      if (measured.overSoftLimit) {
        metrics.oversizedRequests += 1;
        void log(`context_pressure input_bytes=${measured.inputBytes}`);
      }
      metrics.requests += 1;
      metrics.orphanOutputs += adapted.stats.orphanOutputs;
      metrics.unpairedCalls += adapted.stats.unpairedCalls;
      metrics.interleavedToolItems += adapted.stats.interleavedToolItems;
      metrics.schemaRoots += adapted.stats.schemaRoots;
      metrics.execGuardrails += adapted.stats.execGuardrails;
      if (adapted.stats.unpairedCalls > 0) {
        void log(`restored_context_unpaired_calls=${adapted.stats.unpairedCalls}`);
      }
      if (adapted.stats.interleavedToolItems > 0) {
        void log(`restored_context_interleaved_tool_items=${adapted.stats.interleavedToolItems}`);
      }
      const upstream = await fetch("https://api.deepseek.com/responses", {
        method: "POST",
        headers: { authorization: request.headers.authorization, "content-type": "application/json" },
        body: JSON.stringify(adapted.body),
        signal: abort.signal,
      });
      metrics.lastStatus = upstream.status;
      response.writeHead(upstream.status, { "content-type": upstream.headers.get("content-type") || "application/json", "cache-control": "no-store" });
      if (!upstream.body) {
        response.end();
        return;
      }
      try {
        const contentType = upstream.headers.get("content-type") || "";
        if (contentType.includes("text/event-stream")) {
          const watchdog = createSseEventWatchdog(DEEPSEEK_SSE_IDLE_TIMEOUT_MS, () => {
            metrics.idleTimeouts += 1;
            void log(`upstream_sse_model_event_idle_timeout timeout_ms=${DEEPSEEK_SSE_IDLE_TIMEOUT_MS}`);
          });
          const sanitizer = createSseSanitizer((itemId) => {
            metrics.clampedExecWaits += 1;
            void log(`exec_wait_clamped item=${itemId} max=${EXEC_COMMAND_MAX_YIELD_MS}`);
          });
          await pipeline(Readable.fromWeb(upstream.body), sanitizer, watchdog, response);
        } else {
          await pipeline(Readable.fromWeb(upstream.body), response);
        }
      } catch (error) {
        metrics.streamErrors += 1;
        recordError("upstream_stream_error", error);
        finishAfterStreamFailure(response);
      }
    } catch (error) {
      metrics.networkErrors += 1;
      recordError("forwarding_error", error);
      if (response.destroyed || response.writableEnded) return;
      if (!response.headersSent) {
        response.writeHead(502, { "content-type": "application/json", "cache-control": "no-store" });
        response.end(JSON.stringify({ error: { message: "Local compatibility forwarding failed", type: "proxy_error" } }));
      } else {
        finishAfterStreamFailure(response);
      }
    }
  });
  server.on("clientError", (error, socket) => {
    recordError("client_error", error);
    if (socket.writable) socket.end("HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n");
  });
  server.on("error", (error) => recordError("server_error", error));
  server.listen(port, "127.0.0.1");
  void log(`service_started port=${port} pid=${process.pid}`);
  return server;
}

if (process.argv[1] && resolve(fileURLToPath(import.meta.url)) === resolve(process.argv[1])) serve();
