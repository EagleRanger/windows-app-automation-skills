import { readFile, writeFile, mkdir, rename } from "node:fs/promises";
import { join } from "node:path";
import { execFileSync } from "node:child_process";
import { resolveCodexCli } from "./codex-cli.mjs";
import { syncRegisteredCodexCli } from "./registered-codex-cli.mjs";

export function validateOfficialCatalog(value) {
  const models = value?.models;
  if (!Array.isArray(models) || !models.length || models.some(m =>
    !m || typeof m.slug !== "string" || !/^(gpt-|codex-)[a-z0-9._-]+$/i.test(m.slug) ||
    typeof m.display_name !== "string" || !Array.isArray(m.supported_reasoning_levels)) ||
    new Set(models.map(m => m.slug)).size !== models.length) {
    throw new Error("Official OpenAI model catalog is invalid; previous catalog retained.");
  }
  return value;
}
export function replaceOpenAiModels(previous, official) {
  validateOfficialCatalog(official);
  const external = (previous?.models ?? []).filter(m => !/^(gpt-|codex-)/i.test(m.slug));
  return { ...previous, fetched_at: new Date().toISOString(), models: [...official.models, ...external] };
}
async function atomic(path, value) {
  const temp = `${path}.tmp-${process.pid}-${Date.now()}`;
  await writeFile(temp, JSON.stringify(value, null, 2) + "\n", "utf8");
  await rename(temp, path);
}
export async function readOfficialCache(home) {
  try { return validateOfficialCatalog(JSON.parse(await readFile(join(home, "openai-live-catalog.json"), "utf8"))); }
  catch { return null; }
}
export async function fetchOfficialCatalog(home, { fetchImpl = fetch, clientVersion } = {}) {
  if (!clientVersion) {
    // The desktop update can be registered before its new CLI is copied into
    // OpenAI/Codex/bin. Use the registered package for both catalog and proxy.
    const runtime = await syncRegisteredCodexCli();
    let versionOutput;
    try {
      versionOutput = execFileSync(runtime?.path ?? resolveCodexCli({ preferInstalled: true }), ["--version"], { encoding: "utf8", windowsHide: true, timeout: 5000 });
    } catch {
      // A packaged WindowsApps executable can be inaccessible until Core setup.
      // Use the official copied CLI for metadata only; do not alter sandbox policy.
      const copied = resolveCodexCli({ env: { ...process.env, CODEX_CLI_PATH: "", PATH: "" } });
      versionOutput = execFileSync(copied, ["--version"], { encoding: "utf8", windowsHide: true, timeout: 5000 });
    }
    clientVersion = versionOutput.match(/codex-cli\s+([^\s]+)/)?.[1];
    if (!clientVersion) throw new Error("Cannot determine official Codex client version; previous catalog retained.");
  }
  // The existing ChatGPT token is read only in this local process. Never log,
  // persist, proxy, or follow a redirect with these credentials.
  const auth = JSON.parse(await readFile(join(home, "auth.json"), "utf8"));
  if (auth.auth_mode !== "chatgpt" || !auth.tokens?.access_token || !auth.tokens?.account_id)
    throw new Error("ChatGPT sign-in unavailable; previous model catalog retained.");
  const response = await fetchImpl(`https://chatgpt.com/backend-api/codex/models?client_version=${encodeURIComponent(clientVersion)}`, {
    headers: { Authorization: `Bearer ${auth.tokens.access_token}`, "ChatGPT-Account-Id": auth.tokens.account_id, originator: "codex_cli_rs" },
    redirect: "error", signal: AbortSignal.timeout(12000),
  });
  if (!response.ok) throw new Error(`Official model catalog HTTP ${response.status}; previous catalog retained.`);
  const result = validateOfficialCatalog(await response.json());
  await mkdir(home, { recursive: true });
  await atomic(join(home, "openai-live-catalog.json"), { ...result, fetched_at: new Date().toISOString(), source: "chatgpt.com/backend-api/codex/models" });
  return result;
}
export async function syncOpenAiCatalog(home, options = {}) {
  const official = await fetchOfficialCatalog(home, options);
  const path = join(home, "deepseek-picker-models.json");
  const previous = JSON.parse(await readFile(path, "utf8"));
  const next = replaceOpenAiModels(previous, official);
  const changed = JSON.stringify(previous.models) !== JSON.stringify(next.models);
  if (changed) await atomic(path, next);
  return { models: official.models.map(m => m.slug), externalModelsPreserved: next.models.length - official.models.length, changed };
}
