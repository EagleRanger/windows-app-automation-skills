import { fetchDevToolsTargets, selectCodexTaskPage } from "../vendor/codex-model-picker/src/devtools.mjs";
import { createCdpClient } from "../vendor/codex-model-picker/src/cdp-client.mjs";

const args = new Map(process.argv.slice(2).map((arg) => {
  const [key, ...parts] = arg.replace(/^--/, "").split("=");
  return [key, parts.join("=")];
}));
const port = Number(args.get("port"));
const badThreadId = args.get("bad-thread") ?? "";
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Valid renderer port required.");
if (!/^[a-z0-9-]{8,}$/i.test(badThreadId)) throw new Error("Concrete bad task ID required.");

const target = selectCodexTaskPage(await fetchDevToolsTargets(port));
if (!target?.webSocketDebuggerUrl) throw new Error("Codex renderer unavailable.");
const cdp = createCdpClient(target.webSocketDebuggerUrl);
await cdp.opened;
try {
  const expression = `(() => {
    const key = "codex-provider-thread-families-v1";
    const badThreadId = ${JSON.stringify(badThreadId)};
    const parsed = JSON.parse(localStorage.getItem(key) || "null");
    if (!parsed?.threadToFamily || !parsed?.families) return { status: "no_mapping" };
    const familyId = parsed.threadToFamily[badThreadId];
    const family = parsed.families[familyId];
    if (family?.providers) {
      for (const [provider, threadId] of Object.entries(family.providers)) {
        if (threadId === badThreadId) delete family.providers[provider];
      }
    }
    delete parsed.threadToFamily[badThreadId];
    localStorage.setItem(key, JSON.stringify(parsed));
    return { status: "removed", badThreadId, familyId, providers: family?.providers ?? null };
  })()`;
  const result = await cdp.send("Runtime.evaluate", {
    expression,
    awaitPromise: true,
    returnByValue: true,
  });
  if (result?.exceptionDetails) throw new Error(result.exceptionDetails.text ?? "Repair failed.");
  console.log(JSON.stringify(result?.result?.value ?? {}));
} finally {
  await cdp.close();
}
