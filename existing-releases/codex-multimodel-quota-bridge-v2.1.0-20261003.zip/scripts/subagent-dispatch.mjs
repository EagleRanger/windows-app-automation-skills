import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { createInterface } from "node:readline";
import { mkdir, readFile, realpath, stat, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { resolveCodexCli } from "./codex-cli.mjs";

const DEFAULT_TIMEOUT_MS = 20 * 60_000;
const MAX_TASK_CHARS = 32_000;
const DEFAULT_CANDIDATES = Object.freeze([
  { provider: "zai", model: "glm-5.3-flash", effort: "high" },
  { provider: "deepseek", model: "deepseek-flash", effort: "high" },
  { provider: "openai", model: "gpt-6.1-sol", effort: "high" },
  { provider: "openai", model: "gpt-6-luna", effort: "high" },
]);

const auditRoot = () => join(
  process.env.LOCALAPPDATA ?? join(process.env.USERPROFILE ?? process.cwd(), "AppData", "Local"),
  "CodexModelPicker",
  "subagent-receipts",
);

async function writeDispatchAudit(record) {
  const root = auditRoot();
  await mkdir(root, { recursive: true });
  const path = join(root, `${new Date().toISOString().replace(/[:.]/g, "-")}-${randomUUID()}.json`);
  // Do not retain user task text here: routing evidence is sufficient for auditing.
  await writeFile(path, `${JSON.stringify(record, null, 2)}\n`, "utf8");
  return path;
}

const assert = (condition, message) => { if (!condition) throw new Error(message); };

export function normalizeSpec(value) {
  assert(value && typeof value === "object" && !Array.isArray(value), "执行规格必须是 JSON 对象");
  assert(value.version === 1, "执行规格版本必须为 1");
  const task = String(value.task ?? "").trim();
  assert(task, "执行规格缺少 task");
  assert(task.length <= MAX_TASK_CHARS, `task 超过 ${MAX_TASK_CHARS} 字符，请改用文件指针缩小交接`);
  const candidates = value.candidates ?? DEFAULT_CANDIDATES;
  assert(Array.isArray(candidates) && candidates.length > 0 && candidates.length <= 4, "candidates 必须包含 1 至 4 个候选模型");
  const normalizedCandidates = candidates.map((candidate) => {
    const provider = String(candidate?.provider ?? "");
    const model = String(candidate?.model ?? "");
    const effort = String(candidate?.effort ?? "high");
    assert(/^[a-z0-9][a-z0-9_-]*$/i.test(provider), "候选 provider 格式无效");
    assert(/^[a-z0-9][a-z0-9._-]*$/i.test(model), "候选 model 格式无效");
    assert(new Set(["low", "medium", "high", "xhigh", "max", "ultra"]).has(effort), "候选 effort 无效");
    return { provider, model, effort };
  });
  const timeoutMs = Number(value.timeoutMs ?? DEFAULT_TIMEOUT_MS);
  assert(Number.isFinite(timeoutMs) && timeoutMs >= 10_000 && timeoutMs <= 60 * 60_000, "timeoutMs 必须在 10 秒到 60 分钟之间");
  return {
    version: 1,
    task,
    cwd: value.cwd ? String(value.cwd) : process.cwd(),
    candidates: normalizedCandidates,
    timeoutMs,
  };
}

export function createTemporaryAppServer() {
  const child = spawn(resolveCodexCli({ preferInstalled: true }), ["app-server", "--stdio"], { stdio: ["pipe", "pipe", "pipe"], windowsHide: true });
  const pending = new Map();
  const listeners = new Set();
  let nextId = 1;
  let stderr = "";
  child.stderr.on("data", (chunk) => { stderr = `${stderr}${chunk}`.slice(-4_000); });
  createInterface({ input: child.stdout }).on("line", (line) => {
    let message;
    try { message = JSON.parse(line); } catch { return; }
    if (message.id && pending.has(message.id)) {
      const waiter = pending.get(message.id);
      pending.delete(message.id);
      clearTimeout(waiter.timer);
      message.error ? waiter.reject(new Error(message.error.message ?? JSON.stringify(message.error))) : waiter.resolve(message.result);
    }
    for (const listener of listeners) listener(message);
  });
  const request = (method, params) => new Promise((ok, reject) => {
    const id = nextId++;
    const timer = setTimeout(() => { pending.delete(id); const error = new Error(method + ' acknowledgement timed out; outcome unknown'); error.outcomeUnknown = true; reject(error); }, 60_000);
    pending.set(id, { resolve: ok, reject, timer });
    child.stdin.write(`${JSON.stringify({ id, method, params })}\n`);
  });
  const rejectPending = error => {
    for (const waiter of pending.values()) { clearTimeout(waiter.timer); waiter.reject(error); }
    pending.clear();
  };
  child.once('error', rejectPending);
  child.once('exit', () => { const error = new Error('Temporary app-server exited before acknowledgement.'); error.outcomeUnknown = true; rejectPending(error); });
  const notify = (method, params = {}) => child.stdin.write(`${JSON.stringify({ method, params })}\n`);
  const waitFor = (predicate, timeoutMs) => new Promise((ok, reject) => {
    const listener = (message) => {
      if (!predicate(message)) return;
      clearTimeout(timer);
      listeners.delete(listener);
      ok(message);
    };
    const timer = setTimeout(() => {
      listeners.delete(listener);
      reject(new Error(`子智能体等待超时（${timeoutMs}ms）`));
    }, timeoutMs);
    listeners.add(listener);
  });
  let closing = null;
  const close = () => {
    if (closing) return closing;
    closing = new Promise((done) => {
      if (child.exitCode !== null || child.signalCode !== null) { done(); return; }
      let settled = false;
      const finish = () => { if (!settled) { settled = true; done(); } };
      child.once("exit", finish);
      try { child.stdin.end(); } catch {}
      setTimeout(() => {
        if (settled || child.exitCode !== null || child.signalCode !== null) { finish(); return; }
        if (process.platform === "win32" && child.pid) {
          const killer = spawn("taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], { stdio: "ignore", windowsHide: true });
          killer.once("exit", finish);
          killer.once("error", () => { try { child.kill(); } catch {} finish(); });
        } else {
          try { child.kill("SIGTERM"); } catch {}
          setTimeout(() => { try { child.kill("SIGKILL"); } catch {} finish(); }, 1_000);
        }
      }, 1_500);
    });
    return closing;
  };
  return { request, notify, waitFor, close, stderr: () => stderr };
}

function instructions() {
  return [
    "你是由当前 Codex 主任务派出的有界执行子智能体。",
    "只完成用户交给你的独立任务；项目文件和当前工作目录中的 AGENTS.md/Skill 是权威入口。",
    "不要复制或猜测父任务未提供的历史，不要再派生子智能体。完成实现、自检和必要修复后，返回结果、验证、证据位置与未解项。",
    "如果任务在产生写入前就因供应商、模型或认证不可用而失败，如实报错；开始执行后不得把未知副作用自动重放到另一模型。",
  ].join("\n");
}

export async function executeSubagentSpec(rawSpec, { makeClient = createTemporaryAppServer, writeAudit = writeDispatchAudit } = {}) {
  const spec = normalizeSpec(rawSpec);
  const cwd = await realpath(resolve(spec.cwd));
  assert((await stat(cwd)).isDirectory(), "cwd 必须是现有目录");
  const client = makeClient();
  const startFailures = [];
  let selected = null;
  let threadId = null;
  let turnStarted = false;
  try {
    await client.request("initialize", { clientInfo: { name: "multi-provider-subagent-dispatch", version: "1" }, capabilities: { experimentalApi: true } });
    client.notify("initialized");
    for (const candidate of spec.candidates) {
      try {
        const started = await client.request("thread/start", {
          cwd,
          ephemeral: true,
          model: candidate.model,
          modelProvider: candidate.provider,
          developerInstructions: instructions(),
          config: { model_reasoning_effort: candidate.effort },
        });
        threadId = started?.thread?.id;
        assert(threadId, "thread/start 未返回子任务 ID");
        const actualProvider = started.thread?.modelProvider ?? candidate.provider;
        const actualModel = started.thread?.model ?? candidate.model;
        assert(actualProvider === candidate.provider && actualModel === candidate.model,
          `创建核验失败：期望 ${candidate.provider}/${candidate.model}，实际 ${actualProvider}/${actualModel}`);
        selected = candidate;
        break;
      } catch (error) {
        if (error?.outcomeUnknown) throw error;
        startFailures.push({ ...candidate, error: String(error?.message ?? error).slice(0, 300) });
      }
    }
    assert(selected && threadId, `没有可用执行模型：${startFailures.map((x) => `${x.provider}/${x.model}: ${x.error}`).join(" | ")}`);

    const turn = await client.request("turn/start", {
      threadId,
      effort: selected.effort,
      input: [{ type: "text", text: spec.task }],
    });
    turnStarted = true;
    const turnId = turn?.turn?.id;
    assert(turnId, "turn/start 未返回执行轮次 ID");
    const completed = await client.waitFor(
      (message) => message.method === "turn/completed" && message.params?.threadId === threadId && message.params?.turn?.id === turnId,
      spec.timeoutMs,
    );
    const status = completed.params?.turn?.status;
    const messages = (completed.params?.turn?.items ?? []).filter((item) => item.type === "agentMessage" && String(item.text ?? "").trim());
    const reply = [...messages].reverse().find((item) => item.phase === "final_answer")?.text
      ?? [...messages].reverse().find((item) => item.phase == null)?.text
      ?? null;
    assert(status === "completed", `子智能体执行失败：${status ?? "unknown"} ${completed.params?.turn?.error?.message ?? ""}`.trim());
    assert(reply, "子智能体完成但没有可用最终结果");
    const result = {
      status,
      provider: selected.provider,
      model: selected.model,
      effort: selected.effort,
      threadId,
      ephemeral: true,
      startFailures,
      reply,
    };
    const auditPath = await writeAudit({
      schemaVersion: 1,
      recordedAt: new Date().toISOString(),
      status: "completed",
      cwd,
      taskChars: spec.task.length,
      candidates: spec.candidates,
      provider: result.provider,
      model: result.model,
      effort: result.effort,
      threadId: result.threadId,
      ephemeral: true,
      startFailures,
    });
    return { ...result, auditPath };
  } catch (error) {
    const failure = {
      schemaVersion: 1,
      recordedAt: new Date().toISOString(),
      status: turnStarted ? "failed_after_turn_start" : "failed_before_turn_start",
      cwd,
      taskChars: spec.task.length,
      candidates: spec.candidates,
      provider: selected?.provider ?? null,
      model: selected?.model ?? null,
      effort: selected?.effort ?? null,
      threadId,
      ephemeral: true,
      startFailures,
      error: String(error?.message ?? error).slice(0, 1_000),
    };
    try { await writeAudit(failure); } catch {}
    throw error;
  } finally {
    await client.close();
  }
}

async function runCli(args) {
  const command = args[0];
  if (command !== "run" || !args[1]) throw new Error("用法：worker run <spec.json>");
  const spec = JSON.parse(await readFile(resolve(args[1]), "utf8"));
  return executeSubagentSpec(spec);
}

export async function subagentCli(args) { return runCli(args); }
if (process.argv[1] && resolve(fileURLToPath(import.meta.url)) === resolve(process.argv[1])) {
  runCli(process.argv.slice(2)).then((result) => console.log(JSON.stringify(result, null, 2))).catch((error) => {
    console.error(error.message);
    process.exitCode = 1;
  });
}
