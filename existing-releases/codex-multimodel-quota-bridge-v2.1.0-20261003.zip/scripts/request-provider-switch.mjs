import { fetchDevToolsTargets, selectCodexTaskPage } from "../vendor/codex-model-picker/src/devtools.mjs";
import { createCdpClient } from "../vendor/codex-model-picker/src/cdp-client.mjs";
import { randomUUID } from "node:crypto";

const args = new Map(process.argv.slice(2).map((arg) => {
  const [key, ...parts] = arg.replace(/^--/, "").split("=");
  return [key, parts.join("=")];
}));
const port = Number(args.get("port"));
const sourceThreadId = args.get("source-thread") ?? "";
const provider = args.get("provider") ?? "";
const model = args.get("model") ?? "";
const effort = args.get("effort") ?? "high";
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Valid renderer port required.");
if (!/^[a-z0-9-]{8,}$/i.test(sourceThreadId)) throw new Error("Concrete source task ID required.");
if (!/^[a-z0-9_-]+$/i.test(provider) || !/^[a-z0-9._-]+$/i.test(model)) throw new Error("Valid provider and model required.");

const target = selectCodexTaskPage(await fetchDevToolsTargets(port));
if (!target?.webSocketDebuggerUrl) throw new Error("Codex renderer unavailable.");
const cdp = createCdpClient(target.webSocketDebuggerUrl);
await cdp.opened;
try {
  const request = {
    type: "codex-provider-switch-request",
    requestId: randomUUID(),
    sourceThreadId,
    provider,
    model,
    settings: { threadId: sourceThreadId, model, reasoningEffort: effort },
  };
  await cdp.send("Runtime.evaluate", {
    expression: `window.postMessage(${JSON.stringify(request)}, "*")`,
    awaitPromise: true,
  });
  const deadline = Date.now() + 120_000;
  let value = null;
  while (Date.now() < deadline) {
    await new Promise((resolve) => setTimeout(resolve, 1_000));
    const result = await cdp.send("Runtime.evaluate", {
      expression: "globalThis.__CODEX_MODEL_PICKER_OVERRIDE__?.providerSwitch ?? null",
      returnByValue: true,
    });
    value = result.result?.value ?? null;
    if (value?.lastRequestId === request.requestId && ["completed", "completed_cleanup_pending", "failed", "same_provider"].includes(value?.status)) break;
  }
  if (value?.lastRequestId !== request.requestId || !["completed", "same_provider"].includes(value?.status)) process.exitCode = 1;
  console.log(JSON.stringify(value));
} finally {
  await cdp.close();
}
