$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$current = Get-AppxPackage -Name OpenAI.Codex | Sort-Object Version -Descending | Select-Object -First 1
if (-not $current) { throw 'No Codex package is registered for the current user.' }
try {
    $available = Get-AppxPackage -AllUsers -Name OpenAI.Codex |
        Where-Object { $_.PackageFamilyName -eq $current.PackageFamilyName -and $_.Architecture -eq $current.Architecture } |
        Sort-Object { [version]$_.Version } -Descending | Select-Object -First 1
} catch {
    # Ordinary non-admin launches may not list staged packages. Keep the current
    # registered release; never broaden permissions or force a process exit.
    @{ status='unavailable'; version=[string]$current.Version; reason='Staged packages unavailable; keeping registered version.' } | ConvertTo-Json -Compress
    exit 0
}
if (-not $available -or [version]$available.Version -le [version]$current.Version) {
    @{ status='no_update'; version=[string]$current.Version } | ConvertTo-Json -Compress
    exit 0
}
$running = Get-CimInstance Win32_Process -Filter "Name='ChatGPT.exe'" |
    Where-Object { $_.ExecutablePath -like '*\OpenAI.Codex_*\app\ChatGPT.exe' }
if ($running) {
    @{ status='pending'; version=[string]$current.Version; pendingVersion=[string]$available.Version; reason='Waiting for Codex to exit before registering downloaded update.' } | ConvertTo-Json -Compress
    exit 0
}
$manifest = Join-Path $available.InstallLocation 'AppxManifest.xml'
if (-not (Test-Path -LiteralPath $manifest)) { throw 'Staged package manifest is missing; keeping registered version.' }
# Package identity is supplied by Windows. No force-shutdown option is used.
try {
    Add-AppxPackage -Register $manifest -DisableDevelopmentMode -ErrorAction Stop
} catch {
    # A staged release must not make the already registered release unusable.
    # Package services can still hold resources after the desktop has exited.
    $busy = $_.Exception.Message -match '80073D02'
    $stillRegistered = Get-AppxPackage -Name OpenAI.Codex | Sort-Object Version -Descending | Select-Object -First 1
    if (-not $stillRegistered) { throw }
    @{ status=$(if ($busy) { 'pending' } else { 'deferred' }); version=[string]$stillRegistered.Version;
        pendingVersion=[string]$available.Version; reason='Update registration deferred; keeping the registered package without forcing an exit.' } | ConvertTo-Json -Compress
    exit 0
}
$verified = Get-AppxPackage -Name OpenAI.Codex | Sort-Object Version -Descending | Select-Object -First 1
if ([version]$verified.Version -ne [version]$available.Version) { throw 'Package registration readback did not match the update.' }
@{ status='updated'; previousVersion=[string]$current.Version; version=[string]$verified.Version } | ConvertTo-Json -Compress
