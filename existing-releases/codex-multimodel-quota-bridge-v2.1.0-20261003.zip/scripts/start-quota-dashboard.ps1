﻿param(
    [int]$Port = 18781,
    [switch]$NoOpen
)

$ErrorActionPreference = 'Stop'
$url = "http://127.0.0.1:$Port/"
$health = "http://127.0.0.1:$Port/health"
$server = Join-Path $PSScriptRoot 'quota-dashboard.mjs'

function Test-Dashboard {
    try { $result = Invoke-RestMethod -Uri $health -TimeoutSec 2; return $result.ok -eq $true -and $result.service -eq 'codex-quota-dashboard' -and $result.runtimeBundleVersion -eq 1 -and $null -ne $result.catalogRefresh }
    catch { return $false }
}

if (-not (Test-Dashboard)) {
    # Replace only this plugin's old dashboard instance. A foreign listener (or
    # DSH) must never be terminated to reclaim the port.
    $listener = Get-NetTCPConnection -LocalAddress '127.0.0.1' -LocalPort $Port -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener) {
        $owner = Get-CimInstance Win32_Process -Filter "ProcessId = $($listener.OwningProcess)" -ErrorAction SilentlyContinue
        if ($owner -and $owner.Name -ieq 'node.exe' -and $owner.CommandLine -like "*$server*") {
            Stop-Process -Id $owner.ProcessId -ErrorAction Stop
            for ($attempt = 0; $attempt -lt 20; $attempt++) {
                Start-Sleep -Milliseconds 150
                if (-not (Get-NetTCPConnection -LocalAddress '127.0.0.1' -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)) { break }
            }
        } else { throw "端口 $Port 被其他程序占用；未结束任何外部进程。" }
    }
    $nodeCandidates = @(@(
        (Get-Command node.exe -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -ErrorAction SilentlyContinue),
        (Get-ChildItem -LiteralPath "$env:LOCALAPPDATA\OpenAI\Codex\runtimes\cua_node" -Filter node.exe -Recurse -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName),
        (Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
    if (-not $nodeCandidates) { throw '没有找到 Node.js 22+。请先打开一次 Codex Desktop。' }
    Start-Process -FilePath ($nodeCandidates | Select-Object -First 1) -ArgumentList @($server, "--port=$Port") -WindowStyle Hidden
    $ready = $false
    for ($attempt = 0; $attempt -lt 20; $attempt++) { Start-Sleep -Milliseconds 300; if (Test-Dashboard) { $ready = $true; break } }
    if (-not $ready) { throw "额度中心未能在本机端口 $Port 启动。" }
}

if ($NoOpen) { return }

$edge = Get-Command msedge.exe -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -ErrorAction SilentlyContinue
if (-not $edge) { $candidate = Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'; if (Test-Path -LiteralPath $candidate) { $edge = $candidate } }
if ($edge) { Start-Process -FilePath $edge -ArgumentList @("--app=$url", '--new-window') }
else { Start-Process $url }
