import { createReadStream } from 'node:fs';
import { readdir, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { createInterface } from 'node:readline';

const fields = ['input_tokens', 'cached_input_tokens', 'output_tokens', 'reasoning_output_tokens', 'total_tokens'];
const valid = (u) => u && fields.every(k => Number.isFinite(u[k]) && u[k] >= 0)
  && u.cached_input_tokens <= u.input_tokens && u.reasoning_output_tokens <= u.output_tokens
  && u.total_tokens === u.input_tokens + u.output_tokens;

// Only counter growth is counted. A repeated last_token_usage is not a new call.
export async function auditUsage(streams, { since, until }) {
  const groups = new Map(), seen = new Set();
  const diagnostics = { duplicates: 0, missingCounters: 0, invalidRecords: 0, rebasedCounters: 0, inheritedRecords: 0, unattributed: 0 };
  for (const { name, records } of streams) {
    let meta = {}, ctx = {}, previous = null, ownHistory = false;
    for await (const item of records) {
      if (item.type === 'session_meta') { meta = item.payload ?? {}; continue; }
      if (item.type === 'turn_context') { ctx = item.payload ?? item; continue; }
      if (item.payload?.type !== 'token_count' || !item.payload.info) continue;
      const t = Date.parse(item.timestamp), info = item.payload.info;
      const current = info.total_token_usage, last = info.last_token_usage;
      if (!Number.isFinite(t)) { diagnostics.invalidRecords++; continue; }
      // Forked historical items keep their original timestamps. Establish a baseline, but never charge them to the child.
      if (t < Date.parse(meta.timestamp)) {
        if (valid(current)) previous = current;
        diagnostics.inheritedRecords++; continue;
      }
      if (!valid(current)) { diagnostics.missingCounters++; continue; }
      let usage;
      const changed = !previous || fields.some(k => current[k] !== previous[k]);
      if (!changed) { diagnostics.duplicates++; continue; }
      if (previous && fields.every(k => current[k] >= previous[k])) {
        usage = Object.fromEntries(fields.map(k => [k, current[k] - previous[k]]));
      } else if (valid(last)) {
        // First observation or counter reset: only the reported last call is defensible.
        usage = last;
        if (previous || current.total_tokens !== last.total_tokens) diagnostics.rebasedCounters++;
      } else {
        diagnostics.invalidRecords++; previous = current; continue;
      }
      const firstOwn = !ownHistory;
      ownHistory = true;
      previous = current;
      if (!valid(usage)) { diagnostics.invalidRecords++; continue; }
      if (t < since || t > until) continue;
      // Same persisted event copied into multiple logs must not be counted twice.
      const thread = meta.id ?? meta.session_id ?? name;
      const identity = JSON.stringify([thread, item.timestamp, current]);
      if (seen.has(identity)) { diagnostics.duplicates++; continue; }
      seen.add(identity);
      const model = ctx.model ?? 'unknown', effort = ctx.effort ?? 'unknown';
      if (model === 'unknown') diagnostics.unattributed++;
      const project = ctx.cwd ?? meta.cwd ?? 'unknown';
      const key = JSON.stringify([project, thread, model, effort]);
      const row = groups.get(key) ?? { project, thread, parentThread: meta.parent_thread_id ?? null,
        model, effort, events: 0, input: 0, cached: 0, output: 0, reasoning: 0, total: 0,
        turns: new Set(), firstObserved: firstOwn };
      row.events++; row.input += usage.input_tokens; row.cached += usage.cached_input_tokens;
      row.output += usage.output_tokens; row.reasoning += usage.reasoning_output_tokens; row.total += usage.total_tokens;
      if (ctx.turn_id) row.turns.add(ctx.turn_id);
      groups.set(key, row);
    }
  }
  return { since: new Date(since).toISOString(), until: new Date(until).toISOString(),
    accounting: 'local_log_observation_not_account_billing', diagnostics,
    rows: [...groups.values()].map(row => ({ ...row, turns: row.turns.size,
      uncached: row.input - row.cached, cacheHitRate: row.input ? row.cached / row.input : null }))
      .sort((a, b) => b.total - a.total) };
}

async function candidates(root, cutoff, files = []) {
  let entries;
  try { entries = await readdir(root, { withFileTypes: true }); }
  catch (e) { if (e.code === 'ENOENT') return files; throw e; }
  for (const entry of entries) {
    const path = join(root, entry.name);
    if (entry.isDirectory()) await candidates(path, cutoff, files);
    else if (entry.isFile() && entry.name.endsWith('.jsonl') && (await stat(path)).mtimeMs >= cutoff) files.push(path);
  }
  return files;
}

async function* records(path) {
  const lines = createInterface({ input: createReadStream(path, { encoding: 'utf8' }), crlfDelay: Infinity });
  for await (const line of lines) {
    if (!line.trim()) continue;
    try { yield JSON.parse(line); } catch { /* live logs may end in a partial record */ }
  }
}

export async function collectUsage(home, options) {
  const files = [...await candidates(join(home, 'sessions'), options.since),
    ...await candidates(join(home, 'archived_sessions'), options.since)];
  return auditUsage(files.map(name => ({ name, records: records(name) })), options);
}
