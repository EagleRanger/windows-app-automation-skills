﻿$ErrorActionPreference = 'Stop'
$ExpectedCompatVersion = 13
$serviceAlreadyHealthy = $false

function Test-CodexMainProcessRunning {
    $main = @(Get-CimInstance Win32_Process -Filter "Name='ChatGPT.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -notmatch '(?i)(?:^|\s)--type=' })
    return $main.Count -gt 0
}

function Wait-CodexMainExit {
    param([int]$TimeoutSeconds = 20)
    for ($attempt = 0; $attempt -lt ($TimeoutSeconds * 4); $attempt++) {
        if (-not (Test-CodexMainProcessRunning)) { return $true }
        if (($attempt % 4) -eq 0) {
            Write-Output ('  仍在等待旧进程退出… {0}/{1} 秒' -f [Math]::Floor($attempt / 4), $TimeoutSeconds)
        }
        Start-Sleep -Milliseconds 250
    }
    return -not (Test-CodexMainProcessRunning)
}

function Wait-CompatHealth {
    param([int]$TimeoutSeconds = 8)
    for ($attempt = 0; $attempt -lt ($TimeoutSeconds * 5); $attempt++) {
        try {
            $health = Invoke-RestMethod 'http://127.0.0.1:18779/health' -TimeoutSec 1
            if ($health.service -eq 'deepseek-responses-compat' -and $health.version -eq $ExpectedCompatVersion) {
                return $true
            }
        } catch {}
        Start-Sleep -Milliseconds 200
    }
    return $false
}

try {
    Write-Output '[服务] 检查 DeepSeek 本地兼容服务…'
    $status = Invoke-RestMethod 'http://127.0.0.1:18779/health' -TimeoutSec 2
    if ($status.service -eq 'deepseek-responses-compat' -and $status.version -eq $ExpectedCompatVersion) {
        Write-Output ('[服务] 已就绪：v' + $ExpectedCompatVersion + '。')
        $serviceAlreadyHealthy = $true
    } elseif ($status.service -eq 'deepseek-responses-compat') {
        Write-Output ('[服务] 正在热升级兼容服务：v' + $status.version + ' → v' + $ExpectedCompatVersion + '…')
        $listener = Get-NetTCPConnection -LocalAddress '127.0.0.1' -LocalPort 18779 -State Listen -ErrorAction Stop | Select-Object -First 1
        $compatProcessId = $listener.OwningProcess
        $processInfo = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $compatProcessId) -ErrorAction Stop
        $expectedScript = Join-Path $PSScriptRoot 'responses-compat.mjs'
        if (-not $processInfo.CommandLine -or $processInfo.CommandLine -notmatch [Regex]::Escape($expectedScript)) {
            throw '端口 18779 已被无法核验身份的旧服务占用。'
        }
        Stop-Process -Id $compatProcessId -Force -ErrorAction Stop
        for ($attempt = 0; $attempt -lt 80; $attempt++) {
            Start-Sleep -Milliseconds 100
            if (-not (Get-NetTCPConnection -LocalAddress '127.0.0.1' -LocalPort 18779 -State Listen -ErrorAction SilentlyContinue)) { break }
        }
        if (Get-NetTCPConnection -LocalAddress '127.0.0.1' -LocalPort 18779 -State Listen -ErrorAction SilentlyContinue) {
            throw '端口 18779 的旧兼容服务未在 8 秒内退出。为避免抢占端口，本次没有启动 Codex。'
        }
    } else {
        throw '端口 18779 已被未知服务占用。'
    }
} catch {
    if ($_.Exception.Message -match '^端口 18779 |^上一轮 Codex ') { throw }
}

$nodeCandidates = @(@(
    (Get-Command node.exe -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -ErrorAction SilentlyContinue),
    (Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe')
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
if (-not $serviceAlreadyHealthy) {
    if (-not $nodeCandidates) { throw '没有找到 Node.js。' }
    $nodeExecutable = $nodeCandidates | Select-Object -First 1
    $runtimeRoot = Join-Path $env:LOCALAPPDATA 'CodexModelPicker'
    $null = New-Item -ItemType Directory -Force -Path $runtimeRoot
    $compatLog = Join-Path $runtimeRoot 'responses-compat.log'
    $scriptArgument = '"' + (Join-Path $PSScriptRoot 'responses-compat.mjs') + '"'
    $logArgument = '"--log=' + $compatLog + '"'
    $process = Start-Process -FilePath $nodeExecutable -ArgumentList @($scriptArgument, $logArgument) -WindowStyle Hidden -PassThru
    Write-Output ('[服务] 正在等待 v' + $ExpectedCompatVersion + ' 健康检查…')
    if (-not (Wait-CompatHealth)) {
        throw ('DeepSeek compatibility service started but did not pass the version ' + $ExpectedCompatVersion + ' health check within 8 seconds.')
    }
    Write-Output ('[服务] 已启动并通过健康检查（进程 ' + $process.Id + '）。')
}
