import { spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { isAbsolute, join, resolve } from "node:path";
import { resolveCodexCli } from "./codex-cli.mjs";
import { APP_SERVER_PROXY_VERSION, createAppServerRouter } from "./app-server-proxy-core.mjs";

const args = process.argv.slice(2);
const isAppServer = args.includes("app-server");
const codexHome = process.env.CODEX_HOME || join(process.env.USERPROFILE, ".codex");
const routing = isAppServer
  ? JSON.parse(await readFile(join(codexHome, "desktop-model-providers.json"), "utf8"))
  : null;
const realCli = resolveCodexCli({
  preferInstalled: true,
  env: { ...process.env, CODEX_CLI_PATH: "" },
});
const child = spawn(realCli, args, {
  stdio: ["pipe", "pipe", "pipe"],
  windowsHide: true,
  env: { ...process.env, CODEX_CLI_PATH: "" },
});
child.stderr.pipe(process.stderr);

if (!isAppServer) {
  process.stdin.pipe(child.stdin);
  child.stdout.pipe(process.stdout);
  child.once("exit", (code) => { process.exitCode = code ?? 1; });
} else {
  const stateRoot = join(process.env.LOCALAPPDATA || join(process.env.USERPROFILE, "AppData", "Local"), "CodexModelPicker");
  const providerMapPath = join(stateRoot, "app-server-provider-map.json");
  await mkdir(stateRoot, { recursive: true });
  const router = createAppServerRouter({
    providerByModel: routing.model_providers ?? {},
    defaultProvider: routing.default_provider ?? "openai",
  });
  try {
    const saved = JSON.parse(await readFile(providerMapPath, "utf8"));
    const restored = router.route({ id: "restore", method: "codex/provider-families/sync", params: saved });
    if (restored.reply?.error) throw new Error(restored.reply.error.message);
  } catch (error) {
    if (error?.code !== "ENOENT") process.stderr.write(`Provider map was not restored: ${String(error?.message ?? error)}\n`);
  }
  const statePath = join(stateRoot, "app-server-proxy-state.json");
  const state = {
    version: APP_SERVER_PROXY_VERSION,
    status: "active",
    pid: process.pid,
    realCli,
    startedAt: new Date().toISOString(),
    providerIds: [routing.default_provider ?? "openai", ...new Set(Object.values(routing.model_providers ?? {}))],
  };
  const tempPath = `${statePath}.${process.pid}.tmp`;
  await writeFile(tempPath, JSON.stringify(state, null, 2), "utf8");
  await rename(tempPath, statePath);

  const emit = (message) => process.stdout.write(`${JSON.stringify(message)}\n`);
  const reply = (id, result, error) => emit(error
    ? { id, error: { code: -32000, message: String(error?.message ?? error) } }
    : { id, result });
  let providerMapWrite = Promise.resolve();
  async function saveProviderMap(params) {
    const temp = `${providerMapPath}.${process.pid}.${Date.now()}.tmp`;
    await writeFile(temp, JSON.stringify(params), "utf8");
    await rename(temp, providerMapPath);
  }

  async function readProjectLoop(params = {}) {
    const cwd = typeof params.cwd === "string" ? params.cwd.trim() : "";
    if (!cwd || !isAbsolute(cwd)) return { status: "unavailable", reason: "源任务工作目录不是绝对路径。" };
    const title = typeof params.threadTitle === "string" ? params.threadTitle : "";
    const rule = (routing.project_loop_roots ?? []).find((item) =>
      String(item.cwd).toLowerCase() === cwd.toLowerCase() &&
      (!item.titleIncludes || title.toLowerCase().includes(String(item.titleIncludes).toLowerCase())));
    const rootValue = rule?.projectRoot ?? cwd;
    if (!isAbsolute(rootValue)) return { status: "unavailable", reason: "项目 Loop 根目录不是绝对路径。" };
    const root = resolve(rootValue);
    const maxChars = Math.min(Math.max(Number(params.maxChars) || 8_000, 1_024), 8_000);
    for (const file of ["STATE.md", "PROJECT_LOOP.md"]) {
      try {
        const content = await readFile(join(root, ".project-reasoning", file), "utf8");
        return {
          status: "loaded", source: `.project-reasoning/${file}`,
          root: root.toLowerCase() === resolve(cwd).toLowerCase() ? undefined : root,
          truncated: content.length > maxChars, content: content.slice(0, maxChars),
        };
      } catch (error) {
        if (error?.code !== "ENOENT" && error?.code !== "ENOTDIR") {
          return { status: "unavailable", reason: `读取项目 Loop 失败：${String(error?.message ?? error)}` };
        }
      }
    }
    return { status: "missing", reason: "工作目录中没有 .project-reasoning/STATE.md 或 PROJECT_LOOP.md。" };
  }

  createInterface({ input: child.stdout, crlfDelay: Infinity }).on("line", (line) => {
    try { router.observe(JSON.parse(line)); } catch {}
    process.stdout.write(`${line}\n`);
  });
  createInterface({ input: process.stdin, crlfDelay: Infinity }).on("line", (line) => {
    let message;
    try { message = JSON.parse(line); }
    catch { child.stdin.write(`${line}\n`); return; }
    if (message.method === "codex/quota/read") {
      void fetch("http://127.0.0.1:18781/api/quotas", {
        signal: AbortSignal.timeout(22_000),
        headers: { Accept: "application/json" },
      }).then(async (response) => {
        if (!response.ok) throw new Error(`Quota service returned HTTP ${response.status}`);
        return response.json();
      }).then((result) => reply(message.id, result), (error) => reply(message.id, null, error));
      return;
    }
    if (message.method === "codex/project-loop/read") {
      void readProjectLoop(message.params).then(
        (result) => reply(message.id, result),
        (error) => reply(message.id, null, error),
      );
      return;
    }
    if (message.method === "codex/provider-families/sync") {
      const routed = router.route(message);
      if (routed.reply?.error) emit(routed.reply);
      else {
        providerMapWrite = providerMapWrite.catch(() => {}).then(() => saveProviderMap(message.params));
        void providerMapWrite.then(
        () => emit(routed.reply),
        (error) => reply(message.id, null, error),
        );
      }
      return;
    }
    const routed = router.route(message);
    for (const notification of routed.notifications) emit(notification);
    if (routed.reply) emit(routed.reply);
    else child.stdin.write(`${JSON.stringify(routed.forward)}\n`);
  }).on("close", () => child.stdin.end());
  child.once("exit", (code) => { process.exitCode = code ?? 1; });
}
