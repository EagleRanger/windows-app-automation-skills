﻿param(
    [string]$PacketDirectory,
    [ValidateSet('run', 'inspect')][string]$Action = 'run'
)
$ErrorActionPreference = 'Stop'
if (-not $PacketDirectory) { $PacketDirectory = Read-Host '粘贴已准备好的交接目录（无需引号）' }
$resolvedPacket = (Resolve-Path -LiteralPath $PacketDirectory).Path
& (Join-Path $PSScriptRoot 'run-manager.ps1') handoff $Action $resolvedPacket
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
