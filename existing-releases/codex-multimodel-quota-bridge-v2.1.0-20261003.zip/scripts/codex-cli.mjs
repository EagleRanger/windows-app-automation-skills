import { execFileSync } from "node:child_process";
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { delimiter, dirname, join, resolve, sep } from "node:path";

function existingFile(path) {
  if (!path) return null;
  const candidate = resolve(path);
  try {
    return existsSync(candidate) && statSync(candidate).isFile() ? candidate : null;
  } catch {
    return null;
  }
}

function installedCodexCandidates(env) {
  const localAppData = env.LOCALAPPDATA;
  if (!localAppData) return [];
  const binRoot = join(localAppData, "OpenAI", "Codex", "bin");
  const candidates = [join(binRoot, "codex.exe")];
  try {
    const versioned = readdirSync(binRoot, { withFileTypes: true })
      .filter((entry) => entry.isDirectory())
      .map((entry) => join(binRoot, entry.name, "codex.exe"))
      .filter((path) => existingFile(path))
      .sort((left, right) => statSync(right).mtimeMs - statSync(left).mtimeMs);
    candidates.push(...versioned);
  } catch {
    // The desktop installation directory may not exist yet.
  }
  return candidates;
}

function registeredCodexCopy(env) {
  if (!env.LOCALAPPDATA) return null;
  const root = resolve(env.LOCALAPPDATA, "CodexModelPicker", "official-cli");
  try {
    const state = JSON.parse(readFileSync(join(root, "state.json"), "utf8"));
    const candidate = resolve(String(state.path ?? ""));
    if (!candidate.toLowerCase().startsWith(root.toLowerCase() + sep) || state.bundleVersion !== 1) return null;
    const folder = dirname(candidate);
    const manifest = JSON.parse(readFileSync(join(folder, "runtime-manifest.json"), "utf8"));
    const required = ["codex.exe", "codex-code-mode-host.exe", "codex-command-runner.exe", "codex-windows-sandbox-setup.exe"];
    if (manifest.bundleVersion !== 1 || manifest.bundleId !== state.bundleId || !Array.isArray(manifest.files) ||
        required.some(name => !manifest.files.some(file => file.name === name))) return null;
    for (const file of manifest.files) {
      if (!/^codex(?:-[a-z0-9-]+)?\.exe$/i.test(file.name) || !(file.size > 0) ||
          !existingFile(join(folder, file.name)) || statSync(join(folder, file.name)).size !== file.size) return null;
    }
    return existingFile(candidate);
  } catch {
    return null;
  }
}

export function resolveCodexCli({ explicit, env = process.env, platform = process.platform, preferInstalled = false } = {}) {
  const candidates = [explicit, env.CODEX_CLI_PATH];
  if (platform === "win32" && preferInstalled) {
    candidates.push(registeredCodexCopy(env), ...installedCodexCandidates(env));
  }
  const executable = platform === "win32" ? "codex.exe" : "codex";
  for (const pathEntry of String(env.PATH ?? "").split(delimiter).filter(Boolean)) {
    candidates.push(join(pathEntry, executable));
  }

  // Prefer an already verified path. On Windows, where.exe prints a noisy
  // "file not found" error even when the installed Codex CLI is available.
  for (const candidate of candidates) {
    const path = existingFile(candidate);
    if (path) return path;
  }

  if (platform === "win32") {
    try {
      const located = execFileSync("where.exe", ["codex.exe"], {
        encoding: "utf8",
        windowsHide: true,
        stdio: ["ignore", "pipe", "ignore"],
        env,
      });
      candidates.push(...located.split(/\r?\n/).filter(Boolean));
    } catch {
      // A desktop shortcut often starts with a minimal PATH.
    }
    candidates.push(registeredCodexCopy(env), ...installedCodexCandidates(env));
  }

  for (const candidate of candidates) {
    const path = existingFile(candidate);
    if (path) return path;
  }
  throw new Error("找不到 Codex CLI。请确认 Codex Desktop 已安装，或设置 CODEX_CLI_PATH 指向 codex.exe。");
}
