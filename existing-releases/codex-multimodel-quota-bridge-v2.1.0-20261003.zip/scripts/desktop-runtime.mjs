import { createHash } from "node:crypto";
import { copyFile, mkdir, readFile, readdir, lstat, writeFile } from "node:fs/promises";
import { dirname, join, relative } from "node:path";

const cacheIdentityFiles = ["manifest.json", "bin/node.exe", "bin/node_repl.exe"];
const digest = (data) => createHash("sha256").update(data).digest("hex");

async function inventory(root, prefix = "") {
  const files = [];
  for (const entry of await readdir(join(root, prefix), { withFileTypes: true })) {
    if (entry.isSymbolicLink()) throw new Error("运行组件中存在链接，停止自动复制。");
    const name = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) files.push(...await inventory(root, name));
    else if (entry.isFile()) files.push(name);
  }
  return files;
}

async function copyVerifiedFile(source, destination, data) {
  await mkdir(dirname(destination), { recursive: true });
  try { await copyFile(source, destination); }
  catch (error) {
    // WindowsApps can reject CopyFile metadata operations even when ordinary
    // reads work. Copy the same verified bytes; do not change permissions.
    if (!["EPERM", "EACCES", "UNKNOWN"].includes(error.code)) throw error;
    await writeFile(destination, data, { flag: "wx" });
  }
  if (digest(await readFile(destination)) !== digest(data)) {
    throw new Error("官方运行组件复制后的 SHA-256 不一致。");
  }
}

export async function prepareDesktopRuntime(sourceRoot, cacheRoot) {
  const manifest = JSON.parse(await readFile(join(sourceRoot, "manifest.json"), "utf8"));
  if (manifest.platform !== "windows" || manifest.node_path !== "bin/node.exe" ||
      manifest.node_repl_path !== "bin/node_repl.exe") {
    throw new Error("官方桌面运行组件格式已变化，停止自动准备并保留现有运行组件。");
  }
  // This is the content identity used by the registered desktop's resolver.
  const identity = createHash("sha256");
  for (const name of cacheIdentityFiles) {
    identity.update(name).update("\0").update(digest(await readFile(join(sourceRoot, name)))).update("\0");
  }
  const cacheId = identity.digest("hex").slice(0, 16);
  await mkdir(cacheRoot, { recursive: true });
  if ((await lstat(cacheRoot)).isSymbolicLink() || (await lstat(sourceRoot)).isSymbolicLink()) {
    throw new Error("运行组件根目录包含链接，停止自动准备。");
  }
  const destinationRoot = join(cacheRoot, cacheId);
  await mkdir(destinationRoot, { recursive: true });
  const files = await inventory(sourceRoot);
  // Publish manifest last. The desktop must not recognize an incomplete cache.
  files.sort((a, b) => (a === "manifest.json") - (b === "manifest.json") || a.localeCompare(b));
  let copied = 0;
  const aggregate = createHash("sha256");
  for (const name of files) {
    const source = join(sourceRoot, name), destination = join(destinationRoot, name);
    const data = await readFile(source), hash = digest(data);
    aggregate.update(name).update("\0").update(hash).update("\0");
    let existing;
    try {
      // Reject links in every existing ancestor, including the cache root.
      for (let current = destination; relative(cacheRoot, current) !== ""; current = dirname(current)) {
        try { if ((await lstat(current)).isSymbolicLink()) throw new Error("运行组件缓存路径包含链接。"); }
        catch (error) { if (error.code !== "ENOENT") throw error; }
      }
      existing = await readFile(destination);
    } catch (error) { if (error.code !== "ENOENT") throw error; }
    if (existing) {
      if (digest(existing) !== hash) throw new Error(`运行组件缓存与官方内容不一致，未覆盖现有文件：${name}`);
      continue;
    }
    await copyVerifiedFile(source, destination, data);
    copied++;
  }
  return { status: "verified", cacheId, files: files.length, copied,
    sha256: aggregate.digest("hex"), nodeVersion: manifest.node_binary_version,
    nodePath: join(destinationRoot, "bin", "node.exe") };
}
