﻿param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet('refresh', 'refresh-openai', 'refresh-unified', 'install', 'uninstall', 'install-zai', 'uninstall-zai', 'enable', 'disable', 'status', 'usage', 'dashboard', 'handoff', 'context', 'worker')]
    [string]$Command,
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ExtraArgs
)

$ErrorActionPreference = 'Stop'
$dashboard = Join-Path $PSScriptRoot 'start-quota-dashboard.ps1'
if ($Command -eq 'dashboard') {
    & $dashboard
    exit $LASTEXITCODE
}
$manager = Join-Path $PSScriptRoot 'manager.mjs'
$nodeCandidates = @(@(
    (Get-Command node.exe -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -ErrorAction SilentlyContinue),
    (Get-ChildItem -LiteralPath "$env:LOCALAPPDATA\OpenAI\Codex\runtimes\cua_node" -Filter node.exe -Recurse -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName),
    (Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe')
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)

if (-not $nodeCandidates) {
    throw '没有找到 Node.js 22+。请先打开一次 Codex Desktop，让其完成运行时安装。'
}

$nodeExecutable = $nodeCandidates | Select-Object -First 1
& $nodeExecutable $manager $Command @ExtraArgs
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
