import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
import { createReadStream } from "node:fs";
import { copyFile, mkdir, mkdtemp, readFile, readdir, rename, rm, stat, writeFile } from "node:fs/promises";
import { dirname, join, resolve, sep } from "node:path";

const windowsPowerShell = join(process.env.SystemRoot ?? "C:\\Windows", "System32", "WindowsPowerShell", "v1.0", "powershell.exe");

function registeredPackage() {
  const output = execFileSync(windowsPowerShell, [
    "-NoProfile", "-NonInteractive", "-Command",
    "Get-AppxPackage -Name 'OpenAI.Codex' -ErrorAction SilentlyContinue | Select-Object Version,InstallLocation | ConvertTo-Json -Compress",
  ], { encoding: "utf8", windowsHide: true, timeout: 10000 }).trim();
  if (!output) return null;
  const packages = JSON.parse(output);
  const current = (Array.isArray(packages) ? packages : [packages])
    .filter((item) => item?.Version && item?.InstallLocation)
    .sort((a, b) => String(b.Version).localeCompare(String(a.Version), undefined, { numeric: true }))[0];
  if (!current) return null;
  const location = resolve(current.InstallLocation);
  if (!location.toLowerCase().split(/[\\/]/).some((segment) => segment.startsWith("openai.codex_"))) {
    throw new Error("Registered Codex package location is invalid.");
  }
  return { version: String(current.Version), executable: join(location, "app", "resources", "codex.exe") };
}

function cliVersion(executable) {
  const output = execFileSync(executable, ["--version"], {
    encoding: "utf8", windowsHide: true, timeout: 10000,
  });
  const version = output.match(/codex-cli\s+([^\s]+)/)?.[1];
  if (!version) throw new Error("Registered Codex CLI did not report its version.");
  return version;
}

export const REQUIRED_RUNTIME_FILES = ["codex.exe", "codex-code-mode-host.exe", "codex-command-runner.exe", "codex-windows-sandbox-setup.exe"];

async function digest(path) {
  const hash = createHash("sha256");
  for await (const part of createReadStream(path)) hash.update(part);
  return hash.digest("hex");
}

// A successful --version cannot prove that tool execution works. Publish the
// whole verified bundle at a new path, leaving running versions untouched.
export async function publishRegisteredCliBundle({ registered, root, getVersion = cliVersion }) {
  if (!/^[\d.]+$/.test(registered.version)) throw new Error("Invalid package version.");
  root = resolve(root);
  const source = dirname(registered.executable);
  const names = (await readdir(source, { withFileTypes: true }))
    .filter(entry => entry.isFile() && /^codex(?:-[a-z0-9-]+)?\.exe$/i.test(entry.name))
    .map(entry => entry.name).sort();
  for (const name of REQUIRED_RUNTIME_FILES) if (!names.includes(name)) throw new Error("Official runtime is incomplete: " + name);
  const files = await Promise.all(names.map(async name => ({ name, size: (await stat(join(source, name))).size, sha256: await digest(join(source, name)) })));
  if (files.some(file => file.size <= 0)) throw new Error("Official runtime contains an empty component.");
  const bundleId = createHash("sha256").update(JSON.stringify(files)).digest("hex").slice(0, 16);
  const statePath = join(root, "state.json");
  let previous;
  try { previous = JSON.parse(await readFile(statePath, "utf8")); } catch {}
  if (previous?.bundleVersion === 1 && previous.appVersion === registered.version && previous.bundleId === bundleId &&
      resolve(previous.path).startsWith(root + sep)) {
    try {
      const folder = dirname(previous.path);
      const manifest = JSON.parse(await readFile(join(folder, "runtime-manifest.json"), "utf8"));
      if (JSON.stringify(manifest.files) === JSON.stringify(files) &&
          (await Promise.all(files.map(async file => (await stat(join(folder, file.name))).size === file.size && await digest(join(folder, file.name)) === file.sha256))).every(Boolean)) {
        return { ...previous, changed: false };
      }
    } catch { /* Retain the old bundle for recovery; prepare a new copy. */ }
  }
  await mkdir(root, { recursive: true });
  const prefix = registered.version + "-" + bundleId + "-";
  const staging = await mkdtemp(join(root, prefix));
  let published = false;
  try {
    for (const file of files) {
      const target = join(staging, file.name);
      await copyFile(join(source, file.name), target);
      if (await digest(target) !== file.sha256) throw new Error("Runtime copy verification failed: " + file.name);
    }
    const version = await getVersion(join(staging, "codex.exe"));
    const manifest = { bundleVersion: 1, appVersion: registered.version, cliVersion: version, bundleId, files };
    await writeFile(join(staging, "runtime-manifest.json"), JSON.stringify(manifest, null, 2) + "\n");
    // Windows may retain an executable handle briefly after --version exits.
    // The unique folder is already final; the atomic pointer is publication.
    const state = { bundleVersion: 1, appVersion: registered.version, cliVersion: version, bundleId, path: join(staging, "codex.exe") };
    const temp = statePath + "." + process.pid + "." + Date.now() + ".tmp";
    await writeFile(temp, JSON.stringify(state, null, 2) + "\n");
    await rename(temp, statePath);
    published = true;
    return { ...state, changed: true };
  } finally {
    // Only our staging directory can be removed, never an active runtime.
    if (!published && resolve(staging).startsWith(root + sep) && staging.split(sep).at(-1).startsWith(prefix)) await rm(staging, { recursive: true, force: true }).catch(() => {});
  }
}

export async function syncRegisteredCodexCli({ env = process.env } = {}) {
  if (process.platform !== "win32") return null;
  const registered = registeredPackage();
  if (!registered) return null;
  const root = join(env.LOCALAPPDATA ?? join(env.USERPROFILE, "AppData", "Local"), "CodexModelPicker", "official-cli");
  return publishRegisteredCliBundle({ registered, root });
}
