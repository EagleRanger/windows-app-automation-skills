﻿$ErrorActionPreference = 'Stop'
$launchLogDirectory = Join-Path $env:LOCALAPPDATA 'CodexModelPicker'
[System.IO.Directory]::CreateDirectory($launchLogDirectory) | Out-Null
$launchLog = Join-Path $launchLogDirectory 'startup-preflight.log'
function Write-LaunchStatus([string]$Message) {
    Write-Output $Message
    try {
        Add-Content -LiteralPath $launchLog -Value ('[{0:o}] [pid={1}] {2}' -f [DateTime]::UtcNow, $PID, $Message) -Encoding UTF8
    } catch {
        # Logging failure must not prevent the desktop from starting.
    }
}
Write-LaunchStatus 'Starting multi-model preflight.'
$launchMutex = [System.Threading.Mutex]::new($false, 'Local\CodexModelPickerLaunch')
$mutexHeld = $false

try {
    Write-Output ''
    Write-Output '=== Codex 多模型启动器 ==='
    Write-LaunchStatus '[1/4] 正在检查是否有上一轮 Codex 或启动器仍在退出…'
    try {
        $mutexHeld = $launchMutex.WaitOne([TimeSpan]::FromSeconds(30))
    } catch [System.Threading.AbandonedMutexException] {
        $mutexHeld = $true
    }
    if (-not $mutexHeld) { throw '另一个 Codex 多模型启动器仍在运行，请稍候。' }
    Write-LaunchStatus '[1/4] 启动锁已取得。'

    $pluginRoot = Split-Path -Parent $PSScriptRoot
    Write-LaunchStatus '[1/4] 正在校验新版 Codex 的后端模型路由…'
    $proxyExecutable = & (Join-Path $PSScriptRoot 'install-cli-proxy.ps1')
    if (-not $proxyExecutable -or -not (Test-Path -LiteralPath $proxyExecutable)) {
        throw '多模型后端代理未通过安装校验。'
    }
    # Registry broadcasts affect future shells; the current launcher must also
    # carry the override into every directly spawned child.
    $env:CODEX_CLI_PATH = [string]$proxyExecutable
    Write-LaunchStatus '[1/4] 后端模型路由已就绪。'
    & (Join-Path $PSScriptRoot 'start-compat.ps1')
    if ($null -ne $LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw "DeepSeek service setup failed (exit $LASTEXITCODE)." }
    Write-LaunchStatus '[2/4] 本地 DeepSeek 服务已就绪。'

    & (Join-Path $PSScriptRoot 'start-quota-dashboard.ps1') -NoOpen
    if ($null -ne $LASTEXITCODE -and $LASTEXITCODE -ne 0) { throw "Quota service setup failed (exit $LASTEXITCODE)." }
    Write-LaunchStatus '[2/4] 嵌入式额度数据源已就绪。'

    # Refresh from the signed-in official directory; bounded network failure
    # retains the last successful snapshot. Offline rebuild must not roll it back.
    & (Join-Path $PSScriptRoot 'run-manager.ps1') refresh-openai --best-effort
    & (Join-Path $PSScriptRoot 'run-manager.ps1') install --offline
    if ($LASTEXITCODE -ne 0) {
        Write-Output '本地模型目录不可用，正在进行一次在线恢复。'
        & (Join-Path $PSScriptRoot 'run-manager.ps1') install
        if ($LASTEXITCODE -ne 0) { throw "Model catalog setup failed (exit $LASTEXITCODE)." }
    }
    Write-LaunchStatus '[3/4] 本地模型目录已就绪，正在启动 Codex 并校验模型菜单…'

    $nodeCandidates = @(@(
        (Get-Command node.exe -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -ErrorAction SilentlyContinue),
        (Get-ChildItem -LiteralPath "$env:LOCALAPPDATA\OpenAI\Codex\runtimes\cua_node" -Filter node.exe -Recurse -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1 -ExpandProperty FullName),
        (Join-Path $env:USERPROFILE '.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe')
    ) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -Unique)
    if (-not $nodeCandidates) { throw '没有找到 Node.js。' }

    $env:CODEX_MODEL_CATALOG = Join-Path $env:USERPROFILE '.codex\deepseek-picker-models.json'
    $nodeExecutable = $nodeCandidates | Select-Object -First 1
    & $nodeExecutable (Join-Path $pluginRoot 'vendor\codex-model-picker\src\launcher.mjs') --doctor --proxy
    if ($LASTEXITCODE -ne 0) { throw "Codex startup verification failed (exit $LASTEXITCODE). See launcher.log for details." }
    Write-LaunchStatus '[4/4] 启动完成：后端路由与模型菜单已校验。'
} catch {
    Write-Output ''
    Write-LaunchStatus ('启动未完成：' + $_.Exception.Message)
    Write-Output ('前置日志：' + $launchLog)
    Write-Output '窗口将保留，便于查看原因；处理后可直接再次从桌面入口启动。'
    exit 1
} finally {
    if ($mutexHeld) { $launchMutex.ReleaseMutex() }
    $launchMutex.Dispose()
}
