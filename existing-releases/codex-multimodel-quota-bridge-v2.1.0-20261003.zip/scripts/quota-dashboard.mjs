import { execFile } from "node:child_process";
import { createServer } from "node:http";
import { open, readdir, readFile, stat } from "node:fs/promises";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { startCatalogAutoRefresh } from "./catalog-auto-refresh.mjs";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);
const scriptDir = dirname(fileURLToPath(import.meta.url));
const pluginRoot = dirname(scriptDir);
const dashboardPath = join(pluginRoot, "assets", "quota-dashboard.html");
const jsonHeaders = { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" };

function asFiniteNumber(value, field) {
  const number = Number(value);
  if (!Number.isFinite(number)) throw new Error(`${field} is not a finite number`);
  return number;
}

function asOptionalResetTime(value) {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const numeric = Number(value);
  if (Number.isFinite(numeric)) return numeric;
  const parsed = Date.parse(String(value));
  return Number.isFinite(parsed) ? parsed : null;
}

function clamp(value, minimum, maximum) { return Math.min(maximum, Math.max(minimum, value)); }

export function parseDeepSeekBalance(payload) {
  if (!payload || typeof payload !== "object" || !Array.isArray(payload.balance_infos)) throw new Error("DeepSeek balance response has an unexpected shape");
  const preferred = payload.balance_infos.find((item) => item?.currency === "CNY") ?? payload.balance_infos[0];
  if (!preferred) throw new Error("DeepSeek balance response contains no balance");
  return {
    available: Boolean(payload.is_available), currency: String(preferred.currency ?? "CNY"),
    total: asFiniteNumber(preferred.total_balance, "total_balance"),
    granted: asFiniteNumber(preferred.granted_balance, "granted_balance"),
    toppedUp: asFiniteNumber(preferred.topped_up_balance, "topped_up_balance"),
  };
}

function parseZaiWindow(item, expectedUnit, expectedNumber, label) {
  if (!item || item.unit !== expectedUnit || item.number !== expectedNumber) throw new Error(`GLM ${label} quota window is missing`);
  const usedPercent = clamp(asFiniteNumber(item.percentage, `${label}.percentage`), 0, 100);
  return {
    label, limit: asFiniteNumber(item.usage, `${label}.usage`), used: asFiniteNumber(item.currentValue, `${label}.currentValue`),
    remaining: asFiniteNumber(item.remaining, `${label}.remaining`), usedPercent, remainingPercent: 100 - usedPercent,
    resetsAt: asOptionalResetTime(item.nextResetTime),
  };
}

export function parseZaiQuota(payload) {
  if (!payload || payload.code !== 200 || payload.success !== true || !Array.isArray(payload.data?.limits)) throw new Error("GLM quota response has an unexpected shape");
  const fiveHour = payload.data.limits.find((item) => item?.unit === 3 && item?.number === 5);
  const weekly = payload.data.limits.find((item) => item?.unit === 6 && item?.number === 1);
  return { plan: String(payload.data.level ?? "unknown"), fiveHour: parseZaiWindow(fiveHour, 3, 5, "5 小时"), weekly: parseZaiWindow(weekly, 6, 1, "每周") };
}

export function parseOpenAIRateLimitEvent(line) {
  if (!line.includes('"rate_limits"') || !line.includes('"token_count"')) return null;
  let event;
  try { event = JSON.parse(line); } catch { return null; }
  const limits = event?.payload?.rate_limits;
  const primary = limits?.primary;
  if (!primary || Number(primary.window_minutes) !== 10080) return null;
  const usedPercent = clamp(asFiniteNumber(primary.used_percent, "OpenAI used_percent"), 0, 100);
  return { usedPercent, remainingPercent: 100 - usedPercent, resetsAt: asFiniteNumber(primary.resets_at, "OpenAI resets_at") * 1000, observedAt: event.timestamp ?? null, plan: limits.plan_type ?? null, limitId: limits.limit_id ?? null };
}

async function walkJsonl(root) {
  const found = [];
  async function walk(directory) {
    let entries;
    try { entries = await readdir(directory, { withFileTypes: true }); } catch { return; }
    await Promise.all(entries.map(async (entry) => {
      const path = join(directory, entry.name);
      if (entry.isDirectory()) return walk(path);
      if (entry.isFile() && entry.name.endsWith(".jsonl")) { const details = await stat(path); found.push({ path, modifiedAt: details.mtimeMs, size: details.size }); }
    }));
  }
  await walk(root);
  return found;
}

async function readTail(path, size, maximumBytes = 8 * 1024 * 1024) {
  const length = Math.min(size, maximumBytes);
  const buffer = Buffer.alloc(length);
  const handle = await open(path, "r");
  try {
    await handle.read(buffer, 0, length, Math.max(0, size - length));
    return buffer.toString("utf8");
  } finally {
    await handle.close();
  }
}

export async function readOpenAIWeeklyLimit(home = process.env.USERPROFILE) {
  if (!home) throw new Error("USERPROFILE is unavailable");
  const groups = await Promise.all([join(home, ".codex", "sessions"), join(home, ".codex", "archived_sessions")].map(walkJsonl));
  const files = groups.flat().sort((a, b) => b.modifiedAt - a.modifiedAt).slice(0, 64);
  let newest = null;
  for (const file of files) {
    let text;
    try { text = await readTail(file.path, file.size); } catch { continue; }
    const lines = text.split(/\r?\n/);
    for (let index = lines.length - 1; index >= 0; index -= 1) {
      const candidate = parseOpenAIRateLimitEvent(lines[index]);
      if (!candidate) continue;
      const candidateTime = Date.parse(candidate.observedAt ?? "") || file.modifiedAt;
      const newestTime = newest ? (Date.parse(newest.observedAt ?? "") || 0) : -1;
      if (!newest || candidateTime > newestTime) newest = candidate;
      break;
    }
  }
  if (!newest) throw new Error("No OpenAI weekly quota observation was found in local Codex logs");
  return newest;
}

async function readProtectedToken(scriptName) {
  const { stdout } = await execFileAsync("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", join(scriptDir, scriptName), "-Mode", "Get"], { windowsHide: true, timeout: 15_000, maxBuffer: 256 * 1024 });
  const token = stdout.trim();
  if (!token) throw new Error("Credential helper returned an empty token");
  return token;
}

async function fetchJson(url, token) {
  const response = await fetch(url, { headers: { Authorization: `Bearer ${token}`, Accept: "application/json" }, signal: AbortSignal.timeout(20_000) });
  if (!response.ok) throw new Error(`Provider returned HTTP ${response.status}`);
  return response.json();
}

async function collectProvider(source, operation) {
  try { return { ok: true, source, observedAt: new Date().toISOString(), data: await operation() }; }
  catch (error) { return { ok: false, source, error: error instanceof Error ? error.message : String(error) }; }
}

export async function collectQuotaSnapshot() {
  const [openai, glm, deepseek] = await Promise.all([
    collectProvider("Codex 本机额度回执", readOpenAIWeeklyLimit),
    collectProvider("Z.ai 额度接口（非公开文档）", async () => parseZaiQuota(await fetchJson("https://api.z.ai/api/monitor/usage/quota/limit", await readProtectedToken("codex-zhipu-token.ps1")))),
    collectProvider("DeepSeek 官方余额接口", async () => parseDeepSeekBalance(await fetchJson("https://api.deepseek.com/user/balance", await readProtectedToken("codex-deepseek-token.ps1")))),
  ]);
  return { generatedAt: new Date().toISOString(), openai, glm, deepseek };
}

function sendJson(response, status, payload) {
  response.writeHead(status, jsonHeaders);
  response.end(JSON.stringify(payload));
}

export async function startQuotaServer({ port = 18781, host = "127.0.0.1" } = {}) {
  const html = await readFile(dashboardPath);
  const catalogRefresh = startCatalogAutoRefresh();
  const server = createServer(async (request, response) => {
    const url = new URL(request.url ?? "/", `http://${request.headers.host ?? `${host}:${port}`}`);
    if (request.method === "GET" && url.pathname === "/") {
      response.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store", "Content-Security-Policy": "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'", "X-Content-Type-Options": "nosniff" });
      response.end(html); return;
    }
    if (request.method === "GET" && url.pathname === "/api/quotas") { sendJson(response, 200, await collectQuotaSnapshot()); return; }
    if (request.method === "GET" && url.pathname === "/health") { sendJson(response, 200, { ok: true, service: "codex-quota-dashboard", runtimeBundleVersion: 1, catalogRefresh: catalogRefresh.status }); return; }
    sendJson(response, 404, { ok: false, error: "Not found" });
  });
  try { await new Promise((resolve, reject) => { server.once("error", reject); server.listen(port, host, resolve); }); }
  catch (error) { catalogRefresh.stop(); throw error; }
  server.once("close", () => catalogRefresh.stop());
  return server;
}

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (isMain) {
  const portArgument = process.argv.find((argument) => argument.startsWith("--port="));
  const port = portArgument ? Number(portArgument.slice("--port=".length)) : 18781;
  await startQuotaServer({ port });
  console.log(`Codex quota dashboard: http://127.0.0.1:${port}`);
}
