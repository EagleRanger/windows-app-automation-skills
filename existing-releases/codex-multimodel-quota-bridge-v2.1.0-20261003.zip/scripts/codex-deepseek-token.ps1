﻿param(
    [ValidateSet('Get', 'StoreFromEnvironment', 'Status')]
    [string]$Mode = 'Get'
)

$ErrorActionPreference = 'Stop'
$runtimeRoot = Join-Path $env:LOCALAPPDATA 'CodexModelPicker'
$credentialPath = Join-Path $runtimeRoot 'deepseek-token.dpapi'

function Read-ProtectedToken {
    if (-not (Test-Path -LiteralPath $credentialPath)) { throw 'Codex DeepSeek credential is not configured.' }
    Add-Type -AssemblyName System.Security
    $protected = [Convert]::FromBase64String([IO.File]::ReadAllText($credentialPath).Trim())
    $plain = [Security.Cryptography.ProtectedData]::Unprotect(
        $protected,
        $null,
        [Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    return [Text.Encoding]::UTF8.GetString($plain)
}

switch ($Mode) {
    'Get' {
        $token = Read-ProtectedToken
        if (-not $token.Trim()) { throw 'Codex DeepSeek credential is empty.' }
        Write-Output $token.Trim()
    }
    'StoreFromEnvironment' {
        $token = [Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY', 'Process')
        if (-not $token) { throw 'The migration process has no DeepSeek credential.' }
        Add-Type -AssemblyName System.Security
        $null = New-Item -ItemType Directory -Force -Path $runtimeRoot
        $plain = [Text.Encoding]::UTF8.GetBytes($token.Trim())
        $protected = [Security.Cryptography.ProtectedData]::Protect(
            $plain,
            $null,
            [Security.Cryptography.DataProtectionScope]::CurrentUser
        )
        $temporary = $credentialPath + '.tmp-' + $PID
        [IO.File]::WriteAllText($temporary, [Convert]::ToBase64String($protected), [Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $temporary -Destination $credentialPath -Force
        Write-Output 'stored'
    }
    'Status' {
        try {
            $token = Read-ProtectedToken
            [pscustomobject]@{ configured = [bool]$token.Trim(); storage = 'Windows DPAPI CurrentUser'; path = $credentialPath } | ConvertTo-Json -Compress
        } catch {
            [pscustomobject]@{ configured = $false; storage = 'Windows DPAPI CurrentUser'; path = $credentialPath } | ConvertTo-Json -Compress
        }
    }
}
