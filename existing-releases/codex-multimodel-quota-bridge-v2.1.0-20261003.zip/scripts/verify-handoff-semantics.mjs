// Explicit, isolated acceptance: no persistent sidebar tasks, no business tools.
import { createTemporaryAppServer } from './subagent-dispatch.mjs';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const args = new Map(process.argv.slice(2).map(arg => { const [k, ...v] = arg.replace(/^--/, '').split('='); return [k, v.join('=')]; }));
if (!args.has('run') || !args.get('output') || !args.get('cwd')) throw Error('Explicit --run --cwd=isolated-folder --output=receipt.json required.');
const cwd = resolve(args.get('cwd'));
await mkdir(cwd, { recursive: true });
const candidates = [
  { provider: 'zai', model: 'glm-5.3-flash' },
  { provider: 'deepseek', model: 'deepseek-flash' },
  { provider: 'openai', model: 'gpt-6-luna' },
].filter(c => !args.get('provider') || c.provider === args.get('provider'));
const results = [];
const historyTrial = args.has('history-trial');
const task = '只做隔离验收，不调用任何工具，不执行业务。读取最近的交接数据，回答一个JSON，字段goal/frozen/next/owner。不能从历史记录覆盖currentLoop。' + (historyTrial ? ' 另外回答blockedRoute，只采用标记accepted的历史证据；没有证据时必须填UNKNOWN。' : '');
const fixture = { currentLoop: { goal: 'VERIFY_ONLY', frozen: 'NO_FILE_WRITES', next: 'WAIT_FOR_USER', owner: 'LOCAL_PROJECT_LOOP' }, messages: [{ role: 'user', text: '当前只验收交接，勿开始执行。' }] };
for (const candidate of candidates) {
  const expected = { ...fixture.currentLoop, ...(historyTrial ? { blockedRoute: 'UNKNOWN' } : {}) };
  const client = createTemporaryAppServer();
  const receipt = { ...candidate, ephemeral: true, scope: historyTrial ? 'isolated supplied-evidence A/B pilot; NOT automated retrieval or token-saving proof' : 'native history injection and two real model replies; not desktop UI switching', passed: false };
  let activeTurn = null;
  try {
    await client.request('initialize', { clientInfo: { name: 'picker-handoff-acceptance', version: '1' }, capabilities: { experimentalApi: true } });
    client.notify('initialized');
    const started = await client.request('thread/start', { cwd, ephemeral: true, model: candidate.model, modelProvider: candidate.provider, developerInstructions: '这是隔离协议验收。不得调用工具、文件、业务或其他任务。仅输出请求的JSON。', config: { model_reasoning_effort: 'high' } });
    receipt.threadId = started.thread?.id;
    receipt.actualModel = started.model ?? started.thread?.model ?? null;
    receipt.actualProvider = started.modelProvider ?? started.thread?.modelProvider ?? null;
    if (!receipt.threadId || receipt.actualModel !== candidate.model || receipt.actualProvider !== candidate.provider) throw Error('Native provider/model readback was not verified.');
    const params = { threadId: receipt.threadId, items: [{ type: 'message', role: 'developer', content: [{ type: 'input_text', text: '<cross_provider_context>' + JSON.stringify(fixture) + '</cross_provider_context>' }] }] };
    try { await client.request('thread/inject_items', params); }
    catch (error) {
      if (!/unknown variant|method not found/i.test(String(error.message))) throw error;
      await client.request('thread/injectItems', params);
    }
    receipt.rounds = [];
    for (let round = 0; round < 2; round++) {
      if (historyTrial && round === 1) {
        const evidence = { accepted: true, blockedRoute: 'RESUME_ONLY_HANDOFF', source: 'repair-20260923-pair-timeout/修复与验收.md#原因与改动-3', observation: '已加载任务会忽略resume开发指令覆盖，必须验证交接确已进入模型历史。', historicalOwner: 'OLD_OWNER_NOT_CURRENT' };
        const packet = { ...fixture, historicalEvidence: [evidence] };
        const extra = { threadId: receipt.threadId, items: [{ type: 'message', role: 'developer', content: [{ type: 'input_text', text: JSON.stringify(packet) }] }] };
        try { await client.request('thread/inject_items', extra); }
        catch (error) { if (!/unknown variant|method not found/i.test(String(error.message))) throw error; await client.request('thread/injectItems', extra); }
        expected.blockedRoute = 'RESUME_ONLY_HANDOFF';
        receipt.extraEvidenceChars = JSON.stringify(evidence).length;
      }
      let completedTurnId = null;
      const done = client.waitFor(message => message.method === 'turn/completed' && message.params?.threadId === receipt.threadId && (!completedTurnId || message.params?.turn?.id === completedTurnId), 60_000);
      // Attach immediately so a slow turn/start cannot cause an unhandled timeout.
      done.catch(() => {});
      const response = await client.request('turn/start', { threadId: receipt.threadId, effort: 'high', input: [{ type: 'text', text: round ? task + ' 这是第二轮，继续沿用同一交接。' : task }] });
      completedTurnId = response.turn?.id;
      activeTurn = completedTurnId;
      const completed = await done;
      if (completed.params.turn.id !== completedTurnId) throw Error('Completion belongs to another turn.');
      const turn = completed.params.turn;
      activeTurn = null;
      if (turn.status !== 'completed') throw Error(turn.error?.message ?? 'Native turn did not complete.');
      const text = (turn.items ?? []).filter(i => i.type === 'agentMessage').map(i => i.text ?? '').join('\n');
      const match = text.match(/\{[^{}]*\}/);
      const parsed = match ? JSON.parse(match[0]) : null;
      const passed = parsed && Object.entries(expected).every(([key, value]) => parsed[key] === value);
      receipt.rounds.push({ turnId: completedTurnId, passed: Boolean(passed), returnedFields: parsed });
      if (!passed) throw Error('Semantic handoff fields did not match current Loop.');
    }
    receipt.passed = true;
  } catch (error) {
    receipt.error = String(error.message).slice(0, 700);
    if (activeTurn && receipt.threadId) {
      try { await client.request('turn/interrupt', { threadId: receipt.threadId, turnId: activeTurn }); } catch {}
    }
  } finally { await client.close(); }
  results.push(receipt);
  await writeFile(resolve(args.get('output')), JSON.stringify({ recordedAt: new Date().toISOString(), results }, null, 2));
  console.log(JSON.stringify(receipt));
}
if (results.some(r => !r.passed)) process.exitCode = 1;
