import { fetchOfficialCatalog, readOfficialCache, syncOpenAiCatalog } from "./openai-catalog.mjs";
import { collectUsage } from "./usage-audit.mjs";
import { handoffCli } from "./handoff.mjs";
import { subagentCli } from "./subagent-dispatch.mjs";
import { contextSwitchCli } from "./context-switch.mjs";
import { resolveCodexCli } from "./codex-cli.mjs";
import { mergeProviderRouting } from "./routing-config.mjs";
import { execFileSync } from "node:child_process";
import { homedir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { copyFile, mkdir, readFile, readdir, rename, stat, writeFile } from "node:fs/promises";

const pluginRoot = dirname(dirname(fileURLToPath(import.meta.url)));
const args = process.argv.slice(2);
const command = args.find((arg) => !arg.startsWith("--")) ?? "status";
const option = (name) => args.find((arg) => arg.startsWith(`--${name}=`))?.slice(name.length + 3);
const flag = (name) => args.includes(`--${name}`);
const codexHome = resolve(option("codex-home") ?? process.env.CODEX_HOME ?? join(homedir(), ".codex"));
const configPath = join(codexHome, "config.toml");
const catalogPath = join(codexHome, "deepseek-picker-models.json");
const providerRoutingPath = join(codexHome, "desktop-model-providers.json");
const runtimeRoot = join(codexHome, "deepseek-picker");
const statePath = join(runtimeRoot, "state.json");
const templatePath = join(pluginRoot, "assets", "deepseek-models.template.json");
const credentialScriptPath = join(pluginRoot, "scripts", "codex-deepseek-token.ps1");
const zhipuCredentialScriptPath = join(pluginRoot, "scripts", "codex-zhipu-token.ps1");
const managedKeys = ["model", "model_provider", "model_reasoning_effort", "model_catalog_json", "web_search", "preferred_auth_method", "forced_login_method"];
const DEEPSEEK_CONTEXT_WINDOW = 131072;
const DEEPSEEK_AUTO_COMPACT_TOKEN_LIMIT = 98304;
const ZHIPU_CONTEXT_WINDOW = 131072;
const ZHIPU_AUTO_COMPACT_TOKEN_LIMIT = 98304;
const zhipuCodingModels = [
  { slug: "glm-5.3", displayName: "GLM-5.3", description: "Z.ai Coding Plan 旗舰模型；旧版旗舰型号由服务端路由到此模型。", priority: 30 },
  { slug: "glm-5.3-flash", displayName: "GLM-5.3 Flash", description: "Z.ai Coding Plan 快速模型；旧版快速型号由服务端路由到此模型。", priority: 31, modalities: ["text", "image"] },
];

const knownModels = {
  "deepseek-flash": {
    template: "deepseek-flash",
    displayName: "DeepSeek V4.1 Flash",
    description: "快速、低成本，支持图像输入。官方模型 ID：deepseek-flash。",
    modalities: ["text", "image"],
    priority: 1,
  },
  "deepseek-v4-pro": {
    template: "deepseek-v4-pro",
    displayName: "DeepSeek V4 Pro",
    description: "适合复杂 Agent 与代码任务。官方模型 ID：deepseek-v4-pro。",
    modalities: ["text"],
    priority: 2,
  },
};

const compatibilityAliases = [
  { id: "deepseek-v4-flash", target: "deepseek-flash", note: "已退役兼容名，实际由 DeepSeek V4.1 Flash 提供服务。" },
  { id: "deepseek-v4-flash-vision-exp", target: "deepseek-flash", note: "已退役兼容名，视觉能力已合并到 DeepSeek V4.1 Flash。" },
];

async function readJson(path, fallback = null) {
  try { return JSON.parse(await readFile(path, "utf8")); } catch { return fallback; }
}

async function writeAtomic(path, content) {
  await mkdir(dirname(path), { recursive: true });
  const temporary = `${path}.tmp-${process.pid}-${Date.now()}`;
  await writeFile(temporary, content, "utf8");
  await rename(temporary, path);
}

function readDeepSeekKey() {
  if (process.platform !== "win32") return "";
  try {
    return execFileSync("powershell.exe", [
      "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", credentialScriptPath, "-Mode", "Get",
    ], { encoding: "utf8", windowsHide: true }).trim();
  } catch { return ""; }
}

function supportedReasoningLevels() {
  return [
    { effort: "low", description: "低：简单任务，响应更快" },
    { effort: "high", description: "高：日常 Agent 与开发任务" },
    { effort: "max", description: "最大：最复杂的推理和校审" },
  ];
}

function clone(value) { return JSON.parse(JSON.stringify(value)); }

async function fetchModelIds() {
  if (flag("offline")) {
    const cached = (await readJson(statePath, {}))?.modelIds;
    return Array.isArray(cached) && cached.length ? cached : Object.keys(knownModels);
  }
  const key = readDeepSeekKey();
  if (!key) throw new Error("Codex 专用 DeepSeek 凭据尚未配置。请运行 migrate-credentials.ps1。");
  const response = await fetch("https://api.deepseek.com/models", {
    headers: { Authorization: `Bearer ${key}` },
    signal: AbortSignal.timeout(15000),
  });
  if (!response.ok) throw new Error(`DeepSeek /models 返回 ${response.status}。`);
  const payload = await response.json();
  const ids = Array.isArray(payload?.data) ? payload.data.map((item) => String(item?.id ?? "").trim()).filter(Boolean) : [];
  if (!ids.length) throw new Error("DeepSeek /models 没有返回可用模型。");
  return [...new Set(ids)].sort();
}

async function refreshCatalog() {
  const ids = await fetchModelIds();
  const template = await readJson(templatePath);
  if (!Array.isArray(template?.models) || !template.models.length) throw new Error("插件内置的 Codex 模型目录模板无效。");
  const bySlug = new Map(template.models.map((model) => [model.slug, model]));
  const fallbackTemplate = bySlug.get("deepseek-flash") ?? template.models[0];
  const models = ids.map((id, index) => {
    const metadata = knownModels[id];
    const source = bySlug.get(metadata?.template ?? id) ?? fallbackTemplate;
    const model = clone(source);
    model.slug = id;
    model.display_name = metadata?.displayName ?? `DeepSeek ${id}`;
    model.description = metadata?.description ?? `DeepSeek 官方 /models 当前返回的模型。官方模型 ID：${id}。`;
    model.visibility = "list";
    model.priority = metadata?.priority ?? 20 + index;
    model.context_window = DEEPSEEK_CONTEXT_WINDOW;
    model.max_context_window = DEEPSEEK_CONTEXT_WINDOW;
    model.auto_compact_token_limit = DEEPSEEK_AUTO_COMPACT_TOKEN_LIMIT;
    model.input_modalities = metadata?.modalities ?? ["text"];
    model.default_reasoning_level = "high";
    model.supported_reasoning_levels = supportedReasoningLevels();
    model.supported_in_api = true;
    delete model.additional_speed_tiers;
    delete model.service_tiers;
    return model;
  });
  const catalog = { ...template, fetched_at: new Date().toISOString(), etag: `deepseek-picker-${Date.now()}`, models };
  await writeAtomic(catalogPath, `${JSON.stringify(catalog, null, 2)}\n`);
  const currentState = (await readJson(statePath, {})) ?? {};
  await writeAtomic(statePath, `${JSON.stringify({ ...currentState, lastRefreshAt: new Date().toISOString(), modelIds: ids, compatibilityAliases, catalogPath }, null, 2)}\n`);
  console.log(`已刷新 DeepSeek 模型目录：${ids.join(", ")}`);
  console.log(`目录文件：${catalogPath}`);
  return ids;
}

function buildDeepSeekModels(ids, template) {
  const bySlug = new Map(template.models.map((model) => [model.slug, model]));
  const fallbackTemplate = bySlug.get("deepseek-flash") ?? template.models[0];
  return ids.map((id, index) => {
    const metadata = knownModels[id];
    const source = bySlug.get(metadata?.template ?? id) ?? fallbackTemplate;
    const model = clone(source);
    model.slug = id;
    model.display_name = metadata?.displayName ?? `DeepSeek ${id}`;
    model.description = metadata?.description ?? `DeepSeek 官方 /models 当前返回的模型。官方模型 ID：${id}。`;
    model.visibility = "list";
    model.priority = 100 + (metadata?.priority ?? index);
    model.context_window = DEEPSEEK_CONTEXT_WINDOW;
    model.max_context_window = DEEPSEEK_CONTEXT_WINDOW;
    model.auto_compact_token_limit = DEEPSEEK_AUTO_COMPACT_TOKEN_LIMIT;
    model.input_modalities = metadata?.modalities ?? ["text"];
    model.default_reasoning_level = "high";
    model.supported_reasoning_levels = supportedReasoningLevels();
    model.supported_in_api = true;
    delete model.additional_speed_tiers;
    delete model.service_tiers;
    return model;
  });
}

function readBundledCatalog() {
  const explicit = option("bundled-catalog");
  if (explicit) return JSON.parse(execFileSync(process.execPath, ["-e", "process.stdout.write(require('fs').readFileSync(process.argv[1],'utf8'))", resolve(explicit)], { encoding: "utf8" }));
  const codexCli = resolveCodexCli({ explicit: option("codex-cli") });
  const output = execFileSync(codexCli, ["debug", "models", "--bundled"], {
    encoding: "utf8",
    windowsHide: true,
    maxBuffer: 64 * 1024 * 1024,
  });
  return JSON.parse(output);
}

async function refreshUnifiedCatalog() {
  const ids = await fetchModelIds();
  const template = await readJson(templatePath);
  const bundled = option("bundled-catalog") ? readBundledCatalog()
    : flag("offline") ? (await readOfficialCache(codexHome) ?? readBundledCatalog())
    : await fetchOfficialCatalog(codexHome);
  if (!Array.isArray(bundled?.models) || !Array.isArray(template?.models)) throw new Error("无法读取 Codex 内置模型目录。");
  const deepSeekModels = buildDeepSeekModels(ids, template);
  const deepSeekIds = new Set(deepSeekModels.map((model) => model.slug));
  const previousCatalog = await readJson(catalogPath, {});
  const otherProviderModels = (previousCatalog.models ?? []).filter(m => !/^(gpt-|codex-|deepseek-)/i.test(m.slug));
  const catalog = {
    ...bundled,
    fetched_at: new Date().toISOString(),
    etag: `deepseek-unified-picker-${Date.now()}`,
    models: [...bundled.models.filter((model) => !deepSeekIds.has(model.slug)), ...deepSeekModels, ...otherProviderModels],
  };
  await writeAtomic(catalogPath, `${JSON.stringify(catalog, null, 2)}\n`);
  const previousRouting = await readJson(providerRoutingPath, {});
  await writeAtomic(providerRoutingPath, `${JSON.stringify(mergeProviderRouting(previousRouting, {
    version: 1,
    default_provider: "openai",
    providers: [
      { id: "openai", label: "OpenAI / ChatGPT", description: "使用当前 ChatGPT Codex 账户" },
      { id: "deepseek", label: "DeepSeek API", description: "使用 Codex 专用受保护凭据，不读取 DSH 的启动环境" },
    ],
    model_providers: Object.fromEntries(ids.map((id) => [id, "deepseek"])),
  }), null, 2)}\n`);
  const currentState = (await readJson(statePath, {})) ?? {};
  await writeAtomic(statePath, `${JSON.stringify({ ...currentState, lastRefreshAt: new Date().toISOString(), modelIds: ids, compatibilityAliases, catalogPath, providerRoutingPath, unifiedCatalog: true }, null, 2)}\n`);
  console.log(`已生成统一模型列表：${bundled.models.length} 个 OpenAI 模型 + ${ids.length} 个 DeepSeek 模型。`);
  return ids;
}

function splitRoot(text) {
  const lines = text.replace(/\r\n/g, "\n").split("\n");
  const tableIndex = lines.findIndex((line) => /^\s*\[/.test(line));
  const index = tableIndex < 0 ? lines.length : tableIndex;
  return { root: lines.slice(0, index), rest: lines.slice(index) };
}

function rootKey(line) { return line.match(/^\s*([A-Za-z0-9_-]+)\s*=/)?.[1] ?? null; }
function quoteToml(value) { return `"${String(value).replaceAll("\\", "/").replaceAll('"', '\\"')}"`; }

function removeTable(lines, tableName) {
  const start = lines.findIndex((line) => line.trim() === `[${tableName}]`);
  if (start < 0) return { lines, removed: null };
  let end = start + 1;
  while (end < lines.length && !/^\s*\[/.test(lines[end])) end += 1;
  return { lines: [...lines.slice(0, start), ...lines.slice(end)], removed: lines.slice(start, end) };
}

function findTable(lines, tableName) {
  const start = lines.findIndex((line) => line.trim() === `[${tableName}]`);
  if (start < 0) return null;
  let end = start + 1;
  while (end < lines.length && !/^\s*\[/.test(lines[end])) end += 1;
  return lines.slice(start, end).join("\n");
}

function tableNameOf(line) {
  return line.match(/^\s*\[([^\]]+)\]\s*$/)?.[1] ?? null;
}

function extractTableTree(lines, tableName) {
  const selected = [];
  let include = false;
  for (const line of lines) {
    const current = tableNameOf(line);
    if (current) include = current === tableName || current.startsWith(`${tableName}.`);
    if (include) selected.push(line);
  }
  return selected;
}

function removeTableTree(lines, tableName) {
  const kept = [];
  let skip = false;
  for (const line of lines) {
    const current = tableNameOf(line);
    if (current) skip = current === tableName || current.startsWith(`${tableName}.`);
    if (!skip) kept.push(line);
  }
  return { lines: kept, removed: extractTableTree(lines, tableName) };
}

function quoteTomlArray(values) {
  return `[${values.map(quoteToml).join(", ")}]`;
}

function tableSetting(table, key) {
  return table?.match(new RegExp(`^\\s*${key}\\s*=\\s*"([^"]*)"`, "m"))?.[1] ?? null;
}

function setTableSetting(lines, tableName, key, value) {
  const start = lines.findIndex((line) => line.trim() === `[${tableName}]`);
  if (start < 0) return lines;
  let end = start + 1;
  while (end < lines.length && !/^\s*\[/.test(lines[end])) end += 1;
  const relative = lines.slice(start + 1, end).findIndex((line) => new RegExp(`^\\s*${key}\\s*=`).test(line));
  const next = [...lines];
  const setting = `${key} = ${quoteToml(value)}`;
  if (relative < 0) next.splice(end, 0, setting); else next[start + 1 + relative] = setting;
  return next;
}

async function enable() {
  if (!(await readJson(catalogPath))) await refreshCatalog();
  const original = await readFile(configPath, "utf8");
  const state = (await readJson(statePath, {})) ?? {};
  const { root, rest } = splitRoot(original);
  const previousRootLines = state.active ? state.previousRootLines : Object.fromEntries(managedKeys.map((key) => [key, root.find((line) => rootKey(line) === key) ?? null]));
  const filteredRoot = root.filter((line) => !managedKeys.includes(rootKey(line)));
  while (filteredRoot.length && !filteredRoot.at(-1).trim()) filteredRoot.pop();
  filteredRoot.push("", "# DeepSeek Codex Picker managed settings", 'model = "deepseek-flash"', 'model_provider = "deepseek"', 'model_reasoning_effort = "high"', `model_catalog_json = ${quoteToml(catalogPath)}`, 'web_search = "disabled"', 'preferred_auth_method = "apikey"', 'forced_login_method = "api"', "");

  const providerName = "model_providers.deepseek";
  const existingProvider = findTable(rest, providerName);
  let nextRest = rest;
  let providerAdded = state.active ? state.providerAdded : false;
  if (existingProvider) {
    const normalized = existingProvider.toLowerCase();
    if (!normalized.includes("api.deepseek.com") || !normalized.includes('wire_api = "responses"')) throw new Error("现有 [model_providers.deepseek] 与官方 Responses 配置不一致，已停止写入。");
  } else {
    providerAdded = true;
    nextRest = [...rest, "", `[${providerName}]`, 'name = "DeepSeek"', 'base_url = "https://api.deepseek.com/"', 'wire_api = "responses"', 'env_key = "DEEPSEEK_API_KEY"', 'env_key_instructions = "Set DEEPSEEK_API_KEY in the Windows user environment, then restart Codex."', ""];
  }

  await mkdir(runtimeRoot, { recursive: true });
  if (!state.active) {
    const backupPath = join(runtimeRoot, `config.pre-enable-${new Date().toISOString().replaceAll(":", "-")}.toml`);
    await copyFile(configPath, backupPath);
    state.backupPath = backupPath;
  }
  const nextText = `${[...filteredRoot, ...nextRest].join("\n").replace(/\n{4,}/g, "\n\n\n").trimEnd()}\n`;
  await writeAtomic(configPath, nextText);
  await writeAtomic(statePath, `${JSON.stringify({ ...state, active: true, enabledAt: new Date().toISOString(), previousRootLines, providerAdded, catalogPath }, null, 2)}\n`);
  console.log("DeepSeek 模式已写入。完全退出 Codex 后，用本插件启动器重新打开。默认：DeepSeek V4.1 Flash / high。");
}

async function disable() {
  const state = (await readJson(statePath, {})) ?? {};
  if (!state.active) { console.log("DeepSeek 模式当前未启用。"); return; }
  const current = await readFile(configPath, "utf8");
  const { root, rest } = splitRoot(current);
  const filteredRoot = root.filter((line) => !managedKeys.includes(rootKey(line)));
  while (filteredRoot.length && !filteredRoot.at(-1).trim()) filteredRoot.pop();
  filteredRoot.push("");
  for (const key of managedKeys) {
    const previous = state.previousRootLines?.[key];
    if (typeof previous === "string" && previous.trim()) filteredRoot.push(previous);
  }
  filteredRoot.push("");
  let nextRest = rest;
  if (state.providerAdded) nextRest = removeTable(rest, "model_providers.deepseek").lines;
  await writeAtomic(configPath, `${[...filteredRoot, ...nextRest].join("\n").replace(/\n{4,}/g, "\n\n\n").trimEnd()}\n`);
  await writeAtomic(statePath, `${JSON.stringify({ ...state, active: false, disabledAt: new Date().toISOString() }, null, 2)}\n`);
  console.log("已恢复启用前的 OpenAI 顶层模型设置。完全退出并重新打开 Codex 后生效。");
}

async function installUnified() {
  const stateBefore = (await readJson(statePath, {})) ?? {};
  if (stateBefore.active) await disable();
  await refreshUnifiedCatalog();
  // Base catalog refresh rebuilds OpenAI + DeepSeek from authoritative inputs.
  // Reapply an already-enabled Z.ai layer so every normal desktop launch keeps
  // the third provider instead of silently dropping it.
  if (stateBefore.zaiCodingPlan) await installZhipuCodingPlan();

  const original = await readFile(configPath, "utf8");
  const state = (await readJson(statePath, {})) ?? {};
  const { root, rest } = splitRoot(original);
  const existingProvider = findTable(rest, "model_providers.deepseek");
  const actualUnifiedActive = root.some((line) =>
    rootKey(line) === "model_catalog_json" && line.replaceAll("\\", "/").includes(catalogPath.replaceAll("\\", "/")),
  ) && tableSetting(existingProvider, "base_url") === "http://127.0.0.1:18779";
  const previousCatalogLine = actualUnifiedActive
    ? state.unifiedPreviousCatalogLine
    : root.find((line) => rootKey(line) === "model_catalog_json") ?? null;
  const filteredRoot = root.filter((line) =>
    rootKey(line) !== "model_catalog_json" &&
    !["# DeepSeek unified model picker", "# DeepSeek Codex Picker managed settings"].includes(line.trim()),
  );
  while (filteredRoot.length && !filteredRoot.at(-1).trim()) filteredRoot.pop();
  filteredRoot.push("", "# DeepSeek unified model picker", `model_catalog_json = ${quoteToml(catalogPath)}`, "");

  const providerName = "model_providers.deepseek";
  const previousProviderTables = actualUnifiedActive
    ? state.unifiedPreviousProviderTables ?? []
    : extractTableTree(rest, providerName);
  const withoutProvider = removeTableTree(rest, providerName).lines;
  const nextRest = [...withoutProvider, "", `[${providerName}]`, 'name = "DeepSeek API"', 'base_url = "http://127.0.0.1:18779"', 'wire_api = "responses"', 'supports_websockets = false', "", `[${providerName}.auth]`, 'command = "powershell.exe"', `args = ${quoteTomlArray(["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", credentialScriptPath, "-Mode", "Get"])}`, ""];

  await mkdir(runtimeRoot, { recursive: true });
  if (!actualUnifiedActive) {
    const backupPath = join(runtimeRoot, `config.pre-unified-${new Date().toISOString().replaceAll(":", "-")}.toml`);
    await copyFile(configPath, backupPath);
    state.unifiedBackupPath = backupPath;
  }
  await writeAtomic(configPath, `${[...filteredRoot, ...nextRest].join("\n").replace(/\n{4,}/g, "\n\n\n").trimEnd()}\n`);
  await writeAtomic(statePath, `${JSON.stringify({ ...state, active: false, unifiedActive: true, unifiedEnabledAt: new Date().toISOString(), unifiedPreviousCatalogLine: previousCatalogLine, unifiedPreviousProviderTables: previousProviderTables, unifiedProviderAdded: previousProviderTables.length === 0, catalogPath, providerRoutingPath }, null, 2)}\n`);
  console.log("统一模型选择已配置：在 Codex 右下角选择 DeepSeek 时自动使用 DeepSeek，选择 GPT 时自动使用 OpenAI。新任务生效。");
}

async function uninstallUnified() {
  const state = (await readJson(statePath, {})) ?? {};
  if (!state.unifiedActive) { console.log("统一模型选择当前未启用。"); return; }
  const current = await readFile(configPath, "utf8");
  const { root, rest } = splitRoot(current);
  const filteredRoot = root.filter((line) => rootKey(line) !== "model_catalog_json");
  while (filteredRoot.length && !filteredRoot.at(-1).trim()) filteredRoot.pop();
  if (typeof state.unifiedPreviousCatalogLine === "string" && state.unifiedPreviousCatalogLine.trim()) filteredRoot.push("", state.unifiedPreviousCatalogLine);
  filteredRoot.push("");
  let nextRest = removeTableTree(rest, "model_providers.deepseek").lines;
  if (Array.isArray(state.unifiedPreviousProviderTables) && state.unifiedPreviousProviderTables.length) {
    nextRest = [...nextRest, "", ...state.unifiedPreviousProviderTables, ""];
  }
  await writeAtomic(configPath, `${[...filteredRoot, ...nextRest].join("\n").replace(/\n{4,}/g, "\n\n\n").trimEnd()}\n`);
  await writeAtomic(statePath, `${JSON.stringify({ ...state, unifiedActive: false, unifiedDisabledAt: new Date().toISOString() }, null, 2)}\n`);
  console.log("已移除统一模型选择配置，OpenAI 登录和其他设置保持不变。");
}

async function installZhipuCodingPlan() {
  const catalog = await readJson(catalogPath);
  if (!Array.isArray(catalog?.models) || !catalog.models.length) throw new Error("统一模型目录不存在；请先完成 DeepSeek 统一目录安装。");
  const source = catalog.models.find((model) => model.slug === "deepseek-flash") ?? catalog.models[0];
  const zhipuModels = zhipuCodingModels.map((metadata) => {
    const model = clone(source);
    model.slug = metadata.slug;
    model.display_name = metadata.displayName;
    model.description = metadata.description;
    model.priority = metadata.priority;
    model.context_window = ZHIPU_CONTEXT_WINDOW;
    model.max_context_window = ZHIPU_CONTEXT_WINDOW;
    model.auto_compact_token_limit = ZHIPU_AUTO_COMPACT_TOKEN_LIMIT;
    model.input_modalities = metadata?.modalities ?? ["text"];
    model.default_reasoning_level = "high";
    model.supported_reasoning_levels = supportedReasoningLevels();
    model.supported_in_api = true;
    return model;
  });
  const nextCatalog = {
    ...catalog,
    fetched_at: new Date().toISOString(),
    etag: `multi-provider-picker-${Date.now()}`,
    models: [...catalog.models.filter((model) => !model.slug?.startsWith("glm-")), ...zhipuModels],
  };
  await writeAtomic(catalogPath, `${JSON.stringify(nextCatalog, null, 2)}\n`);
  const routing = (await readJson(providerRoutingPath, { version: 1, default_provider: "openai", providers: [], model_providers: {} })) ?? {};
  const providers = Array.isArray(routing.providers) ? routing.providers.filter((provider) => !["zhipu", "zai"].includes(provider?.id)) : [];
  providers.push({ id: "zai", label: "Z.ai GLM Coding Plan", description: "使用 Z.ai 编程套餐专用 API Key" });
  const modelProviders = { ...(routing.model_providers ?? {}) };
  for (const id of Object.keys(modelProviders)) {
    if (id.startsWith("glm-")) delete modelProviders[id];
  }
  for (const model of zhipuCodingModels) modelProviders[model.slug] = "zai";
  await writeAtomic(providerRoutingPath, `${JSON.stringify({ ...routing, version: 1, default_provider: "openai", providers, model_providers: modelProviders }, null, 2)}\n`);
  const config = await readFile(configPath, "utf8");
  const { root, rest } = splitRoot(config);
  let withoutZai = removeTableTree(rest, "model_providers.zhipu").lines;
  withoutZai = removeTableTree(withoutZai, "model_providers.zai").lines;
  withoutZai = removeTableTree(withoutZai, "profiles.zai").lines;
  const zaiTable = [
    "", "[model_providers.zai]", 'name = "Z.ai GLM Coding Plan"',
    'base_url = "https://api.z.ai/api/v1"', 'wire_api = "responses"', 'supports_websockets = false',
    "", "[model_providers.zai.auth]", 'command = "powershell.exe"',
    `args = ${quoteTomlArray(["-NoProfile", "-ExecutionPolicy", "Bypass", "-File", zhipuCredentialScriptPath, "-Mode", "Get"])}`, "",
  ];
  const state = (await readJson(statePath, {})) ?? {};
  let zaiBackupPath = state.zaiBackupPath;
  if (!zaiBackupPath) {
    zaiBackupPath = join(codexHome, `config.toml.before-zai-${Date.now()}.bak`);
    await copyFile(configPath, zaiBackupPath);
  }
  await writeAtomic(configPath, `${[...root, ...withoutZai, ...zaiTable].join("\n").replace(/\n{4,}/g, "\n\n\n").trimEnd()}\n`);
  await writeAtomic(statePath, `${JSON.stringify({ ...state, zaiBackupPath, zaiCodingPlan: { enabledAt: new Date().toISOString(), models: zhipuCodingModels.map((model) => model.slug), endpoint: "https://api.z.ai/api/v1" }, catalogPath, providerRoutingPath }, null, 2)}\n`);
  console.log(`Z.ai GLM Coding Plan 已加入统一模型目录：${zhipuCodingModels.map((model) => model.displayName).join("、")}。`);
}

async function uninstallZhipuCodingPlan() {
  const catalog = await readJson(catalogPath);
  if (Array.isArray(catalog?.models)) {
    catalog.models = catalog.models.filter((model) => !model.slug?.startsWith("glm-"));
    await writeAtomic(catalogPath, `${JSON.stringify({ ...catalog, fetched_at: new Date().toISOString() }, null, 2)}\n`);
  }
  const routing = (await readJson(providerRoutingPath, {})) ?? {};
  const modelProviders = { ...(routing.model_providers ?? {}) };
  for (const id of Object.keys(modelProviders)) {
    if (id.startsWith("glm-")) delete modelProviders[id];
  }
  await writeAtomic(providerRoutingPath, `${JSON.stringify({ ...routing, providers: (routing.providers ?? []).filter((provider) => !["zhipu", "zai"].includes(provider?.id)), model_providers: modelProviders }, null, 2)}\n`);
  const config = await readFile(configPath, "utf8");
  const { root, rest } = splitRoot(config);
  let cleaned = removeTableTree(rest, "model_providers.zhipu").lines;
  cleaned = removeTableTree(cleaned, "model_providers.zai").lines;
  cleaned = removeTableTree(cleaned, "profiles.zai").lines;
  await writeAtomic(configPath, `${[...root, ...cleaned].join("\n").replace(/\n{4,}/g, "\n\n\n").trimEnd()}\n`);
  const state = (await readJson(statePath, {})) ?? {};
  delete state.zhipuCodingPlan;
  delete state.zaiCodingPlan;
  await writeAtomic(statePath, `${JSON.stringify({ ...state, zaiCodingPlanDisabledAt: new Date().toISOString() }, null, 2)}\n`);
  console.log("Z.ai 路由已撤回；凭据和接入脚本保留。");
}

async function status() {
  const state = (await readJson(statePath, {})) ?? {};
  const catalog = await readJson(catalogPath);
  const zaiEnabled = Boolean(state.zaiCodingPlan);
  console.log(`模式：${state.unifiedActive ? `OpenAI + DeepSeek${zaiEnabled ? " + Z.ai" : ""} 统一选择` : state.active ? "旧 DeepSeek 独占模式" : "OpenAI / 未接管"}`);
  const deepSeekModels = catalog?.models?.filter((model) => model.slug?.startsWith("deepseek")) ?? [];
  const zaiModels = catalog?.models?.filter((model) => model.slug?.startsWith("glm-")) ?? [];
  console.log(`DeepSeek 模型：${deepSeekModels.map((model) => `${model.display_name} (${model.slug})`).join("；") || "尚未刷新"}`);
  console.log(`Z.ai 模型：${zaiModels.map((model) => `${model.display_name} (${model.slug})`).join("；") || "尚未接入"}`);
  console.log("推理档位：low / high / max；默认 high。");
  console.log("省流路线：主模型规划/必要审核，子模型有界执行；手动选型优先，阶段内稳定。跨供应商首次建立配对任务，之后取消归档并复用，只发送有界增量交接。用量按需查看。");
  console.log("兼容别名：deepseek-v4-flash、deepseek-v4-flash-vision-exp（均转到 deepseek-flash，不单列为新模型）。");
}

async function usageReport() {
  const until = Date.now();
  const days = Number(option("days") ?? 7);
  if (!Number.isFinite(days) || days <= 0 || days > 366) throw new Error("days 必须在 0 到 366 之间。");
  const report = await collectUsage(codexHome, { since: until - days * 86400000, until });
  if (flag("json")) { console.log(JSON.stringify(report, null, 2)); return; }
  console.log(`本机日志时间窗：${report.since} 至 ${report.until}（UTC）`);
  console.log("按项目路径、任务、模型和档位分组；缓存是输入子集，推理是输出子集。用量事件数不等于 API 请求数。");
  for (const row of report.rows) {
    console.log(`${row.project} | ${row.thread}${row.parentThread ? `（父任务 ${row.parentThread}）` : ""}`);
    console.log(`  ${row.model} / ${row.effort}：${row.events} 个用量事件，${row.total.toLocaleString()} tokens（未缓存输入 ${row.uncached.toLocaleString()}，缓存 ${row.cached.toLocaleString()}，输出 ${row.output.toLocaleString()}），输入缓存命中率 ${row.cacheHitRate === null ? "未知" : (row.cacheHitRate * 100).toFixed(1) + "%"}`);
  }
  console.log(`记录诊断：${JSON.stringify(report.diagnostics)}`);
  console.log("仅为本机可见日志观察，非账户扣费或节省证明；未知计数记录未纳入。供应商账单、缺失会话和跨机器记录需另行核对。旧硬编码费率已停用。");
  if (!report.rows.length) console.log("没有找到可可靠汇总的 token 记录。");
}

switch (command) {
  case "worker": console.log(JSON.stringify(await subagentCli(args.slice(args.indexOf(command) + 1)), null, 2)); break;
  case "context": console.log(JSON.stringify(await contextSwitchCli(args.slice(args.indexOf(command) + 1)), null, 2)); break;
  case "handoff": console.log(JSON.stringify(await handoffCli(args.slice(args.indexOf(command) + 1)), null, 2)); break;
  case "refresh-openai":
    try { console.log(JSON.stringify(await syncOpenAiCatalog(codexHome))); }
    catch (error) { if (!flag("best-effort")) throw error; console.log("OpenAI directory refresh unavailable; keeping last verified catalog. " + error.message); }
    break;
  case "refresh": await refreshCatalog(); break;
  case "refresh-unified": await refreshUnifiedCatalog(); break;
  case "install": await installUnified(); break;
  case "install-zhipu":
  case "install-zai": await installZhipuCodingPlan(); break;
  case "uninstall-zhipu":
  case "uninstall-zai": await uninstallZhipuCodingPlan(); break;
  case "uninstall": await uninstallUnified(); break;
  case "enable": await enable(); break;
  case "disable": await disable(); break;
  case "status": await status(); break;
  case "usage": await usageReport(); break;
  default: throw new Error(`未知命令：${command}`);
}
