using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;

// CODEX_CLI_PATH must be an executable on Windows. Keep this shim small: the
// routing code and its tests live in app-server-proxy.mjs beside this file.
internal static class CodexCliProxy
{
    private static string Quote(string value)
    {
        if (value.Length > 0 && value.IndexOfAny(new[] { ' ', '\t', '\n', '"' }) < 0) return value;
        var result = new StringBuilder("\"");
        int slashes = 0;
        foreach (char ch in value)
        {
            if (ch == '\\') { slashes++; continue; }
            if (ch == '"')
            {
                result.Append('\\', slashes * 2 + 1);
                result.Append('"');
                slashes = 0;
                continue;
            }
            result.Append('\\', slashes);
            slashes = 0;
            result.Append(ch);
        }
        result.Append('\\', slashes * 2);
        result.Append('"');
        return result.ToString();
    }

    private static string FindNode()
    {
        string user = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        string primary = Path.Combine(user, @".cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe");
        if (File.Exists(primary)) return primary;
        string runtimeRoot = Path.Combine(local, @"OpenAI\Codex\runtimes\cua_node");
        if (Directory.Exists(runtimeRoot))
        {
            foreach (string folder in Directory.GetDirectories(runtimeRoot))
            {
                string candidate = Path.Combine(folder, @"bin\node.exe");
                if (File.Exists(candidate)) return candidate;
            }
        }
        foreach (string folder in (Environment.GetEnvironmentVariable("PATH") ?? "").Split(';'))
        {
            try
            {
                string candidate = Path.Combine(folder.Trim('"'), "node.exe");
                if (File.Exists(candidate)) return candidate;
            }
            catch { }
        }
        throw new FileNotFoundException("Codex Model Picker cannot find Node.js.");
    }

    private static void Copy(Stream source, Stream target, bool closeTarget)
    {
        try { source.CopyTo(target); target.Flush(); }
        catch (IOException) { }
        catch (ObjectDisposedException) { }
        finally { if (closeTarget) try { target.Close(); } catch { } }
    }

    private static void CopyInputLines(Stream source, Stream target)
    {
        try
        {
            using (var line = new MemoryStream())
            {
                int value;
                while ((value = source.ReadByte()) != -1)
                {
                    line.WriteByte((byte)value);
                    if (value != '\n') continue;
                    line.WriteTo(target);
                    target.Flush();
                    line.SetLength(0);
                }
                if (line.Length > 0) { line.WriteTo(target); target.Flush(); }
            }
        }
        catch (IOException) { }
        catch (ObjectDisposedException) { }
        finally { try { target.Close(); } catch { } }
    }

    private static int Main(string[] args)
    {
        try
        {
            string script = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "app-server-proxy.mjs");
            if (!File.Exists(script)) throw new FileNotFoundException("Codex Model Picker proxy script is missing.", script);
            var start = new ProcessStartInfo(FindNode())
            {
                Arguments = Quote(script) + (args.Length == 0 ? "" : " " + String.Join(" ", Array.ConvertAll(args, Quote))),
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardInput = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
            };
            using (var child = Process.Start(start))
            {
                if (child == null) throw new InvalidOperationException("Could not start Codex Model Picker proxy.");
                var input = new Thread(() => CopyInputLines(Console.OpenStandardInput(), child.StandardInput.BaseStream));
                var output = new Thread(() => Copy(child.StandardOutput.BaseStream, Console.OpenStandardOutput(), false));
                var error = new Thread(() => Copy(child.StandardError.BaseStream, Console.OpenStandardError(), false));
                input.IsBackground = true;
                output.IsBackground = true;
                error.IsBackground = true;
                input.Start(); output.Start(); error.Start();
                child.WaitForExit();
                output.Join(3000); error.Join(3000);
                return child.ExitCode;
            }
        }
        catch (Exception error)
        {
            Console.Error.WriteLine("Codex Model Picker CLI proxy failed: " + error.Message);
            return 127;
        }
    }
}
