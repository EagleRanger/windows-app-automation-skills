﻿param(
    [ValidateSet('Get', 'StoreFromStdin', 'Status')]
    [string]$Mode = 'Get'
)

$ErrorActionPreference = 'Stop'
$runtimeRoot = Join-Path $env:LOCALAPPDATA 'CodexModelPicker'
$credentialPath = Join-Path $runtimeRoot 'zhipu-coding-token.dpapi'

function Read-ProtectedToken {
    if (-not (Test-Path -LiteralPath $credentialPath)) { throw 'Codex Zhipu Coding Plan credential is not configured.' }
    Add-Type -AssemblyName System.Security
    $protected = [Convert]::FromBase64String([IO.File]::ReadAllText($credentialPath).Trim())
    $plain = [Security.Cryptography.ProtectedData]::Unprotect($protected, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
    [Text.Encoding]::UTF8.GetString($plain)
}

function Normalize-Token([string]$Value) {
    if ($null -eq $Value) { return '' }
    # Windows console input can include Ctrl+Z (SUB, U+001A) before EOF.
    # Remove surrounding whitespace/control characters, but reject controls
    # embedded in the credential instead of silently changing its contents.
    $normalized = $Value -replace '^[\p{C}\s]+|[\p{C}\s]+$', ''
    if ($normalized -match '\p{C}') { throw 'Zhipu Coding Plan API Key contains an invalid control character.' }
    return $normalized
}

switch ($Mode) {
    'Get' { $token = Normalize-Token (Read-ProtectedToken); if (-not $token) { throw 'Codex Zhipu Coding Plan credential is empty.' }; Write-Output $token }
    'StoreFromStdin' {
        $token = Normalize-Token ([Console]::In.ReadToEnd())
        if ($token.Length -lt 20) { throw 'Zhipu Coding Plan API Key is invalid.' }
        Add-Type -AssemblyName System.Security
        $null = New-Item -ItemType Directory -Force -Path $runtimeRoot
        $plain = [Text.Encoding]::UTF8.GetBytes($token)
        $protected = [Security.Cryptography.ProtectedData]::Protect($plain, $null, [Security.Cryptography.DataProtectionScope]::CurrentUser)
        $temporary = $credentialPath + '.tmp-' + $PID
        [IO.File]::WriteAllText($temporary, [Convert]::ToBase64String($protected), [Text.UTF8Encoding]::new($false))
        Move-Item -LiteralPath $temporary -Destination $credentialPath -Force
        Write-Output 'stored'
    }
    'Status' { try { $configured = [bool](Normalize-Token (Read-ProtectedToken)) } catch { $configured = $false }; [pscustomobject]@{ configured = $configured; storage = 'Windows DPAPI CurrentUser'; path = $credentialPath } | ConvertTo-Json -Compress }
}
