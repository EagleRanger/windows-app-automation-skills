﻿$ErrorActionPreference = 'Stop'

$pluginRoot = Split-Path -Parent $PSScriptRoot
$tokenScript = Join-Path $PSScriptRoot 'codex-deepseek-token.ps1'
$dshCredentials = Join-Path $env:USERPROFILE '.dsh\.credentials.yaml'
$token = [Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY', 'User')
if (-not $token) { $token = [Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY', 'Process') }
if (-not $token -or $token.Trim().Length -lt 12) { throw '没有找到可迁移的 DeepSeek API Key。' }
$token = $token.Trim()

$previousProcessValue = [Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY', 'Process')
[Environment]::SetEnvironmentVariable('DEEPSEEK_API_KEY', $token, 'Process')
try {
    & $tokenScript -Mode StoreFromEnvironment | Out-Null
    $readback = & $tokenScript -Mode Get
    if ($readback -ne $token) { throw 'Codex DPAPI 凭据回读不一致。' }

    $dshRoot = Split-Path -Parent $dshCredentials
    $null = New-Item -ItemType Directory -Force -Path $dshRoot
    $existing = if (Test-Path -LiteralPath $dshCredentials) { [IO.File]::ReadAllText($dshCredentials) } else { "version: 1`n" }
    if ($existing -notmatch '(?m)^version:\s*1\s*$') { throw 'DSH 凭据文件版本无法识别，未覆盖。' }
    $quoted = $token | ConvertTo-Json -Compress
    if ($existing -match '(?m)^refs:\s*$') {
        if ($existing -match '(?m)^\s{2}DEEPSEEK_API_KEY\s*:') {
            $next = [regex]::Replace($existing, '(?m)^\s{2}DEEPSEEK_API_KEY\s*:.*$', '  DEEPSEEK_API_KEY: ' + $quoted, 1)
        } else {
            $next = [regex]::Replace($existing, '(?m)^refs:\s*$', "refs:`n  DEEPSEEK_API_KEY: $quoted", 1)
        }
    } else {
        $next = [regex]::Replace($existing, '(?m)^version:\s*1\s*$', "version: 1`nrefs:`n  DEEPSEEK_API_KEY: $quoted", 1)
    }
    if ($next -ne $existing -and (Test-Path -LiteralPath $dshCredentials)) {
        Copy-Item -LiteralPath $dshCredentials -Destination ($dshCredentials + '.pre-codex-isolation-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    }
    [IO.File]::WriteAllText($dshCredentials, $next.TrimEnd() + "`n", [Text.UTF8Encoding]::new($false))
    $dshReadback = [IO.File]::ReadAllText($dshCredentials)
    if ($dshReadback -notmatch '(?m)^\s{2}DEEPSEEK_API_KEY\s*:') { throw 'DSH 凭据写入后未能回读。' }

    [Environment]::SetEnvironmentVariable('DEEPSEEK_API_KEY', $null, 'User')
    if ([Environment]::GetEnvironmentVariable('DEEPSEEK_API_KEY', 'User')) { throw 'Windows 用户级 DeepSeek 环境变量未能移除。' }

    Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class EnvironmentBroadcast {
    [DllImport("user32.dll", SetLastError=true, CharSet=CharSet.Auto)]
    public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam, uint flags, uint timeout, out UIntPtr result);
}
'@
    $result = [UIntPtr]::Zero
    [void][EnvironmentBroadcast]::SendMessageTimeout([IntPtr]0xffff, 0x001A, [UIntPtr]::Zero, 'Environment', 2, 3000, [ref]$result)
    Write-Output 'Codex credential: DPAPI isolated and verified.'
    Write-Output 'DSH credential: local credential store updated and verified.'
    Write-Output 'Shared user environment variable: removed.'
} finally {
    [Environment]::SetEnvironmentVariable('DEEPSEEK_API_KEY', $previousProcessValue, 'Process')
}
