# v2.1.0 - 2026-10-03

本次更新对齐 `deepseek-codex-picker 0.1.0+codex.20261003174419` 的最终源码快照，包含最新默认 worker 候选顺序。相对于 v2.0.0：

- 整套校验并复制已登记的官方 CLI、code-mode host、命令执行与 sandbox helper；逐文件 SHA-256 核对，按内容标识复用完整缓存，保留仍在运行的旧版本。
- 准备官方 cua_node 运行组件，冷启动等待真实界面、路由和菜单就绪；只按本次进程与启动时间识别致命日志，显示实际错误原因。
- Windows 已下载更新暂不能登记时保留已登记版本继续启动，不强制关闭现有任务。
- 模型目录查询与代理共用同一套官方 CLI，减少“菜单已有新型号、实际后端仍是旧版”的错配。
- 直接轮次、队列与定时任务的模型覆盖也受供应商身份检查；冲突时请求原配对切换并说明原指令尚未执行，不自动重放。
- 额度服务增加运行组件版本读回，避免旧服务存活导致新版入口误判；OpenAI、GLM、DeepSeek 的数值解析口径未变。
- 临时 worker 默认 GLM-5.3 Flash → DeepSeek Flash → GPT-6.1 Sol High → GPT-6 Luna High；显式候选优先，未知创建回执或已开始的工作不自动回退重放。

公开包仍含两个 Skill，保留原第三方 MIT 归属与同类产品参考。本次随包测试 177 项通过，两份 Skill 与插件结构校验通过。发布包不含 API Key、密码、DPAPI 数据、账号配置、聊天正文、运行日志或 Codex/Node 二进制。接收方需自己的 Windows Codex Desktop、Node.js 22+ 与供应商账号，并在自己的环境核对启动、工具执行、真实跨供应商往返和额度显示。

# v2.0.0 - 2026-09-30

本次公开更新对齐本机 `deepseek-codex-picker 0.1.0+codex.20260930072655` 的源码。相对于 v1.0.0，主要变化：

- 适配新版 Codex 的用户级 `CODEX_CLI_PATH` app-server 路由代理；改进冷启动、单实例和页面刷新后的菜单挂载。
- OpenAI 模型目录从当前登录态可访问的官方目录更新，支持手动与运行时定期复查；失败保留上次成功目录。
- 跨供应商交接加入项目 Loop 热状态、配对槽位与可恢复回执；交接文本预算合计 14,000 字符。
- 来源任务绑定 heartbeat 时逐项迁移到配对任务，读回确认后才归档来源。
- 容量不足/服务器过载仅在原生证据完整、无副作用时尝试一次接续；不覆盖普通额度、鉴权和网络故障。
- 左下角三源额度栏继续显示 OpenAI 本机周额度回执、GLM 5 小时/每周窗口、DeepSeek 官方余额，不估算缺失数据。
- 增加运行期、交接语义、容量故障分支的验证入口及 Windows 设置修复/原 OpenAI 路由恢复入口。

发布包包含 `codex-multimodel-bridge` 与 `codex-inline-quota-widget` 两个 Skill。仅支持 Windows；接收方仍需自己的账号、DPAPI 凭据、Codex Desktop 与 Node.js 22+。本包不含密钥、账号配置、聊天内容、运行日志、回执或 Codex 二进制。静态测试不能替代接收方机器上的真实界面往返、定时触发或自然容量故障验收。

源码归属和同类参考见 `README.md`、`THIRD_PARTY_NOTICES.md` 与 `vendor/codex-model-picker/LICENSE`。
