# Third-party notices

## Included MIT source

This package includes modified source from [Mochall/codex-model-picker](https://github.com/Mochall/codex-model-picker).

Copyright (c) 2026 Codex Model Picker contributors.

Licensed under the MIT License. The copied source and its complete license are retained in `vendor/codex-model-picker/`.

## Research and comparison only

- [keaipiao/codex-quota](https://github.com/keaipiao/codex-quota) was reviewed as a comparable Windows Codex sidebar quota project. Its source is not copied here.
- [onllm-dev/onWatch](https://github.com/onllm-dev/onwatch) informed local-first, fail-closed quota product boundaries. No GPL-3.0 source, binary, or UI from onWatch is included here.

## Runtime packaging

This repository and its v2.1.0 release ZIP do not bundle Node.js, Codex Desktop, provider credentials, or account data. Install Node.js 22+ separately before using the launcher. Runtime components are copied only from the user's registered official Codex installation and verified locally; they are not distributed in this ZIP.
