@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start-quota-dashboard.ps1" -NoOpen
echo API 额度已嵌入 Codex 左侧栏。请返回 Codex，在个人资料栏上方查看。
if errorlevel 1 pause
