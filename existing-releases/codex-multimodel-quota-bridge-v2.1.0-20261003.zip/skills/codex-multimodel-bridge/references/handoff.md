# 原生规划 → DeepSeek 文件执行 → 原生接回

用于用户明确要求把有界文件工作交给 DeepSeek，或准备原生额度不足时的接续。此为插件内直接 API 文件执行器，不是 collaboration 原生子代理，也不是同任务跨供应商热切换。无需在每个项目建立常驻配对任务。

## 日常准备

沿用项目现有状态，只在自然阶段边界记录当前目标、最新纠正、已通过成果、未解项、必要文件版本和下一步。原生额度不足时无需原生模型再总结；但没有预先保全的信息不能凭空恢复。三四家供应商共享同一交接格式，不扩展规划审核层。

## 入口

## 完整项目的交接合同

文件执行器只是可实测的小范围入口。需要构建、运行桌面工具或连续开发时，由目标供应商的原生任务承接，使用该任务真实可用的工具。不能将候选文件的成功推广成整项业务通过。

沿用项目现有检查点，保留六项：当前目标及最新纠正；已完成项及验收证据；未完成的下一步；必要文件路径和内容指纹；权限/冻结范围/已否定路线；当前执行者及接回条件。按需附证据，不复制整段历史，不传模型私有推理。已有状态满足要求就引用，不另建第二套管理台账。

- 正常搭配：Astra 或 Sol 只在必要规划/校审节点介入，执行者完成一个有界阶段并自检后回传。用户最新手动选择优先；现有 Terra/CAD 例外不因安装本入口改变。
- 原生额度不足：额度未耗尽前，在自然阶段边界保全检查点。已有 DeepSeek 原生任务可在本身权限和工具范围内承担后续规划、执行、自检，不依赖已停用的原生主控逐步批准。没有目标任务时由用户创建/明确授权创建；不能暗建常驻配对任务。
- 接续任务先核对当前目标、已验收项、文件指纹和真实工具能力，再从下一步工作；缺材料按证据指针补读。无法恢复的内容明确列为未知，不补写历史成果。
- 额度恢复：用户选择接回后，待当前有副作用的操作结束，冻结交接涉及的写入；同一文件保持一个执行者。只交付阶段增量、证据、未解项与下一步，原生主控核验后继续，不重做已经通过的工作。
- 第三/第四供应商以后复用上述合同，另测其工具和接口；本版只实现 DeepSeek 适配，没有自动额度监控、自动回切或其他供应商适配。

## 文件入口命令

插件根目录 scripts/run-manager.ps1 的命令：

```powershell
& '<插件根>/scripts/run-manager.ps1' handoff prepare '<spec.json>' '<新的交接目录>'
& '<插件根>/scripts/run-manager.ps1' handoff run '<交接目录>'
& '<插件根>/scripts/run-manager.ps1' handoff inspect '<交接目录>'
& '<插件根>/scripts/run-manager.ps1' handoff accept '<交接目录>' '<review.json>'
```

将 `<插件根>` 替换为实际已加载的插件路径。也可直接用 Node 运行 scripts/handoff.mjs，参数从 prepare/run/inspect/accept 开始。run 默认 deepseek-flash / high；可显式选择 deepseek-v4-pro。只从 DEEPSEEK_API_KEY 读取密钥，Windows 用户环境为后备，不读取 ChatGPT 认证，不启动嵌套 Codex CLI。

原生额度已经用完且无法发出工具调用时，用户可运行插件根的“继续-DeepSeek-交接.cmd”，输入事先准备的交接目录。它只完成候选文件及固定检查，不自动合入或冒充生产验收。真实 Codex 额度耗尽时的界面可用性需另测。

## 准备说明 spec.json

必填：version=1、root（真实项目绝对路径）、goal、nextAction、constraints[]、decisions[]、rejected[]、acceptance[]、files[]、checks[]。

- files 每项为 {path: 相对路径, write: true/false}。只放与本任务相关的 UTF-8 文本；只读输入必须存在，允许新增的目标文件可不存在。prepare 自动拍下文件内容和 SHA-256；不接受目录跳转、联接、认证文件和内部目录。
- 最新纠正写入 decisions，并在 rejected 说明被替代的旧路线，避免新模型接错旧目标。root 和源任务身份仅本地保留，不将本机绝对路径发给 API。
- checks 是主控事先定义的纯数据检查，不执行模型生成的命令。目前支持 json-equals（path/pointer/value）、json-preserve（path/pointer）、text-includes/text-excludes（path/text）、unchanged（path）。JSON pointer 采用 /字段/子字段。检查至少一项，不靠模型自述通过。
- 交接包最多 80KB，通常只需少量材料。模型每次输出最多 4096 tokens，正常两次请求（候选＋读取检查后回传），检查失败允许一次修复，最多三次。大代码改造、二进制文件、CAD/金融真实业务执行不在此文件执行器的验收范围；使用原生 DeepSeek 任务及项目已有工具和权限。
- 预先核对输入是否在用户允许交给该供应商的范围。不会上传整个项目或全部对话；发往官方 DeepSeek 的具体材料就是 packet 中的任务说明和选中文本。

## 回接与审核

1. run 仅生成 candidate.json、checks.json、result.json、RETURN.md 和 api-usage.json。它不写生产源文件，不调用 shell/MCP/桌面，也不自动唤醒原生主模型。DeepSeek 同供应商必要的推理续接只存运行内存，不保存在交接包或发送给原生审核者。
2. 主模型恢复后先 inspect，再读取 RETURN.md、候选差异及必要原文。inspect 检查包/候选身份、固定检查和完整文件内容的 SHA-256，不以 JSON version 字段代替内容核对；任何源文件变化都要求重新协调，不能直接覆盖新版。attempt-N.candidate.json / attempt-N.checks.json 保留各次候选和失败证据。
3. 语义验收、业务权限和必要执行测试仍由主控依项目要求判断。prepare 中的纯数据检查不足以证明一般代码运行正确，文件哈希一致也不证明目标满足。
4. 审核通过后建立 review.json：decision="accept"、packetId、packetHash、candidateHash（来自 inspect）、reviewer、reason。审核者按已有授权进行常规可逆合入，不需要用户重复审批；会影响真实系统的业务审批另按项目规则。
5. accept 先再次核对所有文件版本，备份后逐文件合入，留下 apply-receipt.json。完成后再次 inspect；结果属于哪个范围要讲清。JSON 中填写 reviewer 不是身份认证或宿主权限替代。

## 故障恢复

- 源文件漂移、旧审核、重复派发、候选被改动：明确拒绝，保留原任务和全部证据，不直接改 state.json 绕过。
- 400/401/429、网络中断或响应不完整：标 blocked，记录可见 API 用量，不自动重试。先诊断已发生的调用，确定新证据和修正后另备新包；无回执不宣称零计费。
- running/RUN.lock 表示执行中或崩溃待核对；先检查原进程/证据，不同时启动第二个执行者。applying 表示合入中断，按 apply-receipt 和备份处理，不能从头重复覆盖。
- RETURN.md 是执行者的待审回传；是否合入以 state.json/apply-receipt.json 和当前文件为准，不以旧说明覆盖新状态。
- API 真实用量在 api-usage.json（含服务端模型与响应 ID）；不包含当前原生主控成本，也不在现有原生会话 usage 汇总内，复盘时单列以免遗漏或重复。
