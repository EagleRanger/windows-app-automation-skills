---
name: codex-multimodel-bridge
description: 在 Windows Codex Desktop 中选择 OpenAI、DeepSeek 与 Z.ai GLM，并配置模型目录刷新、跨供应商配对任务接续和本机凭据。用于安装、切换、恢复或排查该扩展；普通 Codex 任务不额外触发。
---

# Codex 多模型桥接

本 Skill 对应插件根目录的 Windows 本地扩展。它不提供供应商账号或 API 权限；先确认目标供应商、项目材料和当前操作均在用户授权范围内。

## 安装与真实入口

- Windows 10/11、已安装 Codex Desktop 和 Node.js 22+。把整个发布包放在稳定目录；完全退出旧 Codex 后用 `启动-Codex-多模型.cmd` 启动。
- 在包根目录运行 `scripts/run-manager.ps1 install` 配置 DeepSeek；需要 GLM 时运行 `scripts/run-manager.ps1 install-zai`。使用接收方自己的供应商凭据。
- 新版路由通过用户级 `CODEX_CLI_PATH` 指向版本化 app-server 代理，不修改 WindowsApps 文件。启动器有界等待冷启动、以单实例锁处理重复点击，并由 renderer hook keeper 维护刷新后的模型菜单。仅有文件、进程或菜单不证明当前后端已加载代理；用 `scripts/run-manager.ps1 status` 和 `scripts/verify-runtime-acceptance.mjs` 核对。
- 启动前从 Windows 已登记安装包校验完整官方 CLI 与辅助 exe、cua_node 运行组件，逐文件检查 SHA-256，并保留正在运行的旧版本。模型目录查询和后端代理共用同一套已验证 CLI。已下载更新暂不能登记时保留已登记版本；本次启动出现致命错误时报告对应日志原因，不以进程 ID 代替就绪，也不自动重复拉起。
- OpenAI 目录从当前 ChatGPT 登录态可访问的官方目录更新，运行时定期复查；失败保留上次成功目录，且不覆盖 DeepSeek/Z.ai。手动更新用 `刷新-模型目录.cmd`。正在运行的原生 app-server 可能仍缓存旧目录，不为刷新中断任务。
- DeepSeek、Z.ai 凭据分别由 Windows 当前用户 DPAPI 文件提供，不写入 `config.toml`、共享环境变量、网页、URL 或日志。恢复原 OpenAI 路由用 `恢复-OpenAI.cmd`；它不负责关闭独立的 DeepSeek Harness。

## 模型与接续

- 新任务在右下角选 OpenAI、DeepSeek 或 GLM；同供应商只更新当前任务模型。菜单列出的模型不保证图片、工具、MCP 或桌面控制能力等价。
- 定时任务、队列和直接发送轮次也须遵守配对任务的供应商身份。模型覆盖冲突时，后端拒绝执行该条指令并请求配对切换；目标就绪后再由用户重新发送，不能把拒绝当作已经执行或自动重放。
- 跨供应商先核对该任务族已登记的目标供应商槽位：有槽位则取消归档复用，只有从未分配才创建一次。结果不明、恢复超时或目标验收失败时保留原槽位，不自动新建替代任务。
- 交接前读取源任务对应项目唯一的 `.project-reasoning/STATE.md`；没有时读取 `.project-reasoning/PROJECT_LOOP.md` 的热区。Loop 最多 8,000 字符，连同最近 6 轮用户/助手文本合计最多 14,000 字符；排除工具输出、私有推理和整段历史。读取失败不能伪称已核对项目，也不能带空交接包报成功。
- 目标需通过供应商/模型、历史可读、当前窗口选中、输入框可编辑检查。创建、交接注入和确认阶段有本地回执；确认丢失时先对账原生请求，不重放未知结果。`completed`、实际助手回复 `reply_observed`、语义正确是三个不同证据层次。
- 若来源任务绑定 heartbeat，先将原定时任务 ID 逐项指向目标配对任务，核对周期、提示词、状态和通知设置，并确认没有残留来源绑定后才归档来源。迁移或回滚不明时保留两端，不宣称定时接续成功。
- 只有原生证据证明容量不足或服务器过载、原轮次已停止且没有工具执行/助手输出/附件/后续新请求时，容量恢复才可尝试一次。额度、鉴权、普通网络错误或结果不明不自动换模；已产生副作用的整轮不能重放。

## 可选临时执行与验收

- 对自包含、一次性、有明确验收的工作，可在插件根目录运行 `scripts/run-manager.ps1 worker run <spec.json>`。默认候选为 GLM-5.3 Flash、DeepSeek Flash、GPT-6.1 Sol High、GPT-6 Luna High；显式候选优先。仅明确创建失败可回退，创建结果不明或轮次开始后不自动重放。共享桌面、同一文件和外部账号入口仍串行。
- 先运行随包测试和插件结构检查，再在接收方电脑核对后端代理、模型菜单刷新恢复、三源额度栏；最后在已核对任务族完成真实跨供应商往返、Heartbeat 绑定核对和实际回复。`scripts/verify-handoff-semantics.mjs --run` 可做隔离语义试验；`scripts/verify-capacity-runtime.mjs` 的故障注入不等于真实容量事故已验收。
- 失败时记录准确阶段，保留来源任务与原设置，不靠重新创建任务或重复执行带副作用的请求制造表面成功。
