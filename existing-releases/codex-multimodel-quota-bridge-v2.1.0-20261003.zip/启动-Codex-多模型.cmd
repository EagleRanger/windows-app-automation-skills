@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\launch-deepseek.ps1"
set "CODEX_PICKER_EXIT=%ERRORLEVEL%"
if not "%CODEX_PICKER_EXIT%"=="0" (
  echo.
  echo 启动未完成。上方已显示原因；如提示旧 Codex 正在退出，请等待后再试。
  pause
  exit /b %CODEX_PICKER_EXIT%
)
echo.
echo 启动器已完成校验，窗口将在约 2 秒后自动关闭。
timeout /t 2 /nobreak >nul
