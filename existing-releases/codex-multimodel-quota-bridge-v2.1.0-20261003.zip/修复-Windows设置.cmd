@echo off
powershell.exe -NoProfile -File "%~dp0scripts\repair-windows-setup.ps1"
