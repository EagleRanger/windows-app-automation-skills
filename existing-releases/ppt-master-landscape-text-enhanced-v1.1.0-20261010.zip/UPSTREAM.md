# Upstream and provenance

This repository is an unofficial derivative distribution of:

- Project: PPT Master
- Upstream: https://github.com/hugohe3/ppt-master
- Upstream copyright: Copyright (c) 2025–2026 Hugo He
- Upstream license: MIT License, retained in `LICENSE`

The packaged Skill is the locally installed and tested snapshot used by this project at release time. Its core files originated from the PPT Master lineage; the public delta includes landscape-editorial guidance, WPS-targeted measurement and render constraints, production-efficiency/context controls, and an optional Theme Factory identity-preset migration.

The nearest upstream commit to the original local snapshot date is `d6a6371801db448cda3498109f764508cee36328` (2026-07-24). This is a provenance aid, not a claim that the released tree is byte-identical to that commit. The local snapshot contains subsequent selected changes and intentionally does not claim compatibility with every later upstream release.

Theme Factory-derived material is separately attributed in `ppt-master/THIRD_PARTY_NOTICES.txt`, with the Apache-2.0 license retained at `ppt-master/licenses/theme-factory-APACHE-2.0.txt`.
