"""Local timing, content-addressed intake receipts, and dependency-aware render plans.

No renderer, model, approval, or visual acceptance is inferred by this helper.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import posixpath
import subprocess
import time
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree as ET

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def write(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)

def files(paths):
    return {str(Path(p).resolve()): sha(p) for p in paths}

def append_event(path, event):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    event['utc'] = datetime.now(timezone.utc).isoformat()
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(event, ensure_ascii=False) + '\n')

def timed_run(log, phase, command, pages=None, attempt=1, reason=None):
    run_id = uuid.uuid4().hex
    base = dict(id=run_id, phase=phase, pages=pages or [], attempt=attempt, reason=reason)
    append_event(log, dict(base, event='start', command=command))
    start = time.perf_counter()
    code = None
    try:
        code = subprocess.run(command, shell=False).returncode
        return code
    finally:
        append_event(log, dict(base, event='end', seconds=round(time.perf_counter()-start, 4),
                              exit_code=code, status='success' if code == 0 else 'failed_or_interrupted'))

def timing_summary(log):
    events = [json.loads(s) for s in Path(log).read_text(encoding='utf-8').splitlines() if s.strip()]
    starts = {e['id']:e for e in events if e['event']=='start'}
    ends = {e['id']:e for e in events if e['event']=='end'}
    groups = {}
    for e in ends.values():
        g = groups.setdefault(e['phase'], dict(seconds=0, invocations=0, failures=0, reworks=0))
        g['seconds'] = round(g['seconds']+e['seconds'],4)
        g['invocations'] += 1
        g['failures'] += e['status'] != 'success'
        g['reworks'] += e['attempt'] > 1
    return dict(phases=groups, unfinished=[s for k,s in starts.items() if k not in ends],
                limits='Command wall time only; no token/cost or model-thinking inference.')

def timed_call(log, phase, callback):
    run_id=uuid.uuid4().hex
    append_event(log,dict(event='start',id=run_id,phase=phase,attempt=1,pages=[],reason=None))
    started=time.perf_counter(); code=None
    try:
        value=callback(); code=0 if value is None else value
        return value
    except SystemExit as exc:
        code=exc.code if isinstance(exc.code,int) else (0 if exc.code is None else 1)
        raise
    finally:
        append_event(log,dict(event='end',id=run_id,phase=phase,attempt=1,pages=[],reason=None,
                     seconds=round(time.perf_counter()-started,4),exit_code=code,
                     status='success' if code==0 else 'failed_or_interrupted'))

def cache_store(receipt, inputs, outputs, tools, config):
    if not inputs or not outputs or not tools:
        raise ValueError('Inputs, outputs and parser/tool files must be explicit.')
    value = dict(schema=1, inputs=files(inputs), outputs=files(outputs), tools=files(tools), config=config)
    write(receipt, value)
    return value

def cache_check(receipt, inputs, tools, config):
    try:
        old = read(receipt)
        hit = (old['schema']==1 and old['inputs']==files(inputs) and old['tools']==files(tools)
               and old['config']==config and old['outputs']==files(old['outputs']))
        return dict(reuse=hit, outputs=list(old['outputs']) if hit else [], reason='verified' if hit else 'fingerprint_changed')
    except (OSError, KeyError, ValueError):
        return dict(reuse=False, outputs=[], reason='missing_or_invalid_receipt_or_file')

REL = '{http://schemas.openxmlformats.org/package/2006/relationships}'
RID = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
def pptx_snapshot(path, environment):
    """Hash each slide's transitive visual dependencies, not notes or timestamps."""
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        def relations(part):
            rp = posixpath.join(posixpath.dirname(part), '_rels', posixpath.basename(part)+'.rels')
            if rp not in names: return []
            out = []
            for r in ET.fromstring(z.read(rp)):
                typ = r.get('Type','').rsplit('/',1)[-1]
                if typ in ('notesSlide','notesMaster','commentAuthors','comments','tags'): continue
                target = r.get('Target','')
                external = r.get('TargetMode')=='External'
                resolved = target if external else posixpath.normpath(posixpath.join(posixpath.dirname(part),target)).lstrip('/')
                out.append((r.get('Id'),typ,resolved,external))
            return out
        pres = ET.fromstring(z.read('ppt/presentation.xml'))
        idmap = {rid:target for rid,typ,target,external in relations('ppt/presentation.xml') if not external}
        pns = '{http://schemas.openxmlformats.org/presentationml/2006/main}'
        slide_paths = [idmap[e.get(RID)] for e in pres.findall('.//'+pns+'sldId')]
        global_parts = {k:hashlib.sha256(z.read(k)).hexdigest() for k in
                        ('ppt/presProps.xml','ppt/tableStyles.xml') if k in names}
        size = pres.find(pns+'sldSz')
        global_parts['size'] = dict(size.attrib) if size is not None else None
        rows=[]
        for idx, part in enumerate(slide_paths,1):
            seen={}
            external=[]
            def walk(p):
                if p in seen: return
                if p not in names: raise ValueError('Missing dependency: '+p)
                rels = relations(p)
                seen[p] = dict(content=hashlib.sha256(z.read(p)).hexdigest(), relationships=rels)
                for rid,typ,target,is_external in rels:
                    if is_external:
                        if typ != 'hyperlink': external.append(target)
                    else: walk(target)
            walk(part)
            # Masters list every layout, so cycles conservatively widen the affected set.
            payload = json.dumps(dict(parts=seen,globals=global_parts),sort_keys=True).encode()
            rows.append(dict(page=idx, part=part, digest=hashlib.sha256(payload).hexdigest(), external=external))
        return dict(schema=1, deck_sha256=sha(path), environment=environment, slides=rows)

def render_plan(baseline, current):
    rows=current['slides']
    all_pages=list(range(1,len(rows)+1))
    if not baseline or baseline.get('environment') != current['environment'] or len(baseline.get('slides',[]))!=len(rows):
        return dict(mode='full', pages=all_pages, reason='baseline_missing_or_environment_or_page_count_changed')
    if any(r['external'] for r in rows):
        return dict(mode='full', pages=all_pages, reason='unverifiable_external_visual_dependency')
    changed=[r['page'] for a,r in zip(baseline['slides'],rows) if a['digest']!=r['digest'] or a['part']!=r['part']]
    return dict(mode='none' if not changed else 'delta',pages=changed,reason='transitive_visual_fingerprints',
                unchanged=len(rows)-len(changed), acceptance='Plan only; new baseline requires actual successful render and visual review.')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    sub=p.add_subparsers(dest='op',required=True)
    run=sub.add_parser('run'); run.add_argument('--log',required=True); run.add_argument('--phase',required=True)
    run.add_argument('--pages',default=''); run.add_argument('--attempt',type=int,default=1); run.add_argument('--reason')
    run.add_argument('command',nargs=argparse.REMAINDER)
    summary=sub.add_parser('summary'); summary.add_argument('log')
    for action in ('cache-store','cache-check'):
        c=sub.add_parser(action); c.add_argument('--receipt',required=True); c.add_argument('--inputs',nargs='+',required=True)
        c.add_argument('--tools',nargs='+',required=True); c.add_argument('--config',default='{}')
        if action=='cache-store': c.add_argument('--outputs',nargs='+',required=True)
    s=sub.add_parser('snapshot'); s.add_argument('pptx'); s.add_argument('--environment',required=True); s.add_argument('--output',required=True)
    r=sub.add_parser('render-plan'); r.add_argument('--baseline'); r.add_argument('--current',required=True)
    a=p.parse_args()
    if a.op=='run':
        command=a.command[1:] if a.command[:1]==['--'] else a.command
        if not command: p.error('Missing command after --')
        raise SystemExit(timed_run(a.log,a.phase,command,[int(x) for x in a.pages.split(',') if x],a.attempt,a.reason))
    if a.op=='summary': result=timing_summary(a.log)
    elif a.op=='cache-store': result=cache_store(a.receipt,a.inputs,a.outputs,a.tools,json.loads(a.config))
    elif a.op=='cache-check': result=cache_check(a.receipt,a.inputs,a.tools,json.loads(a.config))
    elif a.op=='snapshot':
        result=pptx_snapshot(a.pptx,read(a.environment)); write(a.output,result)
        result=dict(output=a.output,pages=len(result['slides']))
    else: result=render_plan(read(a.baseline) if a.baseline else None,read(a.current))
    print(json.dumps(result,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
