"""Opt-in, fingerprint-locked WPS glyph measurement. Unsupported styles fall back."""
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re

@lru_cache(maxsize=8)
def _profile(path,mtime):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    if data.get('status')!='validated_local': raise ValueError('WPS width profile is not validated')
    for item in [data['engine']]+data['groups']:
        key='path' if 'path' in item else 'font_file'
        digest='sha256' if 'sha256' in item else 'font_sha256'
        if hashlib.sha256(Path(item[key]).read_bytes()).hexdigest()!=item[digest]:
            raise ValueError('WPS/font fingerprint changed; recalibration required')
    return data

@lru_cache(maxsize=16)
def _font(path):
    from PIL import ImageFont
    return ImageFont.truetype(path,1000)

def calibrated_width(runs,profile_path):
    path=Path(profile_path)
    data=_profile(str(path.resolve()),path.stat().st_mtime_ns)
    total=0.0
    for run in runs:
        size=float(run.get('font_size',16))
        if not data['min_px']<=size<=data['max_px']: return None
        if run.get('font_style','normal') not in ('normal',''): return None
        if float(run.get('letter_spacing',0) or 0)!=0: return None
        family=str(run.get('font_family','')).split(',')[0].strip().strip('"\'')
        family={'微软雅黑':'Microsoft YaHei'}.get(family,family)
        weight=str(run.get('font_weight','400')).lower()
        if weight not in ('normal','400','bold','700'): return None
        bold=weight in ('bold','700')
        group=next((g for g in data['groups'] if g['font']==family and g['bold']==bold),None)
        if group is None: return None
        text=str(run.get('text',''))
        # Only the tested horizontal Latin/CJK repertoire; emoji/complex scripts fall back.
        if any(ord(c)>0xffff or 0x590<=ord(c)<0x2e80
               and not (0x2000<=ord(c)<=0x206f) and c not in '≥≤ⅢⅡⅠ' for c in text): return None
        for piece in re.findall(r'[\u2e80-\uffff]+|[^\u2e80-\uffff]+',text):
            face='Microsoft YaHei' if ord(piece[0])>=0x2e80 else family
            g=next(g for g in data['groups'] if g['font']==face and g['bold']==bold)
            total+=_font(g['font_file']).getlength(piece)*size/1000*group['scale']
    return total + data['safe_margin_px']
