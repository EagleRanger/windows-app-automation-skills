#!/usr/bin/env python3
"""PPT Master - SVG to PPTX Tool (thin wrapper).

Delegates to the svg_to_pptx package. ``-s final`` remains a native-export
diagnostic override; the standard pipeline reads ``svg_output/``:
    python3 scripts/svg_to_pptx.py <project_path> -s final
"""

import sys
from pathlib import Path

# Ensure the scripts directory is on sys.path so the package can be found
sys.path.insert(0, str(Path(__file__).resolve().parent))

from console_encoding import configure_utf8_stdio
from svg_to_pptx import main

configure_utf8_stdio()

if __name__ == '__main__':
    import os
    from pipeline_efficiency import timed_call
    project = Path(sys.argv[1]) if len(sys.argv)>1 and not sys.argv[1].startswith('-') else None
    log = os.environ.get('PPTMASTER_TIMING_LOG')
    if not log and project is not None and project.is_dir():
        log = project / 'analysis' / 'timing.jsonl'
    raise SystemExit(timed_call(log, 'native-export', main) if log else main())
