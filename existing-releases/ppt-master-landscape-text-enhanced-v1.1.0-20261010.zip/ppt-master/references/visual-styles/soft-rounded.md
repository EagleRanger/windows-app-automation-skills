# Visual style: soft-rounded

Approachable and modern. Rounded cards, gentle elevation, friendly rhythm. For product, SaaS, training, consumer decks.

---

## 1. Shape & decoration

- Shape language: rounded rectangles (`rx` 12-16), pill tags, soft containers. Consistent radius deck-wide.
- Composition geometry: a large soft disc or blob bleeding off one edge as the color field; a pill chain or arc path replacing the boxed step row; one hero panel overlapping a full-width tinted band; an oversized rounded numeral behind the point. Cards are the container language, not the composition — vary the stage they sit on.
- Decoration: cards as the primary container; icon accents; numbered circles; gentle dividers. Moderate, in service of clarity.
- Whitespace: comfortable padding inside cards; even gutters; balanced rather than austere.

## 2. Typography character

- Friendly sans (humanist or geometric); medium weights; clear but not severe hierarchy.
- Rounded, open letterforms suit; avoid condensed / industrial faces.

> Families are chosen at confirmation `g`; this style asks for an approachable sans *character*.

## 3. Using the deck's colors

- Theme color used confidently on covers / chapter backgrounds; same-hue tints for card backings; accent for key figures.
- Warmer, more generous color use than swiss / editorial. Assign hues by semantic role and visual hierarchy; intentional multi-hue compositions remain valid.

> HEX values come from confirmation `e`; this style governs confident, friendly color use without naming colors or imposing a ratio.

## 4. Texture / elevation

- Gentle elevation: soft shadows on floating cards (resting tier), subtle tints, optional same-hue gradients. Two-tier elevation max; keep peer-grid cards flat.

## 5. Paired image-rendering

`flat` — clean modern blocks for AI images. (For frosted-glass depth, see the dedicated [`glassmorphism`](./glassmorphism.md) style.)

## 6. Illustration propensity

**supportive** — friendly rounded spots suit this approachable style; use them where they lift rhythm or section warmth, kept restrained. With no user steer this is the default lean; an explicit user request wins either way, and `image_usage: none` writes no illustration rows.
