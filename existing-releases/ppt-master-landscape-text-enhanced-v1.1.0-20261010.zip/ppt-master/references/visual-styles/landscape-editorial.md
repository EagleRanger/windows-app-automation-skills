# Landscape Editorial

An image-led editorial system for landscape architecture, ecological restoration, planning, engineering landscapes, competition boards, and high-level project reports. It combines real project imagery and diagrams with strong report typography. It is not a card theme.

## 1. Shape and composition

- Start with the page function, then choose the composition. Common functions include cover/divider, claim, site/context map, project case, before-after evidence, process/timeline, technical detail, comparison/table, method summary, and closing.
- Let aerial photography, master plans, maps, sections, construction photographs, and rendered views form the page-scale field. Crop and position them to preserve the strongest terrain, shoreline, settlement, or engineering feature.
- Favor editorial structures: open headline blocks, asymmetric image/text fields, margin notes, figure captions, hairline rules, oversized numerals, compact metric bands, and one dominant visual hierarchy.
- Use containers only when they clarify grouping, legibility, or comparison. A page may use naked type, a rule-and-label system, a single floating caption, an inset panel, or a table without any card shell.
- Do not repeat one card grid, bubble family, corner radius, or overlay recipe across unrelated page functions. A reusable component must first succeed on at least two different page functions without flattening their hierarchy.

## 2. Typography character

- Report-scale and competition-board hierarchy: decisive titles, short line lengths, clear numeric emphasis, disciplined captions, and generous leading.
- Use restrained sans as the primary system; a refined serif or contrast display family may be used for short editorial titles when it remains export-safe and coherent with the project.
- Treat prose as prose. Do not create arbitrary line breaks, fragment continuous reasoning into bullets, or shrink text to rescue a weak container.
- Emphasize through scale, weight, position, rules, and selective accent color before outlines, glows, or ornamental text effects.

## 3. Color usage

- Derive the palette from authoritative project imagery, maps, and brand constraints. Preserve natural asset colors when they carry factual or site identity.
- Coordinate cool environmental fields with a controlled warm counter-accent when the source supports it; avoid muddy gray-blue overlays and low-contrast monochrome washes.
- If a background image is materially off-direction, color-grade the image and overlay together. Do not compensate for a dull background by making text panels progressively darker.
- Protect strong image features. A large overlay may occupy only the region that needs legibility; it must not erase the very landscape evidence chosen as the visual anchor.

## 4. Material, depth, and containers

- Flat editorial panels, translucent surfaces, bright-white glass, labels, pills, and framed figures are all conditional materials, never defaults.
- Bright-white or lightly tinted translucent bubbles/glass are permitted when the background, hierarchy, and content call for them. Tune white balance, opacity, edge contrast, radius, highlight, and shadow against the actual page; keep the result luminous rather than dirty gray.
- Never repair an unsuitable bubble merely by recoloring it. Reconsider its geometry, text hierarchy, padding, alignment, and whether a container is needed at all.
- Use shadows sparingly and locally. Peer information blocks should usually remain flat; lift only the element that is genuinely floating above the image field.

## 5. Page-function starting structures

| Page function | Useful starting structures |
|---|---|
| Cover / divider | full-bleed image + open title; image horizon + oversized chapter numeral; typographic poster over a quiet crop |
| Core claim | large statement + one evidence image; hero number + short interpretation; quote-led landscape field |
| Site / context | dominant map or aerial + indexed callouts; layered map strip + concise legend; locator inset + one takeaway |
| Project / case | asymmetric photo field + dossier column; hero image + metric band; sequence of evidence frames with one conclusion |
| Process / timeline | route line over terrain; staged bands; image-led sequence with captions; avoid identical bubble chains by default |
| Technical / table | full-width designed table; detail drawing + specification column; comparison matrix with restrained surface hierarchy |
| Method / summary | one framework diagram + concise explanation; editorial columns; large verb-led statement + evidence row |
| Closing | memorable site image + distilled conclusion; forward call over horizon; no generic thank-you card |

These are starting structures, not templates. Adapt proportion and density to content and reading mode.

## 6. Image and illustration discipline

- Supplied photographs, plans, maps, diagrams, and rendered views are usually primary because they carry project authority.
- AI imagery may create a background, conceptual transition, spatial scenario, or style prototype when it meaningfully improves communication. It may also help establish layout and art direction.
- Do not use AI imagery as decoration that competes with stronger real evidence. Generated imagery inherits the deck palette and visual hierarchy.
- Spot illustration propensity: **sparse**. Use only when it clarifies an abstract relationship or fills a genuine evidence gap.

## 7. Paired rendering

Default paired image rendering: `corporate-photo`. A project may instead use a restrained custom rendering when supplied imagery or an explicitly confirmed concept requires it.
