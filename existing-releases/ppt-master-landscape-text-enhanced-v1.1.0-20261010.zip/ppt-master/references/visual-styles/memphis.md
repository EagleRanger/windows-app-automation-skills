# Visual style: memphis

Memphis / Pop — clashing color blocks, geometric confetti, bold outlines, 80s-revival exuberance. Loud and playful. For festivals, consumer brands, youth culture, launch hype, anything that wants energy over restraint.

---

## 1. Shape & decoration

- Shape language: bold geometric primitives — circles, triangles, zigzags, squiggles, blobs — with thick dark outlines (2-4px). Mixed corner radii allowed; playful inconsistency is on-brand.
- Composition geometry: a giant primitive bleeding off one edge as the backdrop; a diagonal two-color field split; a zigzag or squiggle band as the section divider; props scattered at angles around one dominant rotated frame or badge at the focal point.
- Decoration: scattered geometric confetti, color-block backings, pattern fills (dots / stripes), oversized punctuation. Generous decoration — but composed, not chaotic.
- Whitespace: energetic asymmetry; props float at angles. Still leave the focal content room to read against the noise.

## 2. Typography character

- Display poster type for headlines (heavy, attention-grabbing); a neutral readable sans for body so density stays legible under the visual energy.
- Big, confident headline scale; tight to the artwork. Body kept clean and quiet by contrast.

> Families are chosen at confirmation `g`; this style asks for a display-poster headline × neutral-sans body *character*.

## 3. Using the deck's colors

- Multi-accent clash is the signature — but bounded: the clashing colors stay a minority of canvas (≈40% cap), and any one page fronts only two or three of them, not the whole set.
- A light field carries the noise; dark outlines anchor every shape so the clash reads as composed, not muddy. Disciplined exuberance, never rainbow soup.

> HEX values come from confirmation `e`; this style governs how many accents appear and how boldly — it names no colors.

## 4. Texture / elevation

- Mostly flat pop-art blocks; bold outlines do the separating, not shadows. Optional hard-offset (sticker / cutout) shadows for a retro pop feel — flat, not soft. Keep gradients rare.

## 5. Paired image-rendering

`flat` — clean vivid flat-color illustration that matches the pop-block energy.

## 6. Illustration propensity

**core** — bold-outline spots, confetti, and geometric shapes *are* the Memphis language; with no user steer, default to recommending a coherent spot-illustration family. Default *lean* only — heaviness and placement stay Strategist judgment, an explicit user request wins either way, and `image_usage: none` writes no illustration rows.
