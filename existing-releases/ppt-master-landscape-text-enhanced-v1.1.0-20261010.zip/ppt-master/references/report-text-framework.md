# Source report to slide text

Use this reference when a formal report supplies the deck's substantive structure, when the user requests close structural fidelity, or when learning from a human-edited deck. It supplements content planning, not rendering or template mechanics. Do not impose it on unrelated creative/topic-only decks.

## Diagnose feedback before editing

When the user asks to compare a human deck with a generated deck and improve extraction, the deliverable is a source-grounded comparison and workflow improvement. Do not silently turn that into editing the human deck. Use only the identified originals; an assistant's intermediate correction is not human feedback.

Assign each input a role: report/fact source, human communication example, generated baseline. Check identity and version separately. A recently supplied file is not necessarily the newest factual edition. Without a verified revision lineage, compare by semantic topic, allow many-to-many page mappings, and do not claim that a difference was an intentional human deletion or addition.

## Engineering report display: original text first

When the task is to display an engineering report in PPT form, treat the report's framework and wording as the presentation source, not as material for a new popularized explanation. Use original text wherever it can serve the page. This explicit source-treatment requirement takes precedence over balanced/default narrative rewriting; visual discretion, fewer pages, or requests for clarity do not by themselves authorize semantic restructuring.

- Preserve original chapter and subsection titles, parallel item names, professional verbs and objects, and their order and hierarchy. Select representative original sentences and clauses for body text before attempting a paraphrase.
- Prefer faithful excerpting, removal of repeated wording, line breaks, and splitting across pages. If shortening is necessary, keep the original terminology, conditions, scope, modality and causal links. Do not splice excerpts into a new causal claim.
- Combining material on one page is a layout operation: retain each original label and relationship. It is not permission to invent an umbrella concept, collapse parallel engineering tasks, or replace a precise technical description with a more familiar phrase.
- A clearer-sounding paraphrase is not evidence of equivalent engineering meaning. If equivalence is uncertain, retain the original passage and flag the ambiguity. Apparent errors or contradictions stay unresolved pending the relevant decision; do not silently correct them.
- In the existing source-to-page map, distinguish verbatim text, shortened excerpt and paraphrase. Record a reason for any necessary paraphrase and check it directly against the original. This is a review aid, not an extra approval stage.

Example: if the source heading is “退还挤占” and its children are “落实水资源刚性约束”, “强化生态流量保障”, and “加强非常规水源利用”, retain those titles and their parent-child relationship. Do not substitute “退还挤占生态用水” or merge the three into a newly named task.

Explicit requests for a popular-science explanation or a freely restructured narrative may change this treatment. Do not infer that permission from a request to make an engineering report look better or read more smoothly.

## Preserve the source's structure before compressing

Before authoring the page outline, identify the report's chapter tree, nested lists, table headings and the role of each section. Distinguish baseline, problem, cause, need, objective, measure, implementation and expected effect.

For close-fidelity instructions, retain authoritative chapter names and parent-child relationships. A slide subtitle may explain a formal title, but may not silently replace it with a different concept. Reordering or merging for a permitted narrative still requires a clear source mapping; retain material qualifications. Do not make all formal reports structurally rigid when the user explicitly authorizes freer reshaping.

Use the existing project analysis and design outline; add a compact source-to-page map rather than another parallel specification. For each necessary subsection record its destination page(s), combination with another section, or justified omission. Do not treat an attractive page count, a recurring three-card layout, or an image roster as evidence of content coverage.

## Extract complete content units

Keep these fields together where relevant:

- **Meaning:** source locator, exact formal name, parent heading, excerpt, concise rendering, and any condition or qualification.
- **Issue:** observed state, stated cause, need and corresponding measure. Keep them distinct; a measure is not the cause, and a desired effect is not a verified current fact.
- **Project:** full project identity and scope, current problem, core purpose, construction content and quantities, expected role, investment boundary and timing if supplied. Missing information stays missing. Build the complete unit before distributing it over overview/detail slides.
- **Indicator:** exact name, population/reach, baseline year/value or missing marker, target/year, unit and definition, annual milestones if required. Never fill a missing baseline with an implementation method or a target.

Compress repetition and subordinate explanation, not the subject, object, causal relation or a necessary qualifier. Preserve parallel source items at their original level; do not promote a child into a parent or relabel the parent as one child. Formal place names, project names, facility types and technical terms are copied precisely unless a supported correction is authorized.

## Learn selectively from a human example

Classify each relevant difference as coverage, grouping/splitting, order/hierarchy, explanation/wording, factual/version change, or error/uncertainty. Trace it to the report before deciding whether to adopt it.

Adopt supported communication improvements such as a complete project overview, explicit rationale, or a comparison table. Retain correct information already present in the generated deck. Do not copy an older project roster, stale target, wrong unit or unsupported scope merely because it appears in the human example. Do not universalize a particular page count or layout from one pair of decks.

Source contradictions remain open with their locations, competing statements, provisional treatment and required decision. A mathematically plausible repair is not an authorized factual resolution. Method learning does not resolve unrelated source disputes.

## Compose pages from content units

Choose page granularity after extraction. One complete overview may consolidate several repetitive detail pages, while important evidence may justify a detail page. The original report's communicative obligations and the user's requested depth govern this choice.

Keep the substantive logic visible: readers should be able to follow the issue, rationale and proposed response without recovering essential meaning from speaker notes. Use notes for supporting detail and traceability. A short title plus scattered numbers is not a substitute for an argument.

## Bidirectional review

Before handing the outline to execution, and again against exported text:

1. **Report to slides:** every required chapter/subsection/list item has a destination or an explicit omission reason. Reconcile different counts only within their respective parent sections.
2. **Slides to report:** each substantive assertion, formal term and number has the correct locator and preserves the original meaning, status, scope and unit.
3. **Across slides:** no contradictory baseline/target, repeated investment, duplicated construction quantity, orphan heading or imagery carrying obsolete labels.
4. **Human feedback:** identify which supported organizational changes were absorbed and which differences were rejected as stale or incorrect.

For method maintenance, deliver a bounded comparison, the revised decision rules and representative source-backed replay examples. Distinguish successful document installation and sample replay from improvement proven by a future natural generation task. Do not regenerate a deck unless requested.
