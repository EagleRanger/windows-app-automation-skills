# Local production efficiency

Keep page-by-page design judgment open. Do not freeze landscape aesthetics into fixed slots; preserve the current continuous main-agent cadence. This run does not establish suitability or cost benefits for cheaper models.

## Timing without model reporting

The native `svg_to_pptx.py` entry automatically records to `<project>/analysis/timing.jsonl`
(or process-local `PPTMASTER_TIMING_LOG`). Do not double-wrap that entry when summing time.
Other deterministic commands can use the wrapper below.

Wrap deterministic commands with:

`python scripts/pipeline_efficiency.py run --log <project>/analysis/timing.jsonl --phase export --attempt 1 -- <runtime> <export-command> <args>`

Use phases such as intake, image-analysis, checks, export, render. For rework include `--attempt 2 --pages 1,12,18 --reason <short-cause>`. Review once with `summary <log>`. A crashed run without an end event is unfinished, never success. This measures command wall time, not model thinking, token cost, or full user wait time. Do not reconstruct missing historical timing.

## Intake reuse and context recovery

Before reconverting an unchanged local source, `cache-check --receipt <json> --inputs <source-files> --tools <parser-and-local-helper-files> --config <JSON>`.
After successful parsing, `cache-store` with the same arguments plus `--outputs <markdown-and-manifests-and-extracted-files>`. Include all reusable outputs, parser settings, and actual dependency/runtime versions in config. Cache miss is safe: parse again, never trust stale output. Do not use this cache for changing remote URLs without fresh source retrieval.

Separate physical parsing from model reading. On recovery read current instructions, current project/spec pointers and a compact source index; retrieve exact relevant source sections. Do not repeatedly inject the full extracted manuscript/media listing. Cache reuse does not prove the source has been understood or authorize dropping content.

## Authored line breaks

The exporter now preserves positional SVG lines by default in one editable text frame. Equal `dy` is not evidence of a soft wrap. `data-paragraph-soft-break="1"` on a line explicitly allows joining; `"0"` preserves it. For imported text whose historical heuristic is genuinely intended, opt in on that text with `data-pptx-line-break-policy="auto"`. Do not auto-mark every prose line as reflowable. Unsupported positional structures retain the existing flattening path.

## WPS-specific text widths

Only when targeting the locally validated WPS build, set the process-local `PPTMASTER_WPS_WIDTH_PROFILE` to `references/wps-width-local.json` before native export. Do not set a permanent global environment variable. The profile checks WPS and font file hashes; mismatch blocks reuse. Clear the variable for PowerPoint or other renderers.

Accepted range: Microsoft YaHei and Arial, regular/bold, horizontal CJK/Latin/digits, 24–52 SVG px (18–39 pt), zero custom tracking. Other styles retain the previous estimator and require visual checks. The model measures real font advances and uses the locally tested margin; it never shrinks fonts, edits text or overrides an explicitly authored frame. A close width estimate does not prove text fits its designed container.

## Incremental render scope

Use `snapshot <pptx> --environment <json> --output <candidate.json>`. Environment JSON must include renderer/WPS version, relevant font-file hashes, renderer settings, converter identity and width-profile hash. Then `render-plan --baseline <last-visually-accepted.json> --current <candidate.json>`.

- First complete deck, missing baseline, changed environment, page-count change or unverifiable linked visual media: full render.
- Local changes: render only returned page numbers using WPS `impress slide-export-image` (batch if supported). Full PDF export followed by selected rasterization is not a genuinely incremental WPS render.
- Notes-only changes do not invalidate visual renders, but still require notes/content checks.
- Theme, master, layout and shared image dependencies are traced transitively. Conservative over-invalidation is allowed; under-invalidation is not.
- Always run whole-package integrity and page/notes/source checks independently of render scope.
- Keep candidate snapshots separate. Replace the accepted baseline only after successful actual renders and visual review, retaining references to unchanged accepted images. A snapshot or plan is not visual acceptance.

Never clear or overwrite previous outputs to make a cache hit or review appear current.
