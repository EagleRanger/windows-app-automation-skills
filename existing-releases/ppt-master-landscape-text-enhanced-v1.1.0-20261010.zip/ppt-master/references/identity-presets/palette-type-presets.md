# Palette and Typography Presets

These ten presets preserve the useful color and typography intent migrated from Theme Factory. They are optional seeds for the existing PPT Master confirmation flow, not full visual styles and not a second selection system.

## Routing and precedence

Use this catalog only when one of the following is true:

- the user explicitly names a preset;
- the user asks to browse preset color directions;
- no user, brand, or active-template identity exists and one preset is a useful starting candidate for the actual content.

Apply precedence in this order: user or brand identity → active template → project-specific proposal → optional preset recall. A preset contributes one candidate to confirmation `e` and `g`; it does not automatically win. Do not show the showcase or ask an extra theme question for every deck.

After selection, expand the seed into the complete `design_spec.colors` role set and recurring typography roles. Check body-text contrast at 4.5:1 or better, preserve factual colors in natural assets, and derive only the tints, shades, semantic states, surfaces, grids, scrims, or overlays the deck actually needs. Persist resolved roles rather than relying on the preset name at execution time.

## Font compatibility

The source themes used DejaVu and FreeFont families. PPT Master adapts their intent to PowerPoint-safe Windows stacks:

- sans intent: Chinese `Microsoft YaHei`; Latin `Segoe UI` or `Arial`;
- serif intent: Chinese `SimSun`; Latin `Georgia` or `Times New Roman`;
- keep bold as a role weight, not a separate family name.

Use a different installed, export-safe family when the project or template provides stronger evidence. Never claim a font is available without checking the target environment.

## Catalog

| Preset id | Direction and exact source tokens | Typography intent | Useful starting contexts |
|---|---|---|---|
| `ocean-depths` | Deep Navy `#1A2332`; Teal `#2D8B8B`; Seafoam `#A8DADC`; Cream `#F1FAEE`. Calm maritime contrast with navy as the dark anchor. | sans | Corporate, finance, consulting, trust-building material |
| `sunset-boulevard` | Burnt Orange `#E76F51`; Coral `#F4A261`; Warm Sand `#E9C46A`; Deep Purple `#264653`. Warm, energetic contrast. | serif headers + sans body | Creative pitches, marketing, lifestyle, events |
| `forest-canopy` | Forest Green `#2D4A2B`; Sage `#7D8471`; Olive `#A4AC86`; Ivory `#FAF9F6`. Grounded natural identity. | serif headers + sans body | Environment, sustainability, outdoor, wellness, organic products |
| `golden-hour` | Mustard Yellow `#F4A900`; Terracotta `#C1666B`; Warm Beige `#D4B896`; Chocolate Brown `#4A403A`. Inviting autumn warmth. | sans | Hospitality, restaurants, artisan products, seasonal lifestyle |
| `arctic-frost` | Ice Blue `#D4E4F7`; Steel Blue `#4A6FA5`; Silver `#C0C0C0`; Crisp White `#FAFAFA`. Cool clarity and precision. | sans | Healthcare, pharmaceuticals, clean tech, winter sports |
| `desert-rose` | Dusty Rose `#D4A5A5`; Clay `#B87D6D`; Sand `#E8D5C4`; Deep Burgundy `#5D2E46`. Muted, elegant warmth. | sans | Fashion, beauty, interiors, boutique and wedding material |
| `modern-minimalist` | Charcoal `#36454F`; Slate Gray `#708090`; Light Gray `#D3D3D3`; White `#FFFFFF`. Flexible grayscale discipline. | sans | Architecture, modern business, data, restrained design portfolios |
| `tech-innovation` | Electric Blue `#0066FF`; Neon Cyan `#00FFFF`; Dark Gray `#1E1E1E`; White `#FFFFFF`. High-contrast digital energy. | sans | AI/ML, software, digital transformation, product launches |
| `botanical-garden` | Fern Green `#4A7C59`; Marigold `#F9A620`; Terracotta `#B7472A`; Cream `#F5F3ED`. Fresh organic color with floral accents. | serif headers + sans body | Agriculture, food, botanical brands, natural products |
| `midnight-galaxy` | Deep Purple `#2B1E3E`; Cosmic Blue `#4A4E8F`; Lavender `#A490C2`; Silver `#E6E6FA`. Dramatic, low-light creative identity. | sans | Entertainment, gaming, nightlife, luxury, creative agencies |

The visual reference is [`theme-palette-showcase.pdf`](../../assets/theme-palette-showcase.pdf). It is browsing evidence only: choosing a page from it still requires the normal color, typography, contrast, and project-identity confirmation.

## Provenance and modification notice

These presets are adapted from Theme Factory, Copyright 2026 Anthropic, PBC, under Apache License 2.0. The migration separates palette/typography from layout style, normalizes hexadecimal capitalization, replaces non-portable font names with PowerPoint-safe intent mappings, and integrates the presets into PPT Master's existing confirmation hierarchy. See [`licenses/theme-factory-APACHE-2.0.txt`](../../licenses/theme-factory-APACHE-2.0.txt) and [`THIRD_PARTY_NOTICES.txt`](../../THIRD_PARTY_NOTICES.txt).
